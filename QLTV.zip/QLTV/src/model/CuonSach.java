package model;

/**
 *
 * @author BIN BIN
 */
public class CuonSach {

    private static long iDCounter = 0;
    private String iD;
    private String kho;
    private String dichVu;
    private String iDDauSach;
    private String iDNgan;
    private float giaThanhLy;
    private String iDPhieuThanhLy;
    private String trangThai;

    public CuonSach() {
    }

    public CuonSach(String kho, String dichVu, String iDDauSach, String iDNgan) {
        this.iD = String.format("CS%05d", iDCounter++);
        this.kho = kho;
        this.dichVu = dichVu;
        this.iDDauSach = iDDauSach;
        this.iDNgan = iDNgan;
        this.iDPhieuThanhLy = "";
        this.trangThai = "Chưa mượn";
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        CuonSach.iDCounter = iDCounter;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getKho() {
        return kho;
    }

    public void setKho(String kho) {
        this.kho = kho;
    }

    public String getDichVu() {
        return dichVu;
    }

    public void setDichVu(String dichVu) {
        this.dichVu = dichVu;
    }

    public String getiDDauSach() {
        return iDDauSach;
    }

    public void setiDDauSach(String iDDauSach) {
        this.iDDauSach = iDDauSach;
    }

    public String getiDNgan() {
        return iDNgan;
    }

    public void setiDNgan(String iDNgan) {
        this.iDNgan = iDNgan;
    }

    public float getGiaThanhLy() {
        return giaThanhLy;
    }

    public void setGiaThanhLy(float giaThanhLy) {
        this.giaThanhLy = giaThanhLy;
    }

    public String getiDPhieuThanhLy() {
        return iDPhieuThanhLy;
    }

    public void setiDPhieuThanhLy(String iDPhieuThanhLy) {
        this.iDPhieuThanhLy = iDPhieuThanhLy;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    @Override
    public String toString() {
        return "%s %s %s %s %s %s %f %s".formatted(this.iD, this.kho, this.dichVu,
                this.iDDauSach, this.iDNgan, this.iDPhieuThanhLy, this.giaThanhLy,
                this.trangThai).toLowerCase();
    }
}
