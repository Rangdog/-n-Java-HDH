package model;

/**
 *
 * @author BIN BIN
 */
public class Ke {

    private static long iDCounter = 0;
    private final String iD;

    public Ke() {
        this.iD = String.format("K%04d", iDCounter++);
    }

    public Ke(String iD) {
        this.iD = iD;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        Ke.iDCounter = iDCounter;
    }

    public String getiD() {
        return iD;
    }
}
