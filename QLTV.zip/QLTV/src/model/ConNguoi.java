package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class ConNguoi {

    protected String iD;
    protected String hoTen;
    protected String phai;
    protected Calendar ngaySinh;
    protected String diaChi;
    protected String email;

    protected ConNguoi() {
    }

    protected ConNguoi(String iD, String hoTen, String phai, Calendar ngaySinh,
            String diaChi, String email) {
        this.iD = iD;
        this.hoTen = hoTen;
        this.phai = phai;
        this.ngaySinh = ngaySinh;
        this.diaChi = diaChi;
        this.email = email;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getPhai() {
        return phai;
    }

    public void setPhai(String phai) {
        this.phai = phai;
    }

    public Calendar getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(Calendar ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "%s %s %s %s %s %s".formatted(this.iD, this.hoTen, this.phai,
                view.HomeFrm.df.format(this.ngaySinh.getTime()), this.diaChi, this.email);
    }
}
