package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class HoaDon {

    protected String iD;
    protected String iDThuThu;
    protected Calendar ngayThucHien;

    protected HoaDon() {

    }

    public HoaDon(String iD, String iDThuThu, Calendar ngayThucHien) {
        this.iD = iD;
        this.iDThuThu = iDThuThu;
        this.ngayThucHien = ngayThucHien;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getiDThuThu() {
        return iDThuThu;
    }

    public void setiDThuThu(String iDThuThu) {
        this.iDThuThu = iDThuThu;
    }

    public Calendar getNgayThucHien() {
        return ngayThucHien;
    }

    public void setNgayThucHien(Calendar ngayThucHien) {
        this.ngayThucHien = ngayThucHien;
    }

    @Override
    public String toString() {
        return "%s %s %s".formatted(this.iD, this.iDThuThu,
                view.HomeFrm.df.format(this.ngayThucHien.getTime()));
    }
}
