package model;

import java.util.Calendar;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DocGia extends ConNguoi {

    private static long iDCounter = 0;
    private String sdt;
    private boolean daHuy;

    public DocGia() {
    }

    public DocGia(String hoTen, String phai, Calendar ngaySinh, String diaChi,
            String email, String sdt) {
        super(String.format("DG%05d", iDCounter++), hoTen, phai, ngaySinh,
                diaChi, email);
        this.sdt = sdt;
        this.daHuy = true;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        DocGia.iDCounter = iDCounter;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public boolean isDaHuy() {
        return daHuy;
    }

    public void setDaHuy(boolean daHuy) {
        this.daHuy = daHuy;
    }

    @Override
    public String toString() {
        return "%s %s %s".formatted(super.toString(), this.sdt, this.daHuy
                ? "Đã hủy" : "Chưa hủy").toLowerCase();
    }
}
