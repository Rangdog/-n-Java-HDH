package model;

/**
 *
 * @author Hà Xuân Thanh
 */
public class SanPham {

    private String iDDauSach;
    private int soLuong;

    public SanPham(String iDDauSach, int soLuong) {
        this.iDDauSach = iDDauSach;
        this.soLuong = soLuong;
    }

    public String getiDDauSach() {
        return iDDauSach;
    }

    public void setiDDauSach(String iDDauSach) {
        this.iDDauSach = iDDauSach;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    @Override
    public String toString() {
        return "%s %d".formatted(this.iDDauSach, this.soLuong).toLowerCase();
    }
}
