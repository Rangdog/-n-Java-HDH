package model;

import java.util.Calendar;

/**
 *
 * @author Hà Xuân Thanh
 */
public class LePhi extends HoaDon {

    private static long iDCounter = 0;
    private String iDDocGia;
    private float chiPhi;

    public LePhi() {
    }

    public LePhi(String iDDocGia, String iDThuThu, float chiPhi, Calendar ngayDong) {
        super(String.format("LP%06d", iDCounter++), iDThuThu, ngayDong);
        this.iDDocGia = iDDocGia;
        this.chiPhi = chiPhi;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        LePhi.iDCounter = iDCounter;
    }

    public String getiDDocGia() {
        return iDDocGia;
    }

    public void setiDDocGia(String iDDocGia) {
        this.iDDocGia = iDDocGia;
    }

    public float getChiPhi() {
        return chiPhi;
    }

    public void setChiPhi(float chiPhi) {
        this.chiPhi = chiPhi;
    }

    @Override
    public String toString() {
        return "%s %s %f".formatted(super.toString(), this.iDDocGia,
                this.chiPhi).toLowerCase();
    }
}
