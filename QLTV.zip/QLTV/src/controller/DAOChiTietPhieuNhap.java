package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ChiTietPhieuNhap;
import model.SanPham;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAOChiTietPhieuNhap {

    private final Connection connection;

    public DAOChiTietPhieuNhap() throws Exception {
        connection = DAO_SQL.getConnection();
    }

    public void setList(List<ChiTietPhieuNhap> listChiTietPhieuNhap) {
        String sql = "SELECT * FROM CT_PHIEUNHAP";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String iDPN = result.getString("ID_PHIEUNHAP");
                String iDDS = result.getString("ID_DAUSACH");
                int soLuong = result.getInt("SOLUONG");
                listChiTietPhieuNhap.stream().filter(e -> e.getiD().
                        equals(iDPN)).findFirst().get().getDanhSach().
                        add(new SanPham(iDDS, soLuong));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOChiTietPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean insertList(String iDPN, String iDDS, int soluong) {
        String sql = "INSERT INTO CT_PHIEUNHAP "
                + "VALUES(?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iDPN);
            ps.setString(2, iDDS);
            ps.setInt(3, soluong);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOChiTietPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iDPN, String iDDS) {
        String sql = "DELETE FROM CT_PHIEUNHAP "
                + "WHERE ID_PHIEUNHAP = ? AND ID_DAUSACH = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iDPN);
            ps.setString(2, iDDS);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOChiTietPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
