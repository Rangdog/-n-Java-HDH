package model;

import java.util.Calendar;

/**
 *
 * @author Hà Xuân Thanh
 */
public class TacGia extends ConNguoi {

    private static long iDCounter = 0;

    public TacGia() {
    }

    public TacGia(String hoTen, String phai, Calendar ngaySinh, String diaChi, String email) {
        super(String.format("TG%05d", iDCounter++), hoTen, phai, ngaySinh,
                diaChi, email);
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        TacGia.iDCounter = iDCounter;
    }

    @Override
    public String toString() {
        return super.toString().toLowerCase();
    }
}
