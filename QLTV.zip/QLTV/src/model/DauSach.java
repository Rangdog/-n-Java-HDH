package model;

/**
 *
 * @author BIN BIN
 */
public class DauSach {

    private String iD;
    private String tenSach;
    private String theLoai;
    private float donGia;
    private int namXuatBan;
    private String iDNhaXuatBan;

    public DauSach() {
    }

    public DauSach(String iD, String tenSach, String theLoai, float donGia,
            int namXuatBan, String idNhaXuatBan) {
        this.iD = iD;
        this.tenSach = tenSach;
        this.theLoai = theLoai;
        this.donGia = donGia;
        this.namXuatBan = namXuatBan;
        this.iDNhaXuatBan = idNhaXuatBan;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public String getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }

    public float getDonGia() {
        return donGia;
    }

    public void setDonGia(float donGia) {
        this.donGia = donGia;
    }

    public int getNamXuatBan() {
        return namXuatBan;
    }

    public void setNamXuatBan(int namXuatBan) {
        this.namXuatBan = namXuatBan;
    }

    public String getIDNhaXuatBan() {
        return iDNhaXuatBan;
    }

    public void setIDNhaXuatBan(String idNhaXuatBan) {
        this.iDNhaXuatBan = idNhaXuatBan;
    }

    @Override
    public String toString() {
        return "%s %s %s %f %d %s".formatted(this.iD, this.tenSach, this.theLoai,
                this.donGia, this.namXuatBan, this.iDNhaXuatBan).toLowerCase();
    }
}
