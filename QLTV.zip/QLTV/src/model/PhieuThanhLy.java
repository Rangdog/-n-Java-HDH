package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class PhieuThanhLy extends HoaDon {

    private static long iDCounter = 0;

    public PhieuThanhLy() {
    }

    public PhieuThanhLy(String iDThuThu, Calendar ngayThanhLy) {
        super(String.format("TL%06d", iDCounter++), iDThuThu, ngayThanhLy);
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        PhieuThanhLy.iDCounter = iDCounter;
    }

    @Override
    public String toString() {
        return super.toString().toLowerCase();
    }
}
