package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.SangTac;

/**
 *
 * @author BIN BIN
 */
public class DAOSangTac {

    private final Connection connection;

    public DAOSangTac() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public void setList(List<SangTac> listSangTac) {
        String sql = "SELECT * FROM CT_TACGIA";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                String iDTacGia = result.getString("ID_TACGIA");
                String iDDauSach = result.getString("ID_DAUSACH");
                listSangTac.stream().filter(e -> e.getiD().equals(iDTacGia)).
                        findFirst().get().getDanhSach().add(iDDauSach);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOSangTac.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public boolean insertList(String iDTacGia, String iDDauSach) {
        String sql = "INSERT INTO CT_TACGIA "
                + "VALUES(?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iDTacGia);
            ps.setString(2, iDDauSach);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOSangTac.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iDTacGia, String iDDauSach) {
        String sql = "DELETE FROM CT_TACGIA "
                + "WHERE ID_TACGIA = ? AND ID_DAUSACH = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iDTacGia);
            ps.setString(2, iDDauSach);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOSangTac.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
