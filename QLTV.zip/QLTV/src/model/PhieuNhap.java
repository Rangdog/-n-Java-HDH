package model;

import java.util.Calendar;

/**
 *
 * @author Hà Xuân Thanh
 */
public class PhieuNhap extends HoaDon {

    private static long iDCounter = 0;

    public PhieuNhap() {
    }

    public PhieuNhap(String iDThuThu, Calendar ngayNhap) {
        super(String.format("PN%06d", iDCounter++), iDThuThu, ngayNhap);
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        PhieuNhap.iDCounter = iDCounter;
    }

    @Override
    public String toString() {
        return super.toString().toLowerCase();
    }
}
