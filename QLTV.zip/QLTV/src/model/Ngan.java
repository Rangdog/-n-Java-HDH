package model;

/**
 *
 * @author BIN BIN
 */
public class Ngan {

    private static long iDCounter = 0;
    private final String iD;
    private String iDKe;

    public Ngan() {
        this.iD = String.format("N%04d", iDCounter++);
        this.iDKe = "";
    }

    public Ngan(String iD, String iDKe) {
        this.iD = iD;
        this.iDKe = iDKe;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        Ngan.iDCounter = iDCounter;
    }

    public String getiD() {
        return iD;
    }

    public String getiDKe() {
        return iDKe;
    }

    public void setiDKe(String iDKe) {
        this.iDKe = iDKe;
    }

    @Override
    public String toString() {
        return "%s %s".formatted(this.iD, this.iDKe).toLowerCase();
    }
}
