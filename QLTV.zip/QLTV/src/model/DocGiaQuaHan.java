package model;

/**
 *
 * @author BIN BIN & Hà Xuân Thanh
 */
public class DocGiaQuaHan {

    private String iDPhieuMuon;
    private String iDDocGia;
    private String hoTen;
    private String tenSach;
    private int soNgayQuaHan;

    public DocGiaQuaHan(String iDPhieuMuon, String iDDocGia, String hoTen, 
            String tenSach, int soNgayQuaHan) {
        this.iDPhieuMuon = iDPhieuMuon;
        this.iDDocGia = iDDocGia;
        this.hoTen = hoTen;
        this.tenSach = tenSach;
        this.soNgayQuaHan = soNgayQuaHan;
    }

    public String getiDPhieuMuon() {
        return iDPhieuMuon;
    }

    public void setiDPhieuMuon(String iDPhieuMuon) {
        this.iDPhieuMuon = iDPhieuMuon;
    }

    public String getiDDocGia() {
        return iDDocGia;
    }

    public void setiDDocGia(String iDDocGia) {
        this.iDDocGia = iDDocGia;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public String getTenSach() {
        return tenSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public int getSoNgayQuaHan() {
        return soNgayQuaHan;
    }

    public void setSoNgayQuaHan(int soNgayQuaHan) {
        this.soNgayQuaHan = soNgayQuaHan;
    }

    @Override
    public String toString() {
        return "%s %s %s %s %s".formatted(this.iDPhieuMuon, this.iDDocGia,
                this.getHoTen(), this.tenSach, this.soNgayQuaHan).toLowerCase();
    }
}
