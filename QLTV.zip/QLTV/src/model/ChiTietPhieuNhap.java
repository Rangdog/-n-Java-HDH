package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hà Xuân Thanh
 */
public class ChiTietPhieuNhap extends ChiTiet {
    
    public ChiTietPhieuNhap(String iDPhieuNhap) {
        super(iDPhieuNhap, new ArrayList<SanPham>());
    }
    
    @Override
    public List<SanPham> getDanhSach() {
        return danhSach;
    }
    
    @Override
    public String toString() {
        String sanPham = this.getDanhSach().stream().map(e -> e.toString()).
                reduce((a, b) -> "%s %s".formatted(a, b)).get();
        return "%s %s".formatted(this.iD, sanPham).toLowerCase();
    }
}
