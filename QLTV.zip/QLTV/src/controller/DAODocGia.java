package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DocGia;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAODocGia {

    private final Connection connection;

    public DAODocGia() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<DocGia> getList() {
        List<DocGia> listDocGia = new ArrayList<>();
        String sql = "SELECT * FROM DOCGIA";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                DocGia e = new DocGia();
                e.setiD(result.getString("ID"));
                e.setHoTen(result.getString("HOTEN"));
                e.setPhai(result.getString("PHAI"));
                Calendar ngaySinh = Calendar.getInstance();
                ngaySinh.setTime(result.getDate("NGAYSINH"));
                e.setNgaySinh(ngaySinh);
                e.setDiaChi(result.getString("DIACHI"));
                e.setEmail(result.getString("EMAIL"));
                e.setSdt(result.getString("SDT"));
                e.setDaHuy(result.getBoolean("DAHUY"));
                listDocGia.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAODocGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listDocGia.isEmpty()) {
            DocGia.setiDCounter(Integer.parseInt(listDocGia.get(listDocGia.
                    size() - 1).getiD().substring(2, 7)) + 1);
        }
        return listDocGia;
    }

    public boolean insertList(DocGia e) {
        String sql = "INSERT INTO DOCGIA "
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getHoTen());
            ps.setString(3, e.getPhai());
            ps.setDate(4, new Date(e.getNgaySinh().getTimeInMillis()));
            ps.setString(5, e.getDiaChi());
            ps.setString(6, e.getEmail());
            ps.setString(7, e.getSdt());
            ps.setBoolean(8, e.isDaHuy());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAODocGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updateList(String iD, String hoTen, String phai, Calendar ngaySinh,
            String diaChi, String email, String sdt, boolean daHuy) {
        String sql = "UPDATE DOCGIA "
                + "SET HOTEN = ? , PHAI = ?, NGAYSINH = ?, DIACHI = ?, "
                + "EMAIL = ?, SDT = ?, DAHUY = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(8, iD);
            ps.setString(1, hoTen);
            ps.setString(2, phai);
            ps.setDate(3, new Date(ngaySinh.getTimeInMillis()));
            ps.setString(4, diaChi);
            ps.setString(5, email);
            ps.setString(6, sdt);
            ps.setBoolean(7, daHuy);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAODocGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void updateList(String iD, boolean daHuy) {
        String sql = "UPDATE DOCGIA "
                + "SET DAHUY = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setBoolean(1, daHuy);
            ps.setString(2, iD);
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAODocGia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
