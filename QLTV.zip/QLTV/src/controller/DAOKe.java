package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Ke;

/**
 *
 * @author BIN BIN
 */
public class DAOKe {

    private final Connection connection;

    public DAOKe() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<Ke> getList() {
        List<Ke> listKe = new ArrayList<>();
        String sql = "SELECT * FROM KE";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                Ke e = new Ke(result.getString("ID"));
                listKe.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOKe.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listKe.isEmpty()) {
            Ke.setiDCounter(Integer.parseInt(listKe.get(listKe.size() - 1).getiD().
                    substring(1, 5)) + 1);
        }
        return listKe;
    }

    public boolean insertList(Ke e) {
        String sql = "INSERT INTO KE "
                + "VALUES(?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOKe.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM KE "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOKe.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
