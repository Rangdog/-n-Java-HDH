package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhaXuatBan;

/**
 *
 * @author BIN BIN
 */
public class DAONhaXuatBan {

    private final Connection connection;

    public DAONhaXuatBan() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<NhaXuatBan> getList() {
        List<NhaXuatBan> listNhaXuatBan = new ArrayList<>();
        String sql = "SELECT * FROM NHAXUATBAN";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                NhaXuatBan e = new NhaXuatBan();
                e.setiD(result.getString("ID"));
                e.setTen(result.getString("TEN"));
                e.setDiaChi(result.getString("DIACHI"));
                e.setEmail(result.getString("EMAIL"));
                e.setSdt(result.getString("SDT"));
                listNhaXuatBan.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAONhaXuatBan.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listNhaXuatBan.isEmpty()) {
            NhaXuatBan.setiDCounter(Integer.parseInt(listNhaXuatBan.get(listNhaXuatBan.
                    size() - 1).getiD().substring(3, 7)) + 1);
        }
        return listNhaXuatBan;
    }

    public boolean insertList(NhaXuatBan e) {
        String sql = "INSERT INTO NHAXUATBAN "
                + "VALUES(?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getTen());
            ps.setString(3, e.getDiaChi());
            ps.setString(4, e.getEmail());
            ps.setString(5, e.getSdt());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAONhaXuatBan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updateList(String iD, String tenNXB, String diaChi,
            String email, String sDT) {
        String sql = "UPDATE NHAXUATBAN "
                + "SET TEN = ?, DIACHI = ?, EMAIL = ?, SDT = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, tenNXB);
            ps.setString(2, diaChi);
            ps.setString(3, email);
            ps.setString(4, sDT);
            ps.setString(5, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAONhaXuatBan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM NHAXUATBAN "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAONhaXuatBan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
