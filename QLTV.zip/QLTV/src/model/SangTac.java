package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Hà Xuân Thanh
 */
public class SangTac extends ChiTiet {

    public SangTac(String iDTacGia) {
        super(iDTacGia, new ArrayList<String>());
    }

    @Override
    public List<String> getDanhSach() {
        return danhSach;
    }

    @Override
    public String toString() {
        String tacPham = this.getDanhSach().stream().reduce((a, b) -> "%s %s".
                formatted(a, b)).get();
        return "%s %s".formatted(this.iD, tacPham).toLowerCase();
    }
}
