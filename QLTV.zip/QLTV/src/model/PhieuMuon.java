package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class PhieuMuon extends HoaDon {

    private static long iDCounter = 0;
    private String iDDocGia;

    public PhieuMuon() {
    }

    public PhieuMuon(String iDDocGia, String iDThuThu, Calendar ngayMuon) {
        super(String.format("PM%06d", iDCounter++), iDThuThu, ngayMuon);
        this.iDDocGia = iDDocGia;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        PhieuMuon.iDCounter = iDCounter;
    }

    public String getiDDocGia() {
        return iDDocGia;
    }

    public void setiDDocGia(String iDDocGia) {
        this.iDDocGia = iDDocGia;
    }

    @Override
    public String toString() {
        return "%s %s".formatted(super.toString(), this.iDDocGia).toLowerCase();
    }
}
