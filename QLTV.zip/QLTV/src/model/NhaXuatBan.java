package model;

/**
 *
 * @author Hà Xuân Thanh
 */
public class NhaXuatBan {

    private static long iDCounter = 0;
    private String iD;
    private String ten;
    private String diaChi;
    private String email;
    private String sdt;

    public NhaXuatBan() {
    }

    public NhaXuatBan(String ten, String diaChi, String email, String sdt) {
        this.iD = String.format("NXB%04d", iDCounter++);
        this.ten = ten;
        this.diaChi = diaChi;
        this.email = email;
        this.sdt = sdt;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        NhaXuatBan.iDCounter = iDCounter;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    @Override
    public String toString() {
        return "%s %s %s %s %s".formatted(this.iD, this.ten, this.diaChi,
                this.email, this.sdt).toLowerCase();
    }
}
