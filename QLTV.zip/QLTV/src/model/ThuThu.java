package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class ThuThu extends ConNguoi {

    public ThuThu() {
    }

    public ThuThu(String iD, String hoTen, String phai, Calendar ngaySinh,
            String diaChi, String email) {
        super(iD, hoTen, phai, ngaySinh, diaChi, email);
    }
}
