package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.SangTac;
import model.TacGia;

/**
 *
 * @author BIN BIN
 */
public class DAOTacGia {

    private final Connection connection;

    public DAOTacGia() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<TacGia> getList(List<SangTac> listSangTac) {
        List<TacGia> listTacGia = new ArrayList<>();
        String sql = "SELECT * FROM TACGIA";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                TacGia e = new TacGia();
                e.setiD(result.getString("ID"));
                e.setHoTen(result.getString("HOTEN"));
                e.setPhai(result.getString("PHAI"));
                Calendar ngaySinh = Calendar.getInstance();
                ngaySinh.setTime(result.getDate("NGAYSINH"));
                e.setNgaySinh(ngaySinh);
                e.setDiaChi(result.getString("DIACHI"));
                e.setEmail(result.getString("EMAIL"));
                listTacGia.add(e);
                listSangTac.add(new SangTac(e.getiD()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOTacGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listTacGia.isEmpty()) {
            TacGia.setiDCounter(Integer.parseInt(listTacGia.get(listTacGia.size() - 1).
                    getiD().substring(2, 7)) + 1);
        }
        return listTacGia;
    }

    public boolean insertList(TacGia e) {
        String sql = "INSERT INTO TACGIA "
                + "VALUES(?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getHoTen());
            ps.setString(3, e.getPhai());
            ps.setDate(4, new Date(e.getNgaySinh().getTimeInMillis()));
            ps.setString(5, e.getDiaChi());
            ps.setString(6, e.getEmail());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOTacGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updateList(String iD, String hoTen, String gioiTinh,
            Calendar ngaySinh, String diaChi, String email) {
        String sql = "UPDATE TACGIA "
                + "SET HOTEN = ?, PHAI = ?, NGAYSINH = ?, DIACHI = ?, EMAIL = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, hoTen);
            ps.setString(2, gioiTinh);
            ps.setDate(3, new Date(ngaySinh.getTimeInMillis()));
            ps.setString(4, diaChi);
            ps.setString(5, email);
            ps.setString(6, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOTacGia.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM TACGIA "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAONgan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
