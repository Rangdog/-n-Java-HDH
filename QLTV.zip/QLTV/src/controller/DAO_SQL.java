package controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class DAO_SQL {

    public static Connection getConnection() throws Exception {
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        String url = "jdbc:sqlserver://" + "LAPTOP-DOUILK3I\\SQLEXPRESS" + ":1433;DatabaseName=" + "QLTV_JAVA" + ";encrypt=true;trustServerCertificate=true";
        return DriverManager.getConnection(url, "sa", "123456");
    }
}
