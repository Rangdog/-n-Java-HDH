package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.TaiKhoan;

/**
 *
 * @author BIN BIN
 */
public class DAOTaiKhoan {

    private final Connection connection;

    public DAOTaiKhoan() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<TaiKhoan> getList() {
        List<TaiKhoan> listTaiKhoan = new ArrayList<>();
        String sql = "SELECT * FROM TAIKHOAN";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                TaiKhoan e = new TaiKhoan();
                e.setiDThuThu(result.getString("ID_THUTHU"));
                e.setTenDangNhap(result.getString("TENDANGNHAP"));
                e.setMatKhau(result.getString("MATKHAU"));
                listTaiKhoan.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listTaiKhoan;
    }
}
