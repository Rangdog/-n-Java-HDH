package model;

import java.util.List;

/**
 *
 * @author BIN BIN
 * @param <T>
 */
public class ChiTiet<T> {

    protected String iD;
    protected List<T> danhSach;

    public ChiTiet() {
    }

    public ChiTiet(String iD, List<T> danhSach) {
        this.iD = iD;
        this.danhSach = danhSach;
    }

    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public List<T> getDanhSach() {
        return danhSach;
    }

    public void setDanhSach(List<T> danhSach) {
        this.danhSach = danhSach;
    }
}
