package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class PhieuTra {

    private String iDPhieuMuon;
    private String iDCuonSach;
    private String iDThuThu;
    private Calendar ngayTra;
    private boolean daGiaHan;
    private boolean daMat;

    public PhieuTra() {
    }

    public PhieuTra(String iDPhieuMuon, String iDCuonSach) {
        this.iDPhieuMuon = iDPhieuMuon;
        this.iDCuonSach = iDCuonSach;
        this.iDThuThu = "";
        this.ngayTra = null;
        this.daGiaHan = false;
        this.daMat = false;
    }

    public String getiDPhieuMuon() {
        return iDPhieuMuon;
    }

    public void setiDPhieuMuon(String iDPhieuMuon) {
        this.iDPhieuMuon = iDPhieuMuon;
    }

    public String getiDCuonSach() {
        return iDCuonSach;
    }

    public void setiDCuonSach(String iDCuonSach) {
        this.iDCuonSach = iDCuonSach;
    }

    public String getiDThuThu() {
        return iDThuThu;
    }

    public void setiDThuThu(String iDThuThu) {
        this.iDThuThu = iDThuThu;
    }

    public Calendar getNgayTra() {
        return ngayTra;
    }

    public void setNgayTra(Calendar ngayTra) {
        this.ngayTra = ngayTra;
    }

    public boolean isDaGiaHan() {
        return daGiaHan;
    }

    public void setDaGiaHan(boolean daGiaHan) {
        this.daGiaHan = daGiaHan;
    }

    public boolean isDaMat() {
        return daMat;
    }

    public void setDaMat(boolean daMat) {
        this.daMat = daMat;
    }

    @Override
    public String toString() {
        return "%s %s %s %s %s %s".formatted(this.iDPhieuMuon, this.iDCuonSach,
                this.iDThuThu, this.ngayTra, this.daGiaHan ? "Đã gia hạn" : "Chưa gia hạn",
                this.daMat ? "Đã mất" : "Chưa mất").toLowerCase();
    }
}
