package model;

import java.util.Calendar;

/**
 *
 * @author BIN BIN
 */
public class PhieuPhat extends HoaDon {

    private static long iDCounter = 0;
    private String iDDocGia;
    private String lyDo;
    private String xuPhat;

    public PhieuPhat() {
    }

    public PhieuPhat(String iDDocGia, String iDThuThu, Calendar ngayLap,
            String lyDo, String xuPhat) {
        super(String.format("PP%06d", iDCounter++), iDThuThu, ngayLap);
        this.iDDocGia = iDDocGia;
        this.lyDo = lyDo;
        this.xuPhat = xuPhat;
    }

    public static long getiDCounter() {
        return iDCounter;
    }

    public static void setiDCounter(long iDCounter) {
        PhieuPhat.iDCounter = iDCounter;
    }

    public String getiDDocGia() {
        return iDDocGia;
    }

    public void setiDDocGia(String iDDocGia) {
        this.iDDocGia = iDDocGia;
    }

    public String getLyDo() {
        return lyDo;
    }

    public void setLyDo(String lyDo) {
        this.lyDo = lyDo;
    }

    public String getXuPhat() {
        return xuPhat;
    }

    public void setXuPhat(String xuPhat) {
        this.xuPhat = xuPhat;
    }

    @Override
    public String toString() {
        return "%s %s %s %s".formatted(super.toString(), this.iDDocGia,
                this.lyDo, this.xuPhat).toLowerCase();
    }
}
