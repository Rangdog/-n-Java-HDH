/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LEGION
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class testketnot {

    public static void main(String[] args) throws SQLException {
        Connection connection = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://" + "LAPTOP-DOUILK3I\\SQLEXPRESS" + ":1433;DatabaseName=" + "QLTV_JAVA" + ";encrypt=true;trustServerCertificate=true";
            connection = DriverManager.getConnection(url, "sa", "123456");
            System.out.println("Ket noi thanh cong!");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Ket noi that bai");
            e.printStackTrace();
        }
    }
}
