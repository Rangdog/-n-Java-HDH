package model;

/**
 *
 * @author BIN BIN
 */
public class TaiKhoan {

    private String iDThuThu;
    private String tenDangNhap;
    private String matKhau;

    public TaiKhoan() {
    }

    public TaiKhoan(String iDThuThu, String tenDangNhap, String matKhau) {
        this.iDThuThu = iDThuThu;
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
    }

    public String getiDThuThu() {
        return iDThuThu;
    }

    public void setiDThuThu(String iDThuThu) {
        this.iDThuThu = iDThuThu;
    }

    public String getTenDangNhap() {
        return tenDangNhap;
    }

    public void setTenDangNhap(String tenDangNhap) {
        this.tenDangNhap = tenDangNhap;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }
}
