package view;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.util.Calendar;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.text.SimpleDateFormat;
import model.*;
import controller.*;

/* @author: Phu Dự Thắng & Hà Xuân Thanh */
public class HomeFrm extends javax.swing.JFrame {

    public static final SimpleDateFormat df;
    private final Controller system;
    private final Image icon;
    final Icon ico_success, ico_failure, ico_question;
    private List<Ke> listKe;
    private List<Ngan> listNgan;
    private List<DauSach> listDauSach;
    private List<CuonSach> listCuonSach;
    private List<TacGia> listTacGia;
    private List<SangTac> listSangTac;
    private List<NhaXuatBan> listNXB;
    private List<DocGia> listDocGia;
    private List<PhieuNhap> listPhieuNhap;
    private List<ChiTietPhieuNhap> listChiTietPhieuNhap;
    private List<PhieuThanhLy> listPhieuThanhLy;
    private List<PhieuMuon> listPhieuMuon;
    private List<PhieuTra> listPhieuTra;
    private List<LePhi> listLePhi;
    private List<PhieuPhat> listPhieuPhat;
    private List<TaiKhoan> listTaiKhoan;
    private List<ThuThu> listThuThu;
    private ThuThu quanLy;
    private DefaultTableModel modelKe, modelNgan, modelDauSach, modelCuonSach,
            modelTacGia, modelSangTac, modelNXB, modelDocGia, modelPhieuNhap,
            modelChiTietPhieuNhap, modelPhieuThanhLy, modelPhieuMuon,
            modelPhieuTra, modelLePhi, modelPhieuPhat;
    private DAOThuThu sqlThuThu;
    private DAOTaiKhoan sqlTaiKhoan;
    private DAOKe sqlKe;
    private DAONgan sqlNgan;
    private DAODauSach sqlDauSach;
    private DAONhaXuatBan sqlNhaXuatBan;
    private DAOCuonSach sqlCuonSach;
    private DAOTacGia sqlTacGia;
    private DAOSangTac sqlSangTac;
    private DAODocGia sqlDocGia;
    private DAOPhieuNhap sqlPhieuNhap;
    private DAOChiTietPhieuNhap sqlChiTietPhieuNhap;
    private DAOPhieuThanhLy sqlPhieuThanhLy;
    private DAOPhieuMuon sqlPhieuMuon;
    private DAOPhieuTra sqlPhieuTra;
    private DAOPhieuPhat sqlPhieuPhat;
    private DAOLePhi sqlLePhi;
    private List<DocGiaQuaHan> listQuaHan;

    {
        this.icon = Toolkit.getDefaultToolkit().getImage("src/image/MAIN.png");
        this.ico_success = new ImageIcon("src/image/SUCCESS.png");
        this.ico_failure = new ImageIcon("src/image/FAILURE.png");
        this.ico_question = new ImageIcon("src/image/QUESTION.png");
        this.system = new Controller();
        this.quanLy = null;
    }

    static {
        df = new SimpleDateFormat("dd/MM/yyyy");
    }

    public HomeFrm() throws Exception {
        initComponents();
        this.initManagers();
        this.initLoginFrm();
        this.initDatabase();
        this.initEntities();
        this.initComboBox();
        this.displayData();
    }

    private void initManagers() throws Exception {
        // Initialize Administration.
        sqlThuThu = new DAOThuThu();
        sqlTaiKhoan = new DAOTaiKhoan();
        listThuThu = sqlThuThu.getList();
        listTaiKhoan = sqlTaiKhoan.getList();
    }

    private void initDatabase() throws Exception {
        // Initialize Data Acess Objects.
        sqlKe = new DAOKe();
        sqlNgan = new DAONgan();
        sqlNhaXuatBan = new DAONhaXuatBan();
        sqlDauSach = new DAODauSach();
        sqlCuonSach = new DAOCuonSach();
        sqlTacGia = new DAOTacGia();
        sqlSangTac = new DAOSangTac();
        sqlDocGia = new DAODocGia();
        sqlPhieuNhap = new DAOPhieuNhap();
        sqlChiTietPhieuNhap = new DAOChiTietPhieuNhap();
        sqlPhieuThanhLy = new DAOPhieuThanhLy();
        sqlPhieuMuon = new DAOPhieuMuon();
        sqlPhieuTra = new DAOPhieuTra();
        sqlLePhi = new DAOLePhi();
        sqlPhieuPhat = new DAOPhieuPhat();
    }

    private void initEntities() {
        // Download data from database.
        listKe = sqlKe.getList();
        listNgan = sqlNgan.getList();
        listNXB = sqlNhaXuatBan.getList();
        listDauSach = sqlDauSach.getList();
        listCuonSach = sqlCuonSach.getList();
        listSangTac = new ArrayList<>();
        listTacGia = sqlTacGia.getList(listSangTac);
        sqlSangTac.setList(listSangTac);
        listDocGia = sqlDocGia.getList();
        listChiTietPhieuNhap = new ArrayList<>();
        listPhieuNhap = sqlPhieuNhap.getList(listChiTietPhieuNhap);
        sqlChiTietPhieuNhap.setList(listChiTietPhieuNhap);
        listPhieuThanhLy = sqlPhieuThanhLy.getList();
        listPhieuMuon = sqlPhieuMuon.getList();
        listPhieuTra = sqlPhieuTra.getList();
        listLePhi = sqlLePhi.getList();
        listPhieuPhat = sqlPhieuPhat.getList();
        listQuaHan = system.getDanhSachMuonSachQuaHan();
        // Set up data models.
        modelKe = (DefaultTableModel) tblKe.getModel();
        modelNgan = (DefaultTableModel) tblNgan.getModel();
        modelNXB = (DefaultTableModel) tblNhaXuatBan.getModel();
        modelDauSach = (DefaultTableModel) tblDauSach.getModel();
        modelCuonSach = (DefaultTableModel) tblCuonSach.getModel();
        modelTacGia = (DefaultTableModel) tblTacGia.getModel();
        modelSangTac = (DefaultTableModel) tblSangTac.getModel();
        modelDocGia = (DefaultTableModel) tblDocGia.getModel();
        modelPhieuNhap = (DefaultTableModel) tblThongTinPhieuNhap.getModel();
        modelChiTietPhieuNhap = (DefaultTableModel) tblChiTietPhieuNhap.getModel();
        modelPhieuThanhLy = (DefaultTableModel) tblPhieuThanhLy.getModel();
        modelPhieuMuon = (DefaultTableModel) tblPhieuMuon.getModel();
        modelPhieuTra = (DefaultTableModel) tblPhieuTra.getModel();
        modelLePhi = (DefaultTableModel) tblLePhi.getModel();
        modelPhieuPhat = (DefaultTableModel) tblPhieuPhat.getModel();
    }

    private void displayData() {
        // Display data via GUI.
        this.checkDocGiaQuaHanLePhi();
        fillToTable(listKe, modelKe);
        fillToTable(listNgan, modelNgan);
        fillToTable(listNXB, modelNXB);
        fillToTable(listDauSach, modelDauSach);
        fillToTable(listCuonSach, modelCuonSach);
        fillToTable(listTacGia, modelTacGia);
        fillToTable(listSangTac, modelSangTac);
        fillToTable(listDocGia, modelDocGia);
        fillToTable(listChiTietPhieuNhap, modelChiTietPhieuNhap);
        fillToTable(listPhieuNhap, modelPhieuNhap);
        fillToTable(listPhieuThanhLy, modelPhieuThanhLy);
        fillToTable(listPhieuMuon, modelPhieuMuon);
        fillToTable(listPhieuTra, modelPhieuTra);
        fillToTable(listPhieuPhat, modelPhieuPhat);
        fillToTable(listLePhi, modelLePhi);
    }

    private void initComboBox() {
        // Download data to Combo Boxes.
        listKe.forEach(e -> cboKeTS.addItem(e.getiD()));
        listNgan.forEach(e -> {
            cboNganTS.addItem(e.getiD());
            cboNganCS.addItem(e.getiD());
        });
        listNXB.forEach(e -> cboNhaXuatBanDS.addItem(e.getiD()));
        listDauSach.stream().forEach(e -> {
            cboDauSachCS.addItem(e.getiD());
            cboDauSachST.addItem(e.getiD());
            cboDauSachCT.addItem(e.getiD());
        });
        listTacGia.forEach(e -> cboTacGiaST.addItem(e.getiD()));
        listDocGia.forEach(e -> {
            cboDocGiaLP.addItem(e.getiD());
            cboDocGiaPP.addItem(e.getiD());
            if (!e.isDaHuy()) {
                cboDocGiaPM.addItem(e.getiD());
            }
        });
        listPhieuThanhLy.forEach(e -> cboPhieuThanhLyCS.addItem(e.getiD()));
        listPhieuNhap.forEach(e -> cboPhieuNhapCT.addItem(e.getiD()));
        // Set up choice for Combo Boxes.
        cboKeTS.setSelectedIndex(-1);
        cboNganTS.setSelectedIndex(-1);
        cboNganCS.setSelectedIndex(-1);
        cboNhaXuatBanDS.setSelectedIndex(-1);
        cboDauSachCS.setSelectedIndex(-1);
        cboDauSachST.setSelectedIndex(-1);
        cboDauSachCT.setSelectedIndex(-1);
        cboTacGiaST.setSelectedIndex(-1);
        cboDocGiaLP.setSelectedIndex(-1);
        cboDocGiaPM.setSelectedIndex(-1);
        cboDocGiaPP.setSelectedIndex(-1);
        cboPhieuThanhLyCS.setSelectedIndex(-1);
        cboPhieuNhapCT.setSelectedIndex(-1);
    }

    public List<DocGiaQuaHan> getListQuaHan() {
        return listQuaHan;
    }

    public <T> void fillToTable(List<T> list, DefaultTableModel model) {
        // Set up data for models.
        model.setRowCount(0);
        for (T t : list) {
            switch (t) {
                case Ke e ->
                    model.addRow(new Object[]{e.getiD()});
                case Ngan e ->
                    model.addRow(new Object[]{e.getiD(), e.getiDKe()});
                case DauSach e ->
                    model.addRow(new Object[]{e.getiD(), e.getTenSach(), e.getTheLoai(),
                        e.getNamXuatBan(), "%,.3f".formatted(e.getDonGia()), e.getIDNhaXuatBan()});
                case CuonSach e ->
                    model.addRow(new Object[]{e.getiD(), e.getKho(), e.getDichVu(),
                        e.getiDDauSach(), e.getiDNgan(), e.getiDPhieuThanhLy(),
                        (e.getiDPhieuThanhLy().isEmpty()) ? "" : "%,.3f".
                        formatted(e.getGiaThanhLy()), e.getTrangThai()});
                case PhieuMuon e ->
                    model.addRow(new Object[]{e.getiD(), df.format(e.getNgayThucHien().getTime()),
                        e.getiDDocGia(), e.getiDThuThu()});
                case NhaXuatBan e ->
                    model.addRow(new Object[]{
                        e.getiD(), e.getTen(), e.getDiaChi(), e.getEmail(), e.getSdt()});
                case TacGia e ->
                    model.addRow(new Object[]{
                        e.getiD(), e.getHoTen(), e.getPhai(), df.format(e.getNgaySinh().getTime()),
                        e.getDiaChi(), e.getEmail()});
                case SangTac e ->
                    e.getDanhSach().forEach(iD -> model.addRow(new Object[]{e.getiD(), iD}));
                case DocGia e ->
                    model.addRow(new Object[]{e.getiD(), e.getHoTen(), e.getPhai(),
                        df.format(e.getNgaySinh().getTime()), e.getDiaChi(), e.getEmail(),
                        e.getSdt(), e.isDaHuy() ? "Đã hủy" : ""});
                case PhieuTra e -> {
                    Calendar ngayQuaHan = system.getNgayQuaHan(system.getNgayMuon(
                            listPhieuMuon, e.getiDPhieuMuon()), e.isDaGiaHan());
                    String ngayTra = e.getNgayTra() != null ? df.format(e.getNgayTra().
                            getTime()) : "";
                    String trangThai = e.isDaMat() ? "Đã mất" : Calendar.getInstance().
                            after(ngayQuaHan) ? "Đã quá hạn" : "";
                    model.addRow(new Object[]{e.getiDPhieuMuon(), e.getiDCuonSach(),
                        e.getiDThuThu(), ngayTra, df.format(ngayQuaHan.getTime()),
                        e.isDaGiaHan() ? "Đã gian hạn" : "", trangThai});
                }
                case PhieuPhat e ->
                    model.addRow(new Object[]{e.getiD(), e.getiDDocGia(), e.getiDThuThu(),
                        df.format(e.getNgayThucHien().getTime()), e.getLyDo(), e.getXuPhat()});
                case PhieuNhap e ->
                    model.addRow(new Object[]{
                        e.getiD(), df.format(e.getNgayThucHien().getTime()), e.getiDThuThu(),
                        "%,.3f".formatted(system.getTongTienPN(e.getiD(),
                        listChiTietPhieuNhap, listDauSach))});
                case ChiTietPhieuNhap e ->
                    e.getDanhSach().forEach(i -> model.addRow(new Object[]{
                        e.getiD(), i.getiDDauSach(), i.getSoLuong()}));
                case PhieuThanhLy e ->
                    model.addRow(new Object[]{
                        e.getiD(), e.getiDThuThu(), df.format(e.getNgayThucHien().getTime()),
                        "%,.3f".formatted(system.getTongTienPTL(e.getiD(), listCuonSach))});
                case LePhi e ->
                    model.addRow(new Object[]{
                        e.getiD(), e.getiDDocGia(), e.getiDThuThu(),
                        "%,.3f".formatted(e.getChiPhi()), df.format(e.getNgayThucHien().getTime())});
                case default -> {
                }
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btgPhaiTG = new javax.swing.ButtonGroup();
        btgPhaiDG = new javax.swing.ButtonGroup();
        btgPhaiQL = new javax.swing.ButtonGroup();
        tabbedQuanLy = new javax.swing.JTabbedPane();
        pnlQuanLy = new javax.swing.JPanel();
        pnlThongTinQuanLy = new javax.swing.JPanel();
        lblIDQL = new javax.swing.JLabel();
        lblHoTenQL = new javax.swing.JLabel();
        lblPhaiQL = new javax.swing.JLabel();
        lblNgaySinhQL = new javax.swing.JLabel();
        lblDiaChiQL = new javax.swing.JLabel();
        txtIDQL = new javax.swing.JTextField();
        txtHoTenQL = new javax.swing.JTextField();
        txtDiaChiQL = new javax.swing.JTextField();
        rbtnNamQL = new javax.swing.JRadioButton();
        rbtnNuQL = new javax.swing.JRadioButton();
        lblEmailQL = new javax.swing.JLabel();
        txtEmailQL = new javax.swing.JTextField();
        cboNgayQL = new javax.swing.JComboBox<>();
        cboThangQL = new javax.swing.JComboBox<>();
        cboNamQL = new javax.swing.JComboBox<>();
        lblThongTinQuanLy = new javax.swing.JLabel();
        btnCapNhat = new javax.swing.JButton();
        btnDangXuat = new javax.swing.JButton();
        btnDanhSachQuaHan = new javax.swing.JButton();
        tabDocGia = new javax.swing.JPanel();
        scrDocGia = new javax.swing.JScrollPane();
        tblDocGia = new javax.swing.JTable();
        pnlThongTinDG = new javax.swing.JPanel();
        lblIDDG = new javax.swing.JLabel();
        lblHoTenDG = new javax.swing.JLabel();
        lblPhaiDG = new javax.swing.JLabel();
        rdbNamDG = new javax.swing.JRadioButton();
        txtHoTenDG = new javax.swing.JTextField();
        txtIDDG = new javax.swing.JTextField();
        rdbNuDG = new javax.swing.JRadioButton();
        lblSDTDG = new javax.swing.JLabel();
        lblEmailDG = new javax.swing.JLabel();
        lblDiaChiDG = new javax.swing.JLabel();
        cboNgayDG = new javax.swing.JComboBox<>();
        cboThangDG = new javax.swing.JComboBox<>();
        cboNamDG = new javax.swing.JComboBox<>();
        txtEmailDG = new javax.swing.JTextField();
        txtSDTDG = new javax.swing.JTextField();
        lblNgaySinhDG = new javax.swing.JLabel();
        lblTrangThaiDG = new javax.swing.JLabel();
        txtDiaChiDG = new javax.swing.JTextField();
        ckbDaHuy = new javax.swing.JCheckBox();
        btnThemDG = new javax.swing.JButton();
        btnSuaDG = new javax.swing.JButton();
        btnLamMoiDG = new javax.swing.JButton();
        lblTimKiemDG = new javax.swing.JLabel();
        txtTimKiemDG = new javax.swing.JTextField();
        btnTimKiemDG = new javax.swing.JButton();
        tabTacGia = new javax.swing.JPanel();
        tabbedQuanLyTacGia = new javax.swing.JTabbedPane();
        tabThongTinTG = new javax.swing.JPanel();
        scrThongTinTacGia = new javax.swing.JScrollPane();
        tblTacGia = new javax.swing.JTable();
        lblTimKiemTG = new javax.swing.JLabel();
        txtTimKiemTG = new javax.swing.JTextField();
        btnTimKiemTG = new javax.swing.JButton();
        pnlThongTinTG = new javax.swing.JPanel();
        lblIDTG = new javax.swing.JLabel();
        lblHoTenTG = new javax.swing.JLabel();
        lblPhaiTG = new javax.swing.JLabel();
        lblNgaySinhTG = new javax.swing.JLabel();
        lblDiaChiTG = new javax.swing.JLabel();
        lblEmailTG = new javax.swing.JLabel();
        txtIDTG = new javax.swing.JTextField();
        txtHoTenTG = new javax.swing.JTextField();
        txtDiaChiTG = new javax.swing.JTextField();
        txtEmailTG = new javax.swing.JTextField();
        rdbNamTG = new javax.swing.JRadioButton();
        rdbNuTG = new javax.swing.JRadioButton();
        cboNgayTG = new javax.swing.JComboBox<>();
        cboThangTG = new javax.swing.JComboBox<>();
        cboNamTG = new javax.swing.JComboBox<>();
        btnThemTG = new javax.swing.JButton();
        btnSuaTG = new javax.swing.JButton();
        btnXoaTG = new javax.swing.JButton();
        btnLamMoiTG = new javax.swing.JButton();
        tabSangTac = new javax.swing.JPanel();
        scrSangTac = new javax.swing.JScrollPane();
        tblSangTac = new javax.swing.JTable();
        lblTimKiemST = new javax.swing.JLabel();
        txtTimKiemST = new javax.swing.JTextField();
        btnTimKiemST = new javax.swing.JButton();
        pnlThongTinST = new javax.swing.JPanel();
        lblTacGiaST = new javax.swing.JLabel();
        lblHoTenST = new javax.swing.JLabel();
        lblDauSachST = new javax.swing.JLabel();
        txtHoTenST = new javax.swing.JTextField();
        txtTenSachST = new javax.swing.JTextField();
        lblTenSachST = new javax.swing.JLabel();
        lblThongTinTacGia = new javax.swing.JLabel();
        lblThongTinTacPham = new javax.swing.JLabel();
        cboTacGiaST = new javax.swing.JComboBox<>();
        cboDauSachST = new javax.swing.JComboBox<>();
        btnThemST = new javax.swing.JButton();
        btnXoaST = new javax.swing.JButton();
        btnLamMoiST = new javax.swing.JButton();
        tabNhaXuatBan = new javax.swing.JPanel();
        scrNhaXuatBan = new javax.swing.JScrollPane();
        tblNhaXuatBan = new javax.swing.JTable();
        pnlThongTinNXB = new javax.swing.JPanel();
        lblIDNXB = new javax.swing.JLabel();
        lblTenXNB = new javax.swing.JLabel();
        lblDiaChiNXB = new javax.swing.JLabel();
        lblEmailNXB = new javax.swing.JLabel();
        lblSDTNXB = new javax.swing.JLabel();
        txtIDNXB = new javax.swing.JTextField();
        txtTenNXB = new javax.swing.JTextField();
        txtDiaChiNXB = new javax.swing.JTextField();
        txtEmailNXB = new javax.swing.JTextField();
        txtSDTNXB = new javax.swing.JTextField();
        btnThemNXB = new javax.swing.JButton();
        btnSuaNXB = new javax.swing.JButton();
        btnXoaNXB = new javax.swing.JButton();
        btnLamMoiNXB = new javax.swing.JButton();
        lblTimKiemNXB = new javax.swing.JLabel();
        txtTimKiemNXB = new javax.swing.JTextField();
        btnTimKiemXNB = new javax.swing.JButton();
        tabDauSach = new javax.swing.JPanel();
        scrDauSach = new javax.swing.JScrollPane();
        tblDauSach = new javax.swing.JTable();
        pnlThongTinDS = new javax.swing.JPanel();
        lblIDDS = new javax.swing.JLabel();
        lblTenSach = new javax.swing.JLabel();
        lblTheLoai = new javax.swing.JLabel();
        lblNamXuatBan = new javax.swing.JLabel();
        lblDonGia = new javax.swing.JLabel();
        lblNhaXuatBan = new javax.swing.JLabel();
        txtIDDS = new javax.swing.JTextField();
        txtTenSach = new javax.swing.JTextField();
        txtDonGia = new javax.swing.JTextField();
        cboNhaXuatBanDS = new javax.swing.JComboBox<>();
        txtTheLoai = new javax.swing.JTextField();
        cboNamXuatBan = new javax.swing.JComboBox<>();
        btnThemDS = new javax.swing.JButton();
        btnSuaDS = new javax.swing.JButton();
        btnXoaDS = new javax.swing.JButton();
        btnLamMoiDS = new javax.swing.JButton();
        lblTimKiemDS = new javax.swing.JLabel();
        txtTimKiemDS = new javax.swing.JTextField();
        btnTimKiemDS = new javax.swing.JButton();
        tabTuSach = new javax.swing.JPanel();
        scrKe = new javax.swing.JScrollPane();
        tblKe = new javax.swing.JTable();
        scrNgan = new javax.swing.JScrollPane();
        tblNgan = new javax.swing.JTable();
        lblKeSach = new javax.swing.JLabel();
        lblNganSach = new javax.swing.JLabel();
        lblTimKiemK = new javax.swing.JLabel();
        txtTimKiemK = new javax.swing.JTextField();
        btnTimKiemK = new javax.swing.JButton();
        lblTimKiemN = new javax.swing.JLabel();
        txtTimKiemN = new javax.swing.JTextField();
        btnTimKiemN = new javax.swing.JButton();
        btnThemK = new javax.swing.JButton();
        btnXoaK = new javax.swing.JButton();
        btnLamMoiTS = new javax.swing.JButton();
        pnlThongTinTS = new javax.swing.JPanel();
        lblIDNganTS = new javax.swing.JLabel();
        lblThongTinNganSach = new javax.swing.JLabel();
        cboNganTS = new javax.swing.JComboBox<>();
        lblThongTinKeSach = new javax.swing.JLabel();
        lblIDKeTS = new javax.swing.JLabel();
        cboKeTS = new javax.swing.JComboBox<>();
        btnThemTS = new javax.swing.JButton();
        btnXoaTS = new javax.swing.JButton();
        btnThemN = new javax.swing.JButton();
        btnXoaN = new javax.swing.JButton();
        tabCuonSach = new javax.swing.JPanel();
        scrCuonSach = new javax.swing.JScrollPane();
        tblCuonSach = new javax.swing.JTable();
        pnlThongTinCS = new javax.swing.JPanel();
        lblIDCS = new javax.swing.JLabel();
        lblKho = new javax.swing.JLabel();
        lblDichVu = new javax.swing.JLabel();
        txtIDCS = new javax.swing.JTextField();
        lblGiaThanhLy = new javax.swing.JLabel();
        lblNganCS = new javax.swing.JLabel();
        lblDauSachCS = new javax.swing.JLabel();
        lblTrangThaiCS = new javax.swing.JLabel();
        cboNganCS = new javax.swing.JComboBox<>();
        cboDauSachCS = new javax.swing.JComboBox<>();
        cboDichVu = new javax.swing.JComboBox<>();
        txtTrangThaiCS = new javax.swing.JTextField();
        cboKho = new javax.swing.JComboBox<>();
        cboPhieuThanhLyCS = new javax.swing.JComboBox<>();
        lblPhieuThanhLyCS = new javax.swing.JLabel();
        txtGiaThanhLy = new javax.swing.JTextField();
        btnThemCS = new javax.swing.JButton();
        btnSuaCS = new javax.swing.JButton();
        btnLamMoiCS = new javax.swing.JButton();
        lblTimKiemCS = new javax.swing.JLabel();
        txtTimKiemCS = new javax.swing.JTextField();
        btnTimKiemCS = new javax.swing.JButton();
        tabHoaDon = new javax.swing.JPanel();
        tabbedQuanLyHoaDon = new javax.swing.JTabbedPane();
        tabPhieuNhap = new javax.swing.JPanel();
        tabbedPhieuNhap = new javax.swing.JTabbedPane();
        tabThongTinPN = new javax.swing.JPanel();
        scrThongTinPhieuNhap = new javax.swing.JScrollPane();
        tblThongTinPhieuNhap = new javax.swing.JTable();
        lblTimKiemPN = new javax.swing.JLabel();
        txtTimKiemTTPN = new javax.swing.JTextField();
        btnTimKiemTTPN = new javax.swing.JButton();
        pnlThongTinPN = new javax.swing.JPanel();
        lblIDPN = new javax.swing.JLabel();
        lblTTPN = new javax.swing.JLabel();
        lblNgayNhap = new javax.swing.JLabel();
        txtIDPN = new javax.swing.JTextField();
        txtThuThuPN = new javax.swing.JTextField();
        cboNgayPN = new javax.swing.JComboBox<>();
        cboThangPN = new javax.swing.JComboBox<>();
        cboNamPN = new javax.swing.JComboBox<>();
        lblThanhTienPN = new javax.swing.JLabel();
        txtThanhTienPN = new javax.swing.JTextField();
        btnThemPN = new javax.swing.JButton();
        btnXoaPN = new javax.swing.JButton();
        btnLamMoiPN = new javax.swing.JButton();
        tabChiTietPN = new javax.swing.JPanel();
        scrChiTietPhieuNhap = new javax.swing.JScrollPane();
        tblChiTietPhieuNhap = new javax.swing.JTable();
        lblTimKiemCT = new javax.swing.JLabel();
        txtTimKiemCT = new javax.swing.JTextField();
        btnTimKiemCT = new javax.swing.JButton();
        pnlThongTinCT = new javax.swing.JPanel();
        lblIDPhieuNhapCT = new javax.swing.JLabel();
        lblSoLuong = new javax.swing.JLabel();
        lblIDDauSachCT = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        txtTenSachCT = new javax.swing.JTextField();
        lblTenSachCT = new javax.swing.JLabel();
        lblThongTinPhieuNhap = new javax.swing.JLabel();
        lblThongTinDauSach = new javax.swing.JLabel();
        cboPhieuNhapCT = new javax.swing.JComboBox<>();
        cboDauSachCT = new javax.swing.JComboBox<>();
        btnThemCT = new javax.swing.JButton();
        btnXoaCT = new javax.swing.JButton();
        btnLamMoiCT = new javax.swing.JButton();
        tabPhieuThanhLy = new javax.swing.JPanel();
        scrPhieuThanhLy = new javax.swing.JScrollPane();
        tblPhieuThanhLy = new javax.swing.JTable();
        pnlThongTinNXB1 = new javax.swing.JPanel();
        lblIDPTL = new javax.swing.JLabel();
        lblThuThuPTL = new javax.swing.JLabel();
        lblNgayThanhLy = new javax.swing.JLabel();
        txtIDPTL = new javax.swing.JTextField();
        txtThuThuPTL = new javax.swing.JTextField();
        cboNamPTL = new javax.swing.JComboBox<>();
        cboNgayPTL = new javax.swing.JComboBox<>();
        cboThangPTL = new javax.swing.JComboBox<>();
        txtThanhTienPTL = new javax.swing.JTextField();
        lblThanhTienPTL = new javax.swing.JLabel();
        btnThemPTL = new javax.swing.JButton();
        btnXoaPTL = new javax.swing.JButton();
        btnLamMoiPTL = new javax.swing.JButton();
        lblTimKiemPTL = new javax.swing.JLabel();
        txtTimKiemPTL = new javax.swing.JTextField();
        btnTimKiemPTL = new javax.swing.JButton();
        tabLePhi = new javax.swing.JPanel();
        scrLePhi = new javax.swing.JScrollPane();
        tblLePhi = new javax.swing.JTable();
        pnlThongTinLP = new javax.swing.JPanel();
        lblIDLP = new javax.swing.JLabel();
        lblNgayDong = new javax.swing.JLabel();
        lblDocGiaLP = new javax.swing.JLabel();
        lblThuThuLP = new javax.swing.JLabel();
        txtIDLP = new javax.swing.JTextField();
        txtThuThuLP = new javax.swing.JTextField();
        cboNgayLP = new javax.swing.JComboBox<>();
        cboThangLP = new javax.swing.JComboBox<>();
        cboNamLP = new javax.swing.JComboBox<>();
        lblChiPhi = new javax.swing.JLabel();
        txtChiPhi = new javax.swing.JTextField();
        cboDocGiaLP = new javax.swing.JComboBox<>();
        btnThemLP = new javax.swing.JButton();
        btnXoaLP = new javax.swing.JButton();
        btnLamMoiLP = new javax.swing.JButton();
        lblTimKiemLP = new javax.swing.JLabel();
        txtTimKiemLP = new javax.swing.JTextField();
        btnTimKiemLP = new javax.swing.JButton();
        tabPhieuMuon = new javax.swing.JPanel();
        scrPhieuMuon = new javax.swing.JScrollPane();
        tblPhieuMuon = new javax.swing.JTable();
        pnlThongTinPM = new javax.swing.JPanel();
        lblIDPM = new javax.swing.JLabel();
        lblNgayMuon = new javax.swing.JLabel();
        lblDocGiaPM = new javax.swing.JLabel();
        lblThuThuPM = new javax.swing.JLabel();
        txtIDPM = new javax.swing.JTextField();
        txtThuThuPM = new javax.swing.JTextField();
        cboNgayPM = new javax.swing.JComboBox<>();
        cboThangPM = new javax.swing.JComboBox<>();
        cboNamPM = new javax.swing.JComboBox<>();
        cboDocGiaPM = new javax.swing.JComboBox<>();
        lblSachMuon = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txaSachMuon = new javax.swing.JTextArea();
        btnThemPM = new javax.swing.JButton();
        btnLamMoiPM = new javax.swing.JButton();
        lblTimKiemPM = new javax.swing.JLabel();
        txtTimKiemPM = new javax.swing.JTextField();
        btnTimKiemPM = new javax.swing.JButton();
        tabPhieuTra = new javax.swing.JPanel();
        scrPhieuTra = new javax.swing.JScrollPane();
        tblPhieuTra = new javax.swing.JTable();
        pnlThongTinPT = new javax.swing.JPanel();
        lblPhieuMuonPT = new javax.swing.JLabel();
        lblThuThuPT = new javax.swing.JLabel();
        lblCuonSachPT = new javax.swing.JLabel();
        lblTrangThaiPT = new javax.swing.JLabel();
        ckbDaMat = new javax.swing.JCheckBox();
        txtThuThuPT = new javax.swing.JTextField();
        lblNgayQuaHan = new javax.swing.JLabel();
        txtNgayQuaHan = new javax.swing.JTextField();
        lblGiaHan = new javax.swing.JLabel();
        ckbGiaHan = new javax.swing.JCheckBox();
        lblNgayTra = new javax.swing.JLabel();
        cboNgayPT = new javax.swing.JComboBox<>();
        cboThangPT = new javax.swing.JComboBox<>();
        cboNamPT = new javax.swing.JComboBox<>();
        txtPhieuMuonPT = new javax.swing.JTextField();
        txtCuonSachPT = new javax.swing.JTextField();
        btnSuaPT = new javax.swing.JButton();
        btnXoaPT = new javax.swing.JButton();
        btnLamMoiPT = new javax.swing.JButton();
        lblTimKiemPT = new javax.swing.JLabel();
        txtTimKiemPT = new javax.swing.JTextField();
        btnTimKiemPT = new javax.swing.JButton();
        tabPhieuPhat = new javax.swing.JPanel();
        scrPhieuPhat = new javax.swing.JScrollPane();
        tblPhieuPhat = new javax.swing.JTable();
        pnlThongTinPP = new javax.swing.JPanel();
        lblIDPP = new javax.swing.JLabel();
        txtThuThuPP = new javax.swing.JTextField();
        txtIDPP = new javax.swing.JTextField();
        lblXuPhat = new javax.swing.JLabel();
        lblLyDo = new javax.swing.JLabel();
        lblDocGiaPP = new javax.swing.JLabel();
        cboNgayPP = new javax.swing.JComboBox<>();
        cboThangPP = new javax.swing.JComboBox<>();
        cboNamPP = new javax.swing.JComboBox<>();
        txtLyDo = new javax.swing.JTextField();
        txtXuPhat = new javax.swing.JTextField();
        lblNgayLap = new javax.swing.JLabel();
        lblThuThuPP = new javax.swing.JLabel();
        cboDocGiaPP = new javax.swing.JComboBox<>();
        btnThemPP = new javax.swing.JButton();
        btnXoaPP = new javax.swing.JButton();
        btnLamMoiPP = new javax.swing.JButton();
        lblTimKiemPP = new javax.swing.JLabel();
        txtTimKiemPP = new javax.swing.JTextField();
        btnTimKiemPP = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LIBRARY MANAGEMENT");
        setIconImage(this.icon);
        setName("mainFrame"); // NOI18N

        tabbedQuanLy.setBorder(new javax.swing.border.MatteBorder(null));
        tabbedQuanLy.setFont(new java.awt.Font("JetBrains Mono", 1, 12)); // NOI18N

        pnlQuanLy.setBackground(new java.awt.Color(204, 255, 204));
        pnlQuanLy.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        pnlThongTinQuanLy.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinQuanLy.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        pnlThongTinQuanLy.setPreferredSize(new java.awt.Dimension(660, 250));

        lblIDQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDQL.setText("ID");

        lblHoTenQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblHoTenQL.setText("Họ tên");

        lblPhaiQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblPhaiQL.setText("Phái");

        lblNgaySinhQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgaySinhQL.setText("Ngày sinh");

        lblDiaChiQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDiaChiQL.setText("Địa chỉ");

        txtIDQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDQL.setEnabled(false);

        txtHoTenQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtHoTenQL.setEnabled(false);

        txtDiaChiQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        btgPhaiQL.add(rbtnNamQL);
        rbtnNamQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rbtnNamQL.setText("Nam");

        btgPhaiQL.add(rbtnNuQL);
        rbtnNuQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rbtnNuQL.setText("Nữ");

        lblEmailQL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblEmailQL.setText("Email");

        txtEmailQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtEmailQL.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        cboNgayQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayQL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        cboThangQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangQL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        cboNamQL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        javax.swing.GroupLayout pnlThongTinQuanLyLayout = new javax.swing.GroupLayout(pnlThongTinQuanLy);
        pnlThongTinQuanLy.setLayout(pnlThongTinQuanLyLayout);
        pnlThongTinQuanLyLayout.setHorizontalGroup(
            pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinQuanLyLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblIDQL, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblHoTenQL, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPhaiQL, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlThongTinQuanLyLayout.createSequentialGroup()
                        .addComponent(rbtnNamQL, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rbtnNuQL, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtIDQL, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtHoTenQL))
                .addGap(44, 44, 44)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNgaySinhQL, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChiQL, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmailQL, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDiaChiQL, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEmailQL, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlThongTinQuanLyLayout.createSequentialGroup()
                        .addComponent(cboNgayQL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangQL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamQL, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pnlThongTinQuanLyLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDiaChiQL, lblEmailQL, lblHoTenQL, lblIDQL, lblNgaySinhQL, lblPhaiQL});

        pnlThongTinQuanLyLayout.setVerticalGroup(
            pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinQuanLyLayout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDQL)
                    .addComponent(txtIDQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgaySinhQL)
                    .addComponent(cboNgayQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblHoTenQL)
                    .addComponent(txtHoTenQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChiQL)
                    .addComponent(txtDiaChiQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblPhaiQL)
                    .addComponent(rbtnNamQL)
                    .addComponent(rbtnNuQL)
                    .addComponent(lblEmailQL)
                    .addComponent(txtEmailQL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(71, Short.MAX_VALUE))
        );

        pnlThongTinQuanLyLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboNamQL, cboNgayQL, cboThangQL, lblEmailQL, lblIDQL, lblNgaySinhQL, lblPhaiQL, rbtnNamQL, rbtnNuQL, txtEmailQL, txtIDQL});

        pnlThongTinQuanLyLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDiaChiQL, lblHoTenQL, txtDiaChiQL, txtHoTenQL});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamQL.addItem(String.valueOf(i));
        }

        lblThongTinQuanLy.setFont(new java.awt.Font("Cambria Math", 1, 24)); // NOI18N
        lblThongTinQuanLy.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblThongTinQuanLy.setText("THÔNG TIN CÁ NHÂN QUẢN LÝ");

        btnCapNhat.setBackground(new java.awt.Color(255, 255, 153));
        btnCapNhat.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        btnCapNhat.setText("Cập nhật");
        btnCapNhat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapNhatActionPerformed(evt);
            }
        });

        btnDangXuat.setBackground(new java.awt.Color(255, 153, 153));
        btnDangXuat.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        btnDangXuat.setText("Đăng xuất");
        btnDangXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDangXuatActionPerformed(evt);
            }
        });

        btnDanhSachQuaHan.setBackground(new java.awt.Color(204, 255, 255));
        btnDanhSachQuaHan.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        btnDanhSachQuaHan.setText("Danh sách quá hạn");
        btnDanhSachQuaHan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDanhSachQuaHanActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlQuanLyLayout = new javax.swing.GroupLayout(pnlQuanLy);
        pnlQuanLy.setLayout(pnlQuanLyLayout);
        pnlQuanLyLayout.setHorizontalGroup(
            pnlQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlQuanLyLayout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addGroup(pnlQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lblThongTinQuanLy, javax.swing.GroupLayout.PREFERRED_SIZE, 662, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(pnlQuanLyLayout.createSequentialGroup()
                            .addComponent(btnCapNhat)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnDanhSachQuaHan)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnDangXuat))
                        .addComponent(pnlThongTinQuanLy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(66, Short.MAX_VALUE))
        );

        pnlQuanLyLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCapNhat, btnDangXuat});

        pnlQuanLyLayout.setVerticalGroup(
            pnlQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlQuanLyLayout.createSequentialGroup()
                .addContainerGap(137, Short.MAX_VALUE)
                .addComponent(lblThongTinQuanLy, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinQuanLy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnlQuanLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnCapNhat)
                    .addComponent(btnDanhSachQuaHan)
                    .addComponent(btnDangXuat))
                .addContainerGap(138, Short.MAX_VALUE))
        );

        pnlQuanLyLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnCapNhat, btnDangXuat, btnDanhSachQuaHan});

        tabbedQuanLy.addTab("Quản lý", pnlQuanLy);

        tabDocGia.setBackground(new java.awt.Color(204, 255, 204));
        tabDocGia.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblDocGia.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblDocGia.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblDocGia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Họ tên", "Phái", "Ngày sinh", "Địa chỉ", "Email", "Số điện thoại", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDocGia.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblDocGia.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblDocGia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDocGiaMouseClicked(evt);
            }
        });
        scrDocGia.setViewportView(tblDocGia);

        pnlThongTinDG.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinDG.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinDG.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDDG.setText("ID");

        lblHoTenDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblHoTenDG.setText("Họ tên");

        lblPhaiDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblPhaiDG.setText("Phái");

        btgPhaiDG.add(rdbNamDG);
        rdbNamDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdbNamDG.setText("Nam");

        txtHoTenDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtHoTenDG.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHoTenDGKeyPressed(evt);
            }
        });

        txtIDDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDDG.setEnabled(false);

        btgPhaiDG.add(rdbNuDG);
        rdbNuDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdbNuDG.setText("Nữ");

        lblSDTDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblSDTDG.setText("Số điện thoại");

        lblEmailDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblEmailDG.setText("Email");

        lblDiaChiDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDiaChiDG.setText("Địa chỉ");

        cboNgayDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayDG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayDG.setSelectedIndex(-1);

        cboThangDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangDG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangDG.setSelectedIndex(-1);

        cboNamDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtEmailDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtSDTDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtSDTDG.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSDTDGKeyPressed(evt);
            }
        });

        lblNgaySinhDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgaySinhDG.setText("Ngày sinh");

        lblTrangThaiDG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTrangThaiDG.setText("Trạng thái");

        txtDiaChiDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        ckbDaHuy.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        ckbDaHuy.setSelected(true);
        ckbDaHuy.setText("Đã hủy");
        ckbDaHuy.setEnabled(false);
        ckbDaHuy.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        javax.swing.GroupLayout pnlThongTinDGLayout = new javax.swing.GroupLayout(pnlThongTinDG);
        pnlThongTinDG.setLayout(pnlThongTinDGLayout);
        pnlThongTinDGLayout.setHorizontalGroup(
            pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinDGLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNgaySinhDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblPhaiDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHoTenDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDDG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtIDDG, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                        .addComponent(txtHoTenDG)
                        .addGroup(pnlThongTinDGLayout.createSequentialGroup()
                            .addComponent(rdbNamDG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(rdbNuDG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pnlThongTinDGLayout.createSequentialGroup()
                        .addComponent(cboNgayDG, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangDG, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamDG, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDiaChiDG)
                    .addComponent(lblEmailDG, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSDTDG, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTrangThaiDG, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtEmailDG, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtSDTDG)
                    .addComponent(txtDiaChiDG)
                    .addComponent(ckbDaHuy, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinDGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDiaChiDG, lblEmailDG, lblHoTenDG, lblIDDG, lblNgaySinhDG, lblPhaiDG, lblSDTDG, lblTrangThaiDG});

        pnlThongTinDGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDiaChiDG, txtEmailDG, txtHoTenDG, txtIDDG, txtSDTDG});

        pnlThongTinDGLayout.setVerticalGroup(
            pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinDGLayout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDDG)
                    .addComponent(txtIDDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChiDG)
                    .addComponent(txtDiaChiDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblHoTenDG)
                    .addComponent(txtHoTenDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmailDG)
                    .addComponent(txtEmailDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblPhaiDG)
                    .addComponent(rdbNamDG)
                    .addComponent(rdbNuDG)
                    .addComponent(lblSDTDG)
                    .addComponent(txtSDTDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinDGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblNgaySinhDG)
                    .addComponent(cboNgayDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTrangThaiDG)
                    .addComponent(ckbDaHuy))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pnlThongTinDGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDiaChiDG, lblEmailDG, lblHoTenDG, lblIDDG, lblNgaySinhDG, lblPhaiDG, lblSDTDG, lblTrangThaiDG});

        pnlThongTinDGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtDiaChiDG, txtEmailDG, txtHoTenDG, txtIDDG, txtSDTDG});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamDG.addItem(String.valueOf(i));
        }

        cboNamDG.setSelectedItem(null);

        btnThemDG.setBackground(new java.awt.Color(153, 255, 204));
        btnThemDG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemDG.setText("Thêm");
        btnThemDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDGActionPerformed(evt);
            }
        });

        btnSuaDG.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaDG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaDG.setText("Sửa");
        btnSuaDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDGActionPerformed(evt);
            }
        });

        btnLamMoiDG.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiDG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiDG.setText("Làm mới");
        btnLamMoiDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiDGActionPerformed(evt);
            }
        });

        lblTimKiemDG.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemDG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemDG.setText("Từ khóa:");

        txtTimKiemDG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemDG.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemDGMouseClicked(evt);
            }
        });
        txtTimKiemDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemDGActionPerformed(evt);
            }
        });

        btnTimKiemDG.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemDG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemDG.setText("Tìm kiếm");
        btnTimKiemDG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemDGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabDocGiaLayout = new javax.swing.GroupLayout(tabDocGia);
        tabDocGia.setLayout(tabDocGiaLayout);
        tabDocGiaLayout.setHorizontalGroup(
            tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrDocGia)
            .addGroup(tabDocGiaLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabDocGiaLayout.createSequentialGroup()
                        .addComponent(lblTimKiemDG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemDG, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemDG))
                    .addGroup(tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabDocGiaLayout.createSequentialGroup()
                            .addComponent(btnThemDG)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSuaDG)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiDG))
                        .addComponent(pnlThongTinDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        tabDocGiaLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiDG, btnSuaDG, btnThemDG});

        tabDocGiaLayout.setVerticalGroup(
            tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabDocGiaLayout.createSequentialGroup()
                .addComponent(scrDocGia, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemDG)
                    .addComponent(txtTimKiemDG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemDG))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinDG, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(tabDocGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemDG)
                    .addComponent(btnSuaDG)
                    .addComponent(btnLamMoiDG))
                .addContainerGap())
        );

        tabDocGiaLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiDG, btnSuaDG, btnThemDG});

        tabbedQuanLy.addTab("Độc giả", tabDocGia);

        tabbedQuanLyTacGia.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tabbedQuanLyTacGia.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N

        tabThongTinTG.setBackground(new java.awt.Color(204, 255, 204));
        tabThongTinTG.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblTacGia.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblTacGia.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblTacGia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Họ tên", "Phái", "Ngày sinh", "Địa chỉ", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblTacGia.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblTacGia.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblTacGia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTacGiaMouseClicked(evt);
            }
        });
        scrThongTinTacGia.setViewportView(tblTacGia);

        lblTimKiemTG.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemTG.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemTG.setText("Từ khóa:");

        txtTimKiemTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemTG.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemTGMouseClicked(evt);
            }
        });
        txtTimKiemTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemTGActionPerformed(evt);
            }
        });

        btnTimKiemTG.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemTG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemTG.setText("Tìm kiếm");
        btnTimKiemTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemTGActionPerformed(evt);
            }
        });

        pnlThongTinTG.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinTG.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinTG.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDTG.setText("ID");

        lblHoTenTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblHoTenTG.setText("Họ tên");

        lblPhaiTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblPhaiTG.setText("Phái");

        lblNgaySinhTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgaySinhTG.setText("Ngày sinh");

        lblDiaChiTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDiaChiTG.setText("Địa chỉ");

        lblEmailTG.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblEmailTG.setText("Email");

        txtIDTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDTG.setEnabled(false);

        txtHoTenTG.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtHoTenTG.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtHoTenTGKeyPressed(evt);
            }
        });

        txtDiaChiTG.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        txtEmailTG.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N

        btgPhaiTG.add(rdbNamTG);
        rdbNamTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdbNamTG.setText("Nam");

        btgPhaiTG.add(rdbNuTG);
        rdbNuTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        rdbNuTG.setText("Nữ");

        cboNgayTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayTG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayTG.setSelectedIndex(-1);

        cboThangTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangTG.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangTG.setSelectedIndex(-1);

        cboNamTG.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        javax.swing.GroupLayout pnlThongTinTGLayout = new javax.swing.GroupLayout(pnlThongTinTG);
        pnlThongTinTG.setLayout(pnlThongTinTGLayout);
        pnlThongTinTGLayout.setHorizontalGroup(
            pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinTGLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblPhaiTG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblHoTenTG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDTG, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDTG, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtHoTenTG)
                    .addGroup(pnlThongTinTGLayout.createSequentialGroup()
                        .addComponent(rdbNamTG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rdbNuTG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNgaySinhTG)
                    .addComponent(lblDiaChiTG, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmailTG, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtDiaChiTG, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtEmailTG)
                    .addGroup(pnlThongTinTGLayout.createSequentialGroup()
                        .addComponent(cboNgayTG, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangTG, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamTG, 0, 0, Short.MAX_VALUE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinTGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDiaChiTG, lblEmailTG, lblHoTenTG, lblIDTG, lblNgaySinhTG, lblPhaiTG});

        pnlThongTinTGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDiaChiTG, txtEmailTG, txtHoTenTG, txtIDTG});

        pnlThongTinTGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {rdbNamTG, rdbNuTG});

        pnlThongTinTGLayout.setVerticalGroup(
            pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinTGLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDTG)
                    .addComponent(txtIDTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgaySinhTG)
                    .addComponent(cboNgayTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblHoTenTG)
                    .addComponent(txtHoTenTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChiTG)
                    .addComponent(txtDiaChiTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblPhaiTG)
                    .addComponent(rdbNamTG)
                    .addComponent(rdbNuTG)
                    .addComponent(lblEmailTG)
                    .addComponent(txtEmailTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pnlThongTinTGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboNamTG, cboNgayTG, cboThangTG, rdbNamTG, rdbNuTG, txtDiaChiTG, txtEmailTG, txtHoTenTG, txtIDTG});

        pnlThongTinTGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDiaChiTG, lblEmailTG, lblHoTenTG, lblIDTG, lblNgaySinhTG, lblPhaiTG});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1800; i--) {
            cboNamTG.addItem(String.valueOf(i));
        }

        cboNamTG.setSelectedItem(null);

        btnThemTG.setBackground(new java.awt.Color(153, 255, 204));
        btnThemTG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemTG.setText("Thêm");
        btnThemTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemTGActionPerformed(evt);
            }
        });

        btnSuaTG.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaTG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaTG.setText("Sửa");
        btnSuaTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaTGActionPerformed(evt);
            }
        });

        btnXoaTG.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaTG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaTG.setText("Xóa");
        btnXoaTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaTGActionPerformed(evt);
            }
        });

        btnLamMoiTG.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiTG.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiTG.setText("Làm mới");
        btnLamMoiTG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiTGActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabThongTinTGLayout = new javax.swing.GroupLayout(tabThongTinTG);
        tabThongTinTG.setLayout(tabThongTinTGLayout);
        tabThongTinTGLayout.setHorizontalGroup(
            tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrThongTinTacGia)
            .addGroup(tabThongTinTGLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabThongTinTGLayout.createSequentialGroup()
                            .addComponent(btnThemTG)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSuaTG)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaTG)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiTG))
                        .addComponent(pnlThongTinTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabThongTinTGLayout.createSequentialGroup()
                        .addComponent(lblTimKiemTG, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemTG, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemTG)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabThongTinTGLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiTG, btnSuaTG, btnThemTG, btnXoaTG});

        tabThongTinTGLayout.setVerticalGroup(
            tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabThongTinTGLayout.createSequentialGroup()
                .addComponent(scrThongTinTacGia, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemTG)
                    .addComponent(txtTimKiemTG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemTG))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinTG, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(tabThongTinTGLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemTG)
                    .addComponent(btnSuaTG)
                    .addComponent(btnXoaTG)
                    .addComponent(btnLamMoiTG))
                .addContainerGap())
        );

        tabThongTinTGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemTG, lblTimKiemTG, txtTimKiemTG});

        tabThongTinTGLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiTG, btnSuaTG, btnThemTG, btnXoaTG});

        tabbedQuanLyTacGia.addTab("Thông tin", tabThongTinTG);

        tabSangTac.setBackground(new java.awt.Color(204, 255, 204));
        tabSangTac.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblSangTac.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblSangTac.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblSangTac.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tác giả", "Tác phẩm"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblSangTac.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblSangTac.setEnabled(false);
        tblSangTac.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblSangTac.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblSangTac.setShowGrid(false);
        scrSangTac.setViewportView(tblSangTac);

        lblTimKiemST.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemST.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemST.setText("Từ khóa:");

        txtTimKiemST.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtTimKiemST.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemSTMouseClicked(evt);
            }
        });
        txtTimKiemST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemSTActionPerformed(evt);
            }
        });

        btnTimKiemST.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemST.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemST.setText("Tìm kiếm");
        btnTimKiemST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemSTActionPerformed(evt);
            }
        });

        pnlThongTinST.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinST.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin liên kết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinST.setPreferredSize(new java.awt.Dimension(700, 100));

        lblTacGiaST.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTacGiaST.setText("ID");

        lblHoTenST.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblHoTenST.setText("Họ tên");

        lblDauSachST.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDauSachST.setText("ID");

        txtHoTenST.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtHoTenST.setEnabled(false);

        txtTenSachST.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtTenSachST.setEnabled(false);

        lblTenSachST.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTenSachST.setText("Tên sách");

        lblThongTinTacGia.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinTacGia.setText("Thông tin tác giả");

        lblThongTinTacPham.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinTacPham.setText("Thông tin tác phẩm");

        cboTacGiaST.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        cboTacGiaST.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboTacGiaSTMouseClicked(evt);
            }
        });
        cboTacGiaST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacGiaSTActionPerformed(evt);
            }
        });

        cboDauSachST.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        cboDauSachST.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboDauSachSTMouseClicked(evt);
            }
        });
        cboDauSachST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboDauSachSTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlThongTinSTLayout = new javax.swing.GroupLayout(pnlThongTinST);
        pnlThongTinST.setLayout(pnlThongTinSTLayout);
        pnlThongTinSTLayout.setHorizontalGroup(
            pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinSTLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinSTLayout.createSequentialGroup()
                        .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblHoTenST, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblTacGiaST, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtHoTenST, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(cboTacGiaST, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lblThongTinTacGia))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinSTLayout.createSequentialGroup()
                        .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDauSachST, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTenSachST, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTenSachST, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(cboDauSachST, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lblThongTinTacPham))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinSTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDauSachST, lblHoTenST, lblTacGiaST, lblTenSachST});

        pnlThongTinSTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblThongTinTacGia, lblThongTinTacPham});

        pnlThongTinSTLayout.setVerticalGroup(
            pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinSTLayout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblThongTinTacGia)
                    .addComponent(lblThongTinTacPham))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 19, Short.MAX_VALUE)
                .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTacGiaST)
                    .addComponent(cboTacGiaST, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDauSachST)
                    .addComponent(cboDauSachST, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinSTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblHoTenST)
                    .addComponent(txtHoTenST, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenSachST)
                    .addComponent(txtTenSachST, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pnlThongTinSTLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDauSachST, lblHoTenST, lblTacGiaST, lblTenSachST, txtHoTenST, txtTenSachST});

        pnlThongTinSTLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblThongTinTacGia, lblThongTinTacPham});

        btnThemST.setBackground(new java.awt.Color(153, 255, 204));
        btnThemST.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemST.setText("Thêm");
        btnThemST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemSTActionPerformed(evt);
            }
        });

        btnXoaST.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaST.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaST.setText("Xóa");
        btnXoaST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaSTActionPerformed(evt);
            }
        });

        btnLamMoiST.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiST.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiST.setText("Làm mới");
        btnLamMoiST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiSTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabSangTacLayout = new javax.swing.GroupLayout(tabSangTac);
        tabSangTac.setLayout(tabSangTacLayout);
        tabSangTacLayout.setHorizontalGroup(
            tabSangTacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrSangTac)
            .addGroup(tabSangTacLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabSangTacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, tabSangTacLayout.createSequentialGroup()
                        .addComponent(btnThemST)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnXoaST)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnLamMoiST))
                    .addComponent(pnlThongTinST, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(tabSangTacLayout.createSequentialGroup()
                        .addComponent(lblTimKiemST, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemST, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemST)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        tabSangTacLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiST, btnThemST, btnXoaST});

        tabSangTacLayout.setVerticalGroup(
            tabSangTacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabSangTacLayout.createSequentialGroup()
                .addComponent(scrSangTac, javax.swing.GroupLayout.DEFAULT_SIZE, 298, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabSangTacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemST)
                    .addComponent(txtTimKiemST, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemST))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinST, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(tabSangTacLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemST)
                    .addComponent(btnXoaST)
                    .addComponent(btnLamMoiST))
                .addContainerGap())
        );

        tabSangTacLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiST, btnThemST, btnXoaST});

        tabSangTacLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemST, lblTimKiemST, txtTimKiemST});

        tabbedQuanLyTacGia.addTab("Sáng tác", tabSangTac);

        javax.swing.GroupLayout tabTacGiaLayout = new javax.swing.GroupLayout(tabTacGia);
        tabTacGia.setLayout(tabTacGiaLayout);
        tabTacGiaLayout.setHorizontalGroup(
            tabTacGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLyTacGia)
        );
        tabTacGiaLayout.setVerticalGroup(
            tabTacGiaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLyTacGia)
        );

        tabbedQuanLy.addTab("Tác giả", tabTacGia);

        tabNhaXuatBan.setBackground(new java.awt.Color(204, 255, 204));
        tabNhaXuatBan.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblNhaXuatBan.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblNhaXuatBan.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        tblNhaXuatBan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tên", "Địa chỉ", "Email", "Số điện thoại"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhaXuatBan.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblNhaXuatBan.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblNhaXuatBan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhaXuatBanMouseClicked(evt);
            }
        });
        scrNhaXuatBan.setViewportView(tblNhaXuatBan);

        pnlThongTinNXB.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinNXB.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinNXB.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDNXB.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDNXB.setText("ID");

        lblTenXNB.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTenXNB.setText("Tên");

        lblDiaChiNXB.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDiaChiNXB.setText("Địa chỉ");

        lblEmailNXB.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblEmailNXB.setText("Email");

        lblSDTNXB.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblSDTNXB.setText("Số điện thoại");

        txtIDNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDNXB.setEnabled(false);

        txtTenNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTenNXB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTenNXBKeyPressed(evt);
            }
        });

        txtDiaChiNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtEmailNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtSDTNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtSDTNXB.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSDTNXBKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout pnlThongTinNXBLayout = new javax.swing.GroupLayout(pnlThongTinNXB);
        pnlThongTinNXB.setLayout(pnlThongTinNXBLayout);
        pnlThongTinNXBLayout.setHorizontalGroup(
            pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinNXBLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTenXNB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDNXB, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDNXB, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtTenNXB))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDiaChiNXB)
                    .addComponent(lblEmailNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSDTNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtDiaChiNXB, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtEmailNXB)
                    .addComponent(txtSDTNXB))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinNXBLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDiaChiNXB, lblEmailNXB, lblIDNXB, lblSDTNXB, lblTenXNB});

        pnlThongTinNXBLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtDiaChiNXB, txtEmailNXB, txtIDNXB, txtSDTNXB, txtTenNXB});

        pnlThongTinNXBLayout.setVerticalGroup(
            pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinNXBLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDNXB)
                    .addComponent(txtIDNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDiaChiNXB)
                    .addComponent(txtDiaChiNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTenXNB)
                    .addComponent(txtTenNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblEmailNXB)
                    .addComponent(txtEmailNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinNXBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblSDTNXB)
                    .addComponent(txtSDTNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pnlThongTinNXBLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDiaChiNXB, lblEmailNXB, lblIDNXB, lblSDTNXB, lblTenXNB});

        pnlThongTinNXBLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtDiaChiNXB, txtEmailNXB, txtIDNXB, txtSDTNXB, txtTenNXB});

        btnThemNXB.setBackground(new java.awt.Color(153, 255, 204));
        btnThemNXB.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemNXB.setText("Thêm");
        btnThemNXB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemNXBActionPerformed(evt);
            }
        });

        btnSuaNXB.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaNXB.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaNXB.setText("Sửa");
        btnSuaNXB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaNXBActionPerformed(evt);
            }
        });

        btnXoaNXB.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaNXB.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaNXB.setText("Xóa");
        btnXoaNXB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaNXBActionPerformed(evt);
            }
        });

        btnLamMoiNXB.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiNXB.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiNXB.setText("Làm mới");
        btnLamMoiNXB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiNXBActionPerformed(evt);
            }
        });

        lblTimKiemNXB.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemNXB.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemNXB.setText("Từ khóa:");

        txtTimKiemNXB.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemNXB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemNXBMouseClicked(evt);
            }
        });
        txtTimKiemNXB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemNXBActionPerformed(evt);
            }
        });

        btnTimKiemXNB.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemXNB.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemXNB.setText("Tìm kiếm");
        btnTimKiemXNB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemXNBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabNhaXuatBanLayout = new javax.swing.GroupLayout(tabNhaXuatBan);
        tabNhaXuatBan.setLayout(tabNhaXuatBanLayout);
        tabNhaXuatBanLayout.setHorizontalGroup(
            tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrNhaXuatBan)
            .addGroup(tabNhaXuatBanLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabNhaXuatBanLayout.createSequentialGroup()
                            .addComponent(btnThemNXB)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSuaNXB)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaNXB)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiNXB))
                        .addComponent(pnlThongTinNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabNhaXuatBanLayout.createSequentialGroup()
                        .addComponent(lblTimKiemNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemXNB)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabNhaXuatBanLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiNXB, btnSuaNXB, btnThemNXB, btnXoaNXB});

        tabNhaXuatBanLayout.setVerticalGroup(
            tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabNhaXuatBanLayout.createSequentialGroup()
                .addComponent(scrNhaXuatBan, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemNXB)
                    .addComponent(txtTimKiemNXB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemXNB))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinNXB, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(tabNhaXuatBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemNXB)
                    .addComponent(btnSuaNXB)
                    .addComponent(btnXoaNXB)
                    .addComponent(btnLamMoiNXB))
                .addContainerGap())
        );

        tabNhaXuatBanLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemXNB, lblTimKiemNXB, txtTimKiemNXB});

        tabNhaXuatBanLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiNXB, btnSuaNXB, btnThemNXB, btnXoaNXB});

        tabbedQuanLy.addTab("Nhà xuất bản", tabNhaXuatBan);

        tabDauSach.setBackground(new java.awt.Color(204, 255, 204));
        tabDauSach.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblDauSach.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblDauSach.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblDauSach.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Tên sách", "Thể loại", "Năm xuất bản", "Đơn giá", "Nhà xuất bản"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblDauSach.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblDauSach.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblDauSach.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblDauSachMouseClicked(evt);
            }
        });
        scrDauSach.setViewportView(tblDauSach);

        pnlThongTinDS.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinDS.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinDS.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDDS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDDS.setText("ID");

        lblTenSach.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTenSach.setText("Tên sách");

        lblTheLoai.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTheLoai.setText("Thể loại");

        lblNamXuatBan.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNamXuatBan.setText("Năm xuất bản");

        lblDonGia.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDonGia.setText("Đơn giá");

        lblNhaXuatBan.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNhaXuatBan.setText("Nhà xuất bản");

        txtIDDS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDDS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtIDDSKeyPressed(evt);
            }
        });

        txtTenSach.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtDonGia.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtDonGia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDonGiaKeyPressed(evt);
            }
        });

        cboNhaXuatBanDS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNhaXuatBanDS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboNhaXuatBanDSMouseClicked(evt);
            }
        });

        txtTheLoai.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTheLoai.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtTheLoaiKeyPressed(evt);
            }
        });

        cboNamXuatBan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        javax.swing.GroupLayout pnlThongTinDSLayout = new javax.swing.GroupLayout(pnlThongTinDS);
        pnlThongTinDS.setLayout(pnlThongTinDSLayout);
        pnlThongTinDSLayout.setHorizontalGroup(
            pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinDSLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTheLoai, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblTenSach, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDDS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDDS)
                    .addComponent(txtTenSach)
                    .addComponent(txtTheLoai))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNamXuatBan)
                    .addComponent(lblDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNhaXuatBan, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtDonGia)
                    .addComponent(cboNhaXuatBanDS, 0, 200, Short.MAX_VALUE)
                    .addComponent(cboNamXuatBan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinDSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDonGia, lblIDDS, lblNamXuatBan, lblNhaXuatBan, lblTenSach, lblTheLoai});

        pnlThongTinDSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboNamXuatBan, cboNhaXuatBanDS, txtDonGia, txtIDDS, txtTenSach, txtTheLoai});

        pnlThongTinDSLayout.setVerticalGroup(
            pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinDSLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDDS)
                    .addComponent(txtIDDS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNamXuatBan)
                    .addComponent(cboNamXuatBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTenSach)
                    .addComponent(txtTenSach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDonGia)
                    .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinDSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTheLoai)
                    .addComponent(txtTheLoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNhaXuatBan)
                    .addComponent(cboNhaXuatBanDS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35))
        );

        pnlThongTinDSLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDonGia, lblIDDS, lblNamXuatBan, lblNhaXuatBan, lblTenSach, lblTheLoai});

        pnlThongTinDSLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboNamXuatBan, cboNhaXuatBanDS, txtDonGia, txtIDDS, txtTenSach, txtTheLoai});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1800; i--) {
            cboNamXuatBan.addItem(String.valueOf(i));
        }

        cboNamXuatBan.setSelectedItem(null);

        btnThemDS.setBackground(new java.awt.Color(153, 255, 204));
        btnThemDS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemDS.setText("Thêm");
        btnThemDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemDSActionPerformed(evt);
            }
        });

        btnSuaDS.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaDS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaDS.setText("Sửa");
        btnSuaDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaDSActionPerformed(evt);
            }
        });

        btnXoaDS.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaDS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaDS.setText("Xóa");
        btnXoaDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaDSActionPerformed(evt);
            }
        });

        btnLamMoiDS.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiDS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiDS.setText("Làm mới");
        btnLamMoiDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiDSActionPerformed(evt);
            }
        });

        lblTimKiemDS.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemDS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemDS.setText("Từ khóa:");

        txtTimKiemDS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemDS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemDSMouseClicked(evt);
            }
        });
        txtTimKiemDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemDSActionPerformed(evt);
            }
        });

        btnTimKiemDS.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemDS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemDS.setText("Tìm kiếm");
        btnTimKiemDS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemDSActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabDauSachLayout = new javax.swing.GroupLayout(tabDauSach);
        tabDauSach.setLayout(tabDauSachLayout);
        tabDauSachLayout.setHorizontalGroup(
            tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrDauSach)
            .addGroup(tabDauSachLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabDauSachLayout.createSequentialGroup()
                            .addComponent(btnThemDS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSuaDS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaDS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiDS))
                        .addComponent(pnlThongTinDS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabDauSachLayout.createSequentialGroup()
                        .addComponent(lblTimKiemDS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemDS, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemDS)))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        tabDauSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiDS, btnSuaDS, btnThemDS, btnXoaDS});

        tabDauSachLayout.setVerticalGroup(
            tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabDauSachLayout.createSequentialGroup()
                .addComponent(scrDauSach, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemDS)
                    .addComponent(txtTimKiemDS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemDS))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinDS, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(tabDauSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemDS)
                    .addComponent(btnSuaDS)
                    .addComponent(btnXoaDS)
                    .addComponent(btnLamMoiDS))
                .addContainerGap())
        );

        tabDauSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemDS, lblTimKiemDS, txtTimKiemDS});

        tabDauSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiDS, btnSuaDS, btnThemDS, btnXoaDS});

        tabbedQuanLy.addTab("Đầu sách", tabDauSach);

        tabTuSach.setBackground(new java.awt.Color(204, 255, 204));
        tabTuSach.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblKe.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblKe.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblKe.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblKe.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblKe.setSelectionForeground(new java.awt.Color(51, 51, 51));
        scrKe.setViewportView(tblKe);

        tblNgan.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblNgan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblNgan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Ngăn", "ID Kệ"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNgan.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblNgan.setSelectionForeground(new java.awt.Color(51, 51, 51));
        scrNgan.setViewportView(tblNgan);

        lblKeSach.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        lblKeSach.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblKeSach.setText("KỆ SÁCH");

        lblNganSach.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        lblNganSach.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNganSach.setText("NGĂN SÁCH");

        lblTimKiemK.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemK.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemK.setText("Từ khóa:");

        txtTimKiemK.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtTimKiemK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemKMouseClicked(evt);
            }
        });
        txtTimKiemK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemKActionPerformed(evt);
            }
        });

        btnTimKiemK.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemK.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemK.setText("Tìm kiếm");
        btnTimKiemK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemKActionPerformed(evt);
            }
        });

        lblTimKiemN.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemN.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemN.setText("Từ khóa:");

        txtTimKiemN.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        txtTimKiemN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemNMouseClicked(evt);
            }
        });
        txtTimKiemN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemNActionPerformed(evt);
            }
        });

        btnTimKiemN.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemN.setText("Tìm kiếm");
        btnTimKiemN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemNActionPerformed(evt);
            }
        });

        btnThemK.setBackground(new java.awt.Color(153, 255, 204));
        btnThemK.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemK.setText("Thêm");
        btnThemK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemKActionPerformed(evt);
            }
        });

        btnXoaK.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaK.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaK.setText("Xóa");
        btnXoaK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaKActionPerformed(evt);
            }
        });

        btnLamMoiTS.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiTS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiTS.setText("Làm mới");
        btnLamMoiTS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiTSActionPerformed(evt);
            }
        });

        pnlThongTinTS.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinTS.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin liên kết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinTS.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDNganTS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDNganTS.setText("Ngăn");

        lblThongTinNganSach.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinNganSach.setText("Thông tin ngăn sách");

        cboNganTS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNganTS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboNganTSMouseClicked(evt);
            }
        });
        cboNganTS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboNganTSActionPerformed(evt);
            }
        });

        lblThongTinKeSach.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinKeSach.setText("Thông tin kệ sách");

        lblIDKeTS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDKeTS.setText("Kệ");

        cboKeTS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboKeTS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboKeTSMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlThongTinTSLayout = new javax.swing.GroupLayout(pnlThongTinTS);
        pnlThongTinTS.setLayout(pnlThongTinTSLayout);
        pnlThongTinTSLayout.setHorizontalGroup(
            pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinTSLayout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblThongTinNganSach)
                    .addGroup(pnlThongTinTSLayout.createSequentialGroup()
                        .addComponent(lblIDNganTS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNganTS, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(70, 70, 70)
                .addGroup(pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinTSLayout.createSequentialGroup()
                        .addComponent(lblIDKeTS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboKeTS, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblThongTinKeSach))
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pnlThongTinTSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblThongTinKeSach, lblThongTinNganSach});

        pnlThongTinTSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblIDKeTS, lblIDNganTS});

        pnlThongTinTSLayout.setVerticalGroup(
            pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinTSLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblThongTinNganSach)
                    .addComponent(lblThongTinKeSach))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlThongTinTSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDNganTS)
                    .addComponent(cboNganTS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIDKeTS)
                    .addComponent(cboKeTS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        pnlThongTinTSLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblThongTinKeSach, lblThongTinNganSach});

        pnlThongTinTSLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboKeTS, cboNganTS, lblIDKeTS, lblIDNganTS});

        btnThemTS.setBackground(new java.awt.Color(153, 255, 204));
        btnThemTS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemTS.setText("Thêm");
        btnThemTS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemTSActionPerformed(evt);
            }
        });

        btnXoaTS.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaTS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaTS.setText("Xóa");
        btnXoaTS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaTSActionPerformed(evt);
            }
        });

        btnThemN.setBackground(new java.awt.Color(153, 255, 204));
        btnThemN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemN.setText("Thêm");
        btnThemN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemNActionPerformed(evt);
            }
        });

        btnXoaN.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaN.setText("Xóa");
        btnXoaN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabTuSachLayout = new javax.swing.GroupLayout(tabTuSach);
        tabTuSach.setLayout(tabTuSachLayout);
        tabTuSachLayout.setHorizontalGroup(
            tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabTuSachLayout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(tabTuSachLayout.createSequentialGroup()
                        .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(scrKe, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(tabTuSachLayout.createSequentialGroup()
                                    .addComponent(lblTimKiemK, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(tabTuSachLayout.createSequentialGroup()
                                            .addComponent(btnThemK)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(btnXoaK))
                                        .addComponent(txtTimKiemK, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnTimKiemK)))
                            .addComponent(lblKeSach, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(scrNgan, javax.swing.GroupLayout.DEFAULT_SIZE, 368, Short.MAX_VALUE)
                                .addComponent(lblNganSach, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(tabTuSachLayout.createSequentialGroup()
                                .addComponent(lblTimKiemN, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtTimKiemN, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(tabTuSachLayout.createSequentialGroup()
                                        .addComponent(btnThemN)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnXoaN)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTimKiemN))))
                    .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(tabTuSachLayout.createSequentialGroup()
                            .addComponent(btnThemTS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaTS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiTS))
                        .addComponent(pnlThongTinTS, javax.swing.GroupLayout.PREFERRED_SIZE, 754, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtTimKiemK, txtTimKiemN});

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnTimKiemK, btnTimKiemN});

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiTS, btnThemK, btnThemN, btnThemTS, btnXoaK, btnXoaN, btnXoaTS});

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {scrKe, scrNgan});

        tabTuSachLayout.setVerticalGroup(
            tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabTuSachLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblKeSach, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNganSach, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(scrKe, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                    .addComponent(scrNgan, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemK)
                    .addComponent(txtTimKiemK, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemK)
                    .addComponent(lblTimKiemN)
                    .addComponent(txtTimKiemN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemK)
                    .addComponent(btnXoaK)
                    .addComponent(btnThemN)
                    .addComponent(btnXoaN))
                .addGap(65, 65, 65)
                .addComponent(pnlThongTinTS, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addGroup(tabTuSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemTS)
                    .addComponent(btnXoaTS)
                    .addComponent(btnLamMoiTS))
                .addContainerGap())
        );

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemK, btnTimKiemN, lblTimKiemK, lblTimKiemN, txtTimKiemK, txtTimKiemN});

        tabTuSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiTS, btnThemK, btnThemN, btnThemTS, btnXoaK, btnXoaN, btnXoaTS});

        tabbedQuanLy.addTab("Tủ sách", tabTuSach);

        tabCuonSach.setBackground(new java.awt.Color(204, 255, 204));
        tabCuonSach.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblCuonSach.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblCuonSach.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblCuonSach.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Khổ", "Dịch vụ", "Đầu sách", "Ngăn", "Phiếu thanh lý", "Giá thanh lý", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblCuonSach.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblCuonSach.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblCuonSach.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCuonSachMouseClicked(evt);
            }
        });
        scrCuonSach.setViewportView(tblCuonSach);

        pnlThongTinCS.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinCS.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinCS.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDCS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDCS.setText("ID");

        lblKho.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblKho.setText("Khổ");

        lblDichVu.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDichVu.setText("Dịch vụ");

        txtIDCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDCS.setEnabled(false);

        lblGiaThanhLy.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblGiaThanhLy.setText("Giá thanh lý");

        lblNganCS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNganCS.setText("Ngăn");

        lblDauSachCS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDauSachCS.setText("Đầu sách");

        lblTrangThaiCS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTrangThaiCS.setText("Trạng thái");

        cboNganCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNganCS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboNganCSMouseClicked(evt);
            }
        });

        cboDauSachCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDauSachCS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboDauSachCSMouseClicked(evt);
            }
        });

        cboDichVu.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDichVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Được mượn", "Đọc tại chỗ", "Trưng bày" }));
        cboDichVu.setSelectedIndex(-1);
        cboDichVu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboDichVuMouseClicked(evt);
            }
        });

        txtTrangThaiCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTrangThaiCS.setEnabled(false);

        cboKho.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboKho.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nhỏ", "Vừa", "Lớn" }));
        cboKho.setSelectedIndex(-1);
        cboKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboKhoMouseClicked(evt);
            }
        });

        cboPhieuThanhLyCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboPhieuThanhLyCS.setEnabled(false);
        cboPhieuThanhLyCS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboPhieuThanhLyCSMouseClicked(evt);
            }
        });
        cboPhieuThanhLyCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPhieuThanhLyCSActionPerformed(evt);
            }
        });

        lblPhieuThanhLyCS.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblPhieuThanhLyCS.setText("Phiếu thanh lý");

        txtGiaThanhLy.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtGiaThanhLy.setEnabled(false);
        txtGiaThanhLy.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtGiaThanhLyKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout pnlThongTinCSLayout = new javax.swing.GroupLayout(pnlThongTinCS);
        pnlThongTinCS.setLayout(pnlThongTinCSLayout);
        pnlThongTinCSLayout.setHorizontalGroup(
            pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinCSLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblDauSachCS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblDichVu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblKho, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDCS, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDCS, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(cboDauSachCS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboDichVu, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboKho, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(59, 59, 59)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblNganCS)
                        .addComponent(lblGiaThanhLy, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblTrangThaiCS, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblPhieuThanhLyCS))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(cboNganCS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTrangThaiCS)
                        .addComponent(cboPhieuThanhLyCS, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(txtGiaThanhLy, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        pnlThongTinCSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDauSachCS, lblDichVu, lblGiaThanhLy, lblIDCS, lblKho, lblNganCS, lblPhieuThanhLyCS, lblTrangThaiCS});

        pnlThongTinCSLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cboDauSachCS, cboDichVu, cboKho, cboNganCS, txtGiaThanhLy, txtIDCS, txtTrangThaiCS});

        pnlThongTinCSLayout.setVerticalGroup(
            pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinCSLayout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDCS)
                    .addComponent(txtIDCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNganCS)
                    .addComponent(cboNganCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblKho)
                    .addComponent(cboKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPhieuThanhLyCS)
                    .addComponent(cboPhieuThanhLyCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblDichVu)
                    .addComponent(cboDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblGiaThanhLy)
                    .addComponent(txtGiaThanhLy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinCSLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblDauSachCS)
                    .addComponent(cboDauSachCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTrangThaiCS)
                    .addComponent(txtTrangThaiCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pnlThongTinCSLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboDauSachCS, cboDichVu, cboKho, cboNganCS, lblDauSachCS, lblDichVu, lblGiaThanhLy, lblIDCS, lblKho, lblNganCS, lblPhieuThanhLyCS, lblTrangThaiCS, txtGiaThanhLy, txtIDCS, txtTrangThaiCS});

        btnThemCS.setBackground(new java.awt.Color(153, 255, 204));
        btnThemCS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemCS.setText("Thêm");
        btnThemCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemCSActionPerformed(evt);
            }
        });

        btnSuaCS.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaCS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaCS.setText("Sửa");
        btnSuaCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaCSActionPerformed(evt);
            }
        });

        btnLamMoiCS.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiCS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiCS.setText("Làm mới");
        btnLamMoiCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiCSActionPerformed(evt);
            }
        });

        lblTimKiemCS.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemCS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemCS.setText("Từ khóa:");

        txtTimKiemCS.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemCS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemCSMouseClicked(evt);
            }
        });
        txtTimKiemCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemCSActionPerformed(evt);
            }
        });

        btnTimKiemCS.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemCS.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemCS.setText("Tìm kiếm");
        btnTimKiemCS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemCSActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabCuonSachLayout = new javax.swing.GroupLayout(tabCuonSach);
        tabCuonSach.setLayout(tabCuonSachLayout);
        tabCuonSachLayout.setHorizontalGroup(
            tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrCuonSach)
            .addGroup(tabCuonSachLayout.createSequentialGroup()
                .addContainerGap(47, Short.MAX_VALUE)
                .addGroup(tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabCuonSachLayout.createSequentialGroup()
                        .addComponent(lblTimKiemCS, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemCS, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemCS))
                    .addGroup(tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabCuonSachLayout.createSequentialGroup()
                            .addComponent(btnThemCS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnSuaCS)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiCS))
                        .addComponent(pnlThongTinCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        tabCuonSachLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiCS, btnSuaCS, btnThemCS});

        tabCuonSachLayout.setVerticalGroup(
            tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabCuonSachLayout.createSequentialGroup()
                .addComponent(scrCuonSach, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemCS)
                    .addComponent(txtTimKiemCS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemCS))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinCS, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(tabCuonSachLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemCS)
                    .addComponent(btnSuaCS)
                    .addComponent(btnLamMoiCS))
                .addContainerGap())
        );

        tabCuonSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiCS, btnSuaCS, btnThemCS});

        tabCuonSachLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemCS, lblTimKiemCS, txtTimKiemCS});

        tabbedQuanLy.addTab("Cuốn sách", tabCuonSach);

        tabbedQuanLyHoaDon.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tabbedQuanLyHoaDon.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N

        tabbedPhieuNhap.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tabbedPhieuNhap.setFont(new java.awt.Font("Times New Roman", 2, 14)); // NOI18N

        tabThongTinPN.setBackground(new java.awt.Color(204, 255, 204));
        tabThongTinPN.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblThongTinPhieuNhap.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblThongTinPhieuNhap.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblThongTinPhieuNhap.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Ngày Nhập", "Thủ thư", "Thành tiền"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblThongTinPhieuNhap.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblThongTinPhieuNhap.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblThongTinPhieuNhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblThongTinPhieuNhapMouseClicked(evt);
            }
        });
        scrThongTinPhieuNhap.setViewportView(tblThongTinPhieuNhap);

        lblTimKiemPN.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemPN.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemPN.setText("Từ khóa:");

        txtTimKiemTTPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemTTPN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemTTPNMouseClicked(evt);
            }
        });
        txtTimKiemTTPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemTTPNActionPerformed(evt);
            }
        });

        btnTimKiemTTPN.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemTTPN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemTTPN.setText("Tìm kiếm");
        btnTimKiemTTPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemTTPNActionPerformed(evt);
            }
        });

        pnlThongTinPN.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinPN.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinPN.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDPN.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDPN.setText("ID");

        lblTTPN.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTTPN.setText("Thủ thư");

        lblNgayNhap.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayNhap.setText("Ngày nhập");

        txtIDPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDPN.setEnabled(false);

        txtThuThuPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuPN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuPNKeyReleased(evt);
            }
        });

        cboNgayPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayPN.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayPN.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
        );

        cboThangPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangPN.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangPN.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        cboNamPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNamPN.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        lblThanhTienPN.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThanhTienPN.setText("Thành tiền");

        txtThanhTienPN.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThanhTienPN.setEnabled(false);

        javax.swing.GroupLayout pnlThongTinPNLayout = new javax.swing.GroupLayout(pnlThongTinPN);
        pnlThongTinPN.setLayout(pnlThongTinPNLayout);
        pnlThongTinPNLayout.setHorizontalGroup(
            pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPNLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblTTPN, javax.swing.GroupLayout.PREFERRED_SIZE, 34, Short.MAX_VALUE)
                    .addComponent(lblIDPN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDPN)
                    .addComponent(txtThuThuPN, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNgayNhap, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(lblThanhTienPN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlThongTinPNLayout.createSequentialGroup()
                        .addComponent(cboNgayPN, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangPN, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamPN, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtThanhTienPN))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinPNLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblIDPN, lblNgayNhap, lblTTPN, lblThanhTienPN});

        pnlThongTinPNLayout.setVerticalGroup(
            pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinPNLayout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDPN)
                    .addComponent(txtIDPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgayNhap)
                    .addComponent(cboNgayPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTTPN)
                    .addComponent(txtThuThuPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhTienPN)
                    .addComponent(txtThanhTienPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        pnlThongTinPNLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblIDPN, lblNgayNhap, lblTTPN, lblThanhTienPN});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamPN.addItem(String.valueOf(i));
        }

        btnThemPN.setBackground(new java.awt.Color(153, 255, 204));
        btnThemPN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemPN.setText("Thêm");
        btnThemPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemPNActionPerformed(evt);
            }
        });

        btnXoaPN.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaPN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaPN.setText("Xóa");
        btnXoaPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaPNActionPerformed(evt);
            }
        });

        btnLamMoiPN.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiPN.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiPN.setText("Làm mới");
        btnLamMoiPN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiPNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabThongTinPNLayout = new javax.swing.GroupLayout(tabThongTinPN);
        tabThongTinPN.setLayout(tabThongTinPNLayout);
        tabThongTinPNLayout.setHorizontalGroup(
            tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabThongTinPNLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabThongTinPNLayout.createSequentialGroup()
                            .addComponent(btnThemPN)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaPN)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiPN))
                        .addComponent(pnlThongTinPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabThongTinPNLayout.createSequentialGroup()
                        .addComponent(lblTimKiemPN, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemTTPN, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemTTPN)))
                .addContainerGap(43, Short.MAX_VALUE))
            .addComponent(scrThongTinPhieuNhap)
        );

        tabThongTinPNLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiPN, btnThemPN, btnXoaPN});

        tabThongTinPNLayout.setVerticalGroup(
            tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabThongTinPNLayout.createSequentialGroup()
                .addComponent(scrThongTinPhieuNhap, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemPN)
                    .addComponent(txtTimKiemTTPN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemTTPN))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinPN, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(tabThongTinPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemPN)
                    .addComponent(btnXoaPN)
                    .addComponent(btnLamMoiPN))
                .addContainerGap())
        );

        tabThongTinPNLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiPN, btnThemPN, btnXoaPN});

        tabThongTinPNLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemTTPN, lblTimKiemPN, txtTimKiemTTPN});

        tabbedPhieuNhap.addTab("Thông tin", tabThongTinPN);

        tabChiTietPN.setBackground(new java.awt.Color(204, 255, 204));
        tabChiTietPN.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblChiTietPhieuNhap.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblChiTietPhieuNhap.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblChiTietPhieuNhap.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Phiếu nhập", "ID Đầu sách", "Số Lượng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblChiTietPhieuNhap.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblChiTietPhieuNhap.setEnabled(false);
        tblChiTietPhieuNhap.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblChiTietPhieuNhap.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblChiTietPhieuNhap.setShowGrid(false);
        scrChiTietPhieuNhap.setViewportView(tblChiTietPhieuNhap);

        lblTimKiemCT.setFont(new java.awt.Font("Cambria Math", 3, 14)); // NOI18N
        lblTimKiemCT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemCT.setText("Từ khóa:");

        txtTimKiemCT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemCTMouseClicked(evt);
            }
        });
        txtTimKiemCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemCTActionPerformed(evt);
            }
        });

        btnTimKiemCT.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemCT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemCT.setText("Tìm kiếm");
        btnTimKiemCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemCTActionPerformed(evt);
            }
        });

        pnlThongTinCT.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinCT.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin liên kết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 14))); // NOI18N
        pnlThongTinCT.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDPhieuNhapCT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDPhieuNhapCT.setText("ID");

        lblSoLuong.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblSoLuong.setText("Số lượng");

        lblIDDauSachCT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDDauSachCT.setText("ID");

        txtSoLuong.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtSoLuong.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSoLuongKeyPressed(evt);
            }
        });

        txtTenSachCT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTenSachCT.setEnabled(false);

        lblTenSachCT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTenSachCT.setText("Tên sách");

        lblThongTinPhieuNhap.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinPhieuNhap.setText("Thông tin phiếu nhập");

        lblThongTinDauSach.setFont(new java.awt.Font("Cambria", 2, 14)); // NOI18N
        lblThongTinDauSach.setText("Thông tin đầu sách");

        cboPhieuNhapCT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboPhieuNhapCT.setSelectedIndex(-1);
        cboPhieuNhapCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboPhieuNhapCTMouseClicked(evt);
            }
        });
        cboPhieuNhapCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboPhieuNhapCTActionPerformed(evt);
            }
        });

        cboDauSachCT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDauSachCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cboDauSachCTMouseClicked(evt);
            }
        });
        cboDauSachCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboDauSachCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnlThongTinCTLayout = new javax.swing.GroupLayout(pnlThongTinCT);
        pnlThongTinCT.setLayout(pnlThongTinCTLayout);
        pnlThongTinCTLayout.setHorizontalGroup(
            pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinCTLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinCTLayout.createSequentialGroup()
                        .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(lblSoLuong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblIDPhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(cboPhieuNhapCT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lblThongTinPhieuNhap))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinCTLayout.createSequentialGroup()
                        .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblIDDauSachCT, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTenSachCT, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTenSachCT, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(cboDauSachCT, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(lblThongTinDauSach))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinCTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblIDDauSachCT, lblIDPhieuNhapCT, lblSoLuong, lblTenSachCT});

        pnlThongTinCTLayout.setVerticalGroup(
            pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinCTLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblThongTinPhieuNhap)
                    .addComponent(lblThongTinDauSach))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, 18, Short.MAX_VALUE)
                .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDPhieuNhapCT)
                    .addComponent(cboPhieuNhapCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblIDDauSachCT)
                    .addComponent(cboDauSachCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinCTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblSoLuong)
                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenSachCT)
                    .addComponent(txtTenSachCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pnlThongTinCTLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblIDDauSachCT, lblIDPhieuNhapCT, lblSoLuong, lblTenSachCT});

        btnThemCT.setBackground(new java.awt.Color(153, 255, 204));
        btnThemCT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemCT.setText("Thêm");
        btnThemCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemCTActionPerformed(evt);
            }
        });

        btnXoaCT.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaCT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaCT.setText("Xóa");
        btnXoaCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaCTActionPerformed(evt);
            }
        });

        btnLamMoiCT.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiCT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiCT.setText("Làm mới");
        btnLamMoiCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiCTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabChiTietPNLayout = new javax.swing.GroupLayout(tabChiTietPN);
        tabChiTietPN.setLayout(tabChiTietPNLayout);
        tabChiTietPNLayout.setHorizontalGroup(
            tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrChiTietPhieuNhap)
            .addGroup(tabChiTietPNLayout.createSequentialGroup()
                .addContainerGap(43, Short.MAX_VALUE)
                .addGroup(tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabChiTietPNLayout.createSequentialGroup()
                            .addComponent(btnThemCT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaCT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiCT))
                        .addComponent(pnlThongTinCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabChiTietPNLayout.createSequentialGroup()
                        .addComponent(lblTimKiemCT, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemCT, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemCT)))
                .addContainerGap(43, Short.MAX_VALUE))
        );

        tabChiTietPNLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiCT, btnThemCT, btnXoaCT});

        tabChiTietPNLayout.setVerticalGroup(
            tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabChiTietPNLayout.createSequentialGroup()
                .addComponent(scrChiTietPhieuNhap, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemCT)
                    .addComponent(txtTimKiemCT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemCT))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinCT, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(tabChiTietPNLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemCT)
                    .addComponent(btnXoaCT)
                    .addComponent(btnLamMoiCT))
                .addContainerGap())
        );

        tabChiTietPNLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiCT, btnThemCT, btnXoaCT});

        tabChiTietPNLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemCT, lblTimKiemCT, txtTimKiemCT});

        tabbedPhieuNhap.addTab("Chi tiết", tabChiTietPN);

        javax.swing.GroupLayout tabPhieuNhapLayout = new javax.swing.GroupLayout(tabPhieuNhap);
        tabPhieuNhap.setLayout(tabPhieuNhapLayout);
        tabPhieuNhapLayout.setHorizontalGroup(
            tabPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPhieuNhap)
        );
        tabPhieuNhapLayout.setVerticalGroup(
            tabPhieuNhapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedPhieuNhap)
        );

        tabbedQuanLyHoaDon.addTab("Phiếu nhập", tabPhieuNhap);

        tabPhieuThanhLy.setBackground(new java.awt.Color(204, 255, 204));
        tabPhieuThanhLy.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblPhieuThanhLy.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblPhieuThanhLy.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblPhieuThanhLy.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Thủ thư", "Ngày thanh lý", "Thành tiền"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPhieuThanhLy.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblPhieuThanhLy.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblPhieuThanhLy.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuThanhLyMouseClicked(evt);
            }
        });
        scrPhieuThanhLy.setViewportView(tblPhieuThanhLy);

        pnlThongTinNXB1.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinNXB1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinNXB1.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDPTL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDPTL.setText("ID");

        lblThuThuPTL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThuThuPTL.setText("Thủ thư");

        lblNgayThanhLy.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayThanhLy.setText("Ngày lập");

        txtIDPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDPTL.setEnabled(false);

        txtThuThuPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuPTL.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuPTLKeyReleased(evt);
            }
        });

        cboNamPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNamPTL.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        cboNgayPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayPTL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayPTL.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)));

        cboThangPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangPTL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangPTL.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        txtThanhTienPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThanhTienPTL.setEnabled(false);

        lblThanhTienPTL.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThanhTienPTL.setText("Thành tiền");

        javax.swing.GroupLayout pnlThongTinNXB1Layout = new javax.swing.GroupLayout(pnlThongTinNXB1);
        pnlThongTinNXB1.setLayout(pnlThongTinNXB1Layout);
        pnlThongTinNXB1Layout.setHorizontalGroup(
            pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinNXB1Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblThuThuPTL, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
                    .addComponent(lblIDPTL, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDPTL, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtThuThuPTL))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNgayThanhLy, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhTienPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlThongTinNXB1Layout.createSequentialGroup()
                        .addComponent(cboNgayPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtThanhTienPTL))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinNXB1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblIDPTL, lblNgayThanhLy, lblThanhTienPTL, lblThuThuPTL});

        pnlThongTinNXB1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {txtIDPTL, txtThanhTienPTL, txtThuThuPTL});

        pnlThongTinNXB1Layout.setVerticalGroup(
            pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinNXB1Layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDPTL)
                    .addComponent(txtIDPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgayThanhLy)
                    .addComponent(cboNgayPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinNXB1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblThuThuPTL)
                    .addComponent(txtThuThuPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhTienPTL)
                    .addComponent(txtThanhTienPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pnlThongTinNXB1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblIDPTL, lblNgayThanhLy, lblThanhTienPTL, lblThuThuPTL});

        pnlThongTinNXB1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {txtIDPTL, txtThanhTienPTL, txtThuThuPTL});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamPTL.addItem(String.valueOf(i));
        }

        btnThemPTL.setBackground(new java.awt.Color(153, 255, 204));
        btnThemPTL.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemPTL.setText("Thêm");
        btnThemPTL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemPTLActionPerformed(evt);
            }
        });

        btnXoaPTL.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaPTL.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaPTL.setText("Xóa");
        btnXoaPTL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaPTLActionPerformed(evt);
            }
        });

        btnLamMoiPTL.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiPTL.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiPTL.setText("Làm mới");
        btnLamMoiPTL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiPTLActionPerformed(evt);
            }
        });

        lblTimKiemPTL.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemPTL.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemPTL.setText("Từ khóa:");

        txtTimKiemPTL.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemPTL.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemPTLMouseClicked(evt);
            }
        });
        txtTimKiemPTL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemPTLActionPerformed(evt);
            }
        });

        btnTimKiemPTL.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemPTL.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemPTL.setText("Tìm kiếm");
        btnTimKiemPTL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemPTLActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabPhieuThanhLyLayout = new javax.swing.GroupLayout(tabPhieuThanhLy);
        tabPhieuThanhLy.setLayout(tabPhieuThanhLyLayout);
        tabPhieuThanhLyLayout.setHorizontalGroup(
            tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuThanhLyLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabPhieuThanhLyLayout.createSequentialGroup()
                            .addComponent(btnThemPTL)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaPTL)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiPTL))
                        .addComponent(pnlThongTinNXB1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabPhieuThanhLyLayout.createSequentialGroup()
                        .addComponent(lblTimKiemPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemPTL, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemPTL)))
                .addContainerGap(45, Short.MAX_VALUE))
            .addComponent(scrPhieuThanhLy)
        );

        tabPhieuThanhLyLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiPTL, btnThemPTL, btnXoaPTL});

        tabPhieuThanhLyLayout.setVerticalGroup(
            tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuThanhLyLayout.createSequentialGroup()
                .addComponent(scrPhieuThanhLy, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemPTL)
                    .addComponent(txtTimKiemPTL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemPTL))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinNXB1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(tabPhieuThanhLyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemPTL)
                    .addComponent(btnXoaPTL)
                    .addComponent(btnLamMoiPTL))
                .addContainerGap())
        );

        tabPhieuThanhLyLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiPTL, btnThemPTL, btnXoaPTL});

        tabPhieuThanhLyLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemPTL, lblTimKiemPTL, txtTimKiemPTL});

        tabbedQuanLyHoaDon.addTab("Phiếu thanh lý", tabPhieuThanhLy);

        tabLePhi.setBackground(new java.awt.Color(204, 255, 204));
        tabLePhi.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblLePhi.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblLePhi.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblLePhi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Độc giả", "Thủ thư", "Chi phí", "Ngày đóng"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblLePhi.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblLePhi.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblLePhi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLePhiMouseClicked(evt);
            }
        });
        scrLePhi.setViewportView(tblLePhi);

        pnlThongTinLP.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinLP.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinLP.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDLP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDLP.setText("ID");

        lblNgayDong.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayDong.setText("Ngày lập");

        lblDocGiaLP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDocGiaLP.setText("Độc giả");

        lblThuThuLP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThuThuLP.setText("Thủ thư");

        txtIDLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDLP.setEnabled(false);

        txtThuThuLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuLP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuLPKeyReleased(evt);
            }
        });

        cboNgayLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayLP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayLP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH)));

        cboThangLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangLP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangLP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        cboNamLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNamLP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        lblChiPhi.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblChiPhi.setText("Chi phí");

        txtChiPhi.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtChiPhi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtChiPhiKeyPressed(evt);
            }
        });

        cboDocGiaLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDocGiaLP.setSelectedIndex(-1);

        javax.swing.GroupLayout pnlThongTinLPLayout = new javax.swing.GroupLayout(pnlThongTinLP);
        pnlThongTinLP.setLayout(pnlThongTinLPLayout);
        pnlThongTinLPLayout.setHorizontalGroup(
            pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinLPLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNgayDong, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDLP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblChiPhi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDLP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnlThongTinLPLayout.createSequentialGroup()
                        .addComponent(cboNgayLP, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangLP, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cboNamLP, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtChiPhi, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDocGiaLP)
                    .addComponent(lblThuThuLP, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtThuThuLP, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(cboDocGiaLP, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinLPLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblChiPhi, lblDocGiaLP, lblIDLP, lblNgayDong, lblThuThuLP});

        pnlThongTinLPLayout.setVerticalGroup(
            pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinLPLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDLP)
                    .addComponent(txtIDLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDocGiaLP)
                    .addComponent(cboDocGiaLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblChiPhi)
                    .addComponent(txtChiPhi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThuThuLP)
                    .addComponent(txtThuThuLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinLPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblNgayDong)
                    .addComponent(cboNgayLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pnlThongTinLPLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblChiPhi, lblDocGiaLP, lblIDLP, lblNgayDong, lblThuThuLP});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamLP.addItem(String.valueOf(i));
        }

        btnThemLP.setBackground(new java.awt.Color(153, 255, 204));
        btnThemLP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemLP.setText("Thêm");
        btnThemLP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemLPActionPerformed(evt);
            }
        });

        btnXoaLP.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaLP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaLP.setText("Xóa");
        btnXoaLP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaLPActionPerformed(evt);
            }
        });

        btnLamMoiLP.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiLP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiLP.setText("Làm mới");
        btnLamMoiLP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiLPActionPerformed(evt);
            }
        });

        lblTimKiemLP.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemLP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemLP.setText("Từ khóa:");

        txtTimKiemLP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemLP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemLPMouseClicked(evt);
            }
        });
        txtTimKiemLP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemLPActionPerformed(evt);
            }
        });

        btnTimKiemLP.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemLP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemLP.setText("Tìm kiếm");
        btnTimKiemLP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemLPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabLePhiLayout = new javax.swing.GroupLayout(tabLePhi);
        tabLePhi.setLayout(tabLePhiLayout);
        tabLePhiLayout.setHorizontalGroup(
            tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrLePhi)
            .addGroup(tabLePhiLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabLePhiLayout.createSequentialGroup()
                            .addComponent(btnThemLP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaLP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiLP))
                        .addComponent(pnlThongTinLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabLePhiLayout.createSequentialGroup()
                        .addComponent(lblTimKiemLP, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemLP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemLP)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        tabLePhiLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiLP, btnThemLP, btnXoaLP});

        tabLePhiLayout.setVerticalGroup(
            tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabLePhiLayout.createSequentialGroup()
                .addComponent(scrLePhi, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemLP)
                    .addComponent(txtTimKiemLP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemLP))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinLP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(tabLePhiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemLP)
                    .addComponent(btnXoaLP)
                    .addComponent(btnLamMoiLP))
                .addContainerGap())
        );

        tabLePhiLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiLP, btnThemLP, btnXoaLP});

        tabLePhiLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemLP, lblTimKiemLP, txtTimKiemLP});

        tabbedQuanLyHoaDon.addTab("Lệ phí", tabLePhi);

        tabPhieuMuon.setBackground(new java.awt.Color(204, 255, 204));
        tabPhieuMuon.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblPhieuMuon.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblPhieuMuon.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblPhieuMuon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Ngày mượn", "Độc giả", "Thủ thư"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPhieuMuon.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblPhieuMuon.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblPhieuMuon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuMuonMouseClicked(evt);
            }
        });
        scrPhieuMuon.setViewportView(tblPhieuMuon);

        pnlThongTinPM.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinPM.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinPM.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDPM.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDPM.setText("ID");

        lblNgayMuon.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayMuon.setText("Ngày lập");

        lblDocGiaPM.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDocGiaPM.setText("Độc giả");

        lblThuThuPM.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThuThuPM.setText("Thủ thư");

        txtIDPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDPM.setEnabled(false);

        txtThuThuPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuPM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuPMKeyReleased(evt);
            }
        });

        cboNgayPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayPM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayPM.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
        );

        cboThangPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangPM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangPM.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        cboNamPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNamPM.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))
        );

        cboDocGiaPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDocGiaPM.setSelectedIndex(-1);

        lblSachMuon.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblSachMuon.setText("Sách mượn");

        txaSachMuon.setColumns(20);
        txaSachMuon.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txaSachMuon.setLineWrap(true);
        txaSachMuon.setRows(3);
        txaSachMuon.setEnabled(false);
        txaSachMuon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txaSachMuonMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(txaSachMuon);

        javax.swing.GroupLayout pnlThongTinPMLayout = new javax.swing.GroupLayout(pnlThongTinPM);
        pnlThongTinPM.setLayout(pnlThongTinPMLayout);
        pnlThongTinPMLayout.setHorizontalGroup(
            pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPMLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblNgayMuon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblIDPM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblSachMuon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDPM)
                    .addGroup(pnlThongTinPMLayout.createSequentialGroup()
                        .addComponent(cboNgayPM, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangPM, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cboNamPM, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblDocGiaPM)
                    .addComponent(lblThuThuPM, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtThuThuPM, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(cboDocGiaPM, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinPMLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDocGiaPM, lblIDPM, lblNgayMuon, lblThuThuPM});

        pnlThongTinPMLayout.setVerticalGroup(
            pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinPMLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDPM)
                    .addComponent(txtIDPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDocGiaPM)
                    .addComponent(cboDocGiaPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblNgayMuon)
                    .addComponent(cboNgayPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThuThuPM)
                    .addComponent(txtThuThuPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPMLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblSachMuon)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pnlThongTinPMLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {lblDocGiaPM, lblIDPM, lblNgayMuon, lblThuThuPM, txtIDPM, txtThuThuPM});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamPM.addItem(String.valueOf(i));
        }

        btnThemPM.setBackground(new java.awt.Color(153, 255, 204));
        btnThemPM.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemPM.setText("Thêm");
        btnThemPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemPMActionPerformed(evt);
            }
        });

        btnLamMoiPM.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiPM.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiPM.setText("Làm mới");
        btnLamMoiPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiPMActionPerformed(evt);
            }
        });

        lblTimKiemPM.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemPM.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemPM.setText("Từ khóa:");

        txtTimKiemPM.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemPM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemPMMouseClicked(evt);
            }
        });
        txtTimKiemPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemPMActionPerformed(evt);
            }
        });

        btnTimKiemPM.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemPM.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemPM.setText("Tìm kiếm");
        btnTimKiemPM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemPMActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabPhieuMuonLayout = new javax.swing.GroupLayout(tabPhieuMuon);
        tabPhieuMuon.setLayout(tabPhieuMuonLayout);
        tabPhieuMuonLayout.setHorizontalGroup(
            tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrPhieuMuon)
            .addGroup(tabPhieuMuonLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabPhieuMuonLayout.createSequentialGroup()
                            .addComponent(btnThemPM)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiPM))
                        .addComponent(pnlThongTinPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabPhieuMuonLayout.createSequentialGroup()
                        .addComponent(lblTimKiemPM, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemPM, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemPM)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        tabPhieuMuonLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiPM, btnThemPM});

        tabPhieuMuonLayout.setVerticalGroup(
            tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuMuonLayout.createSequentialGroup()
                .addComponent(scrPhieuMuon, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemPM)
                    .addComponent(txtTimKiemPM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemPM))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinPM, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(tabPhieuMuonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemPM)
                    .addComponent(btnLamMoiPM))
                .addContainerGap())
        );

        tabPhieuMuonLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiPM, btnThemPM});

        tabPhieuMuonLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemPM, lblTimKiemPM, txtTimKiemPM});

        tabbedQuanLyHoaDon.addTab("Phiếu mượn", tabPhieuMuon);

        tabPhieuTra.setBackground(new java.awt.Color(204, 255, 204));
        tabPhieuTra.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblPhieuTra.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblPhieuTra.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblPhieuTra.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Phiếu mượn", "ID Cuốn sách", "Thủ thư", "Ngày trả", "Ngày quá hạn", "Gia hạn", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPhieuTra.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblPhieuTra.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblPhieuTra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuTraMouseClicked(evt);
            }
        });
        scrPhieuTra.setViewportView(tblPhieuTra);

        pnlThongTinPT.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinPT.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinPT.setPreferredSize(new java.awt.Dimension(700, 100));

        lblPhieuMuonPT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblPhieuMuonPT.setText("Phiếu mượn");

        lblThuThuPT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThuThuPT.setText("Thủ thư");

        lblCuonSachPT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblCuonSachPT.setText("Cuốn sách");

        lblTrangThaiPT.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblTrangThaiPT.setText("Trạng thái");

        ckbDaMat.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        ckbDaMat.setText("Đã mất");
        ckbDaMat.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        txtThuThuPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuPT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtThuThuPTMouseClicked(evt);
            }
        });
        txtThuThuPT.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuPTKeyReleased(evt);
            }
        });

        lblNgayQuaHan.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayQuaHan.setText("Ngày quá hạn");

        txtNgayQuaHan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtNgayQuaHan.setEnabled(false);

        lblGiaHan.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblGiaHan.setText("Gia hạn");

        ckbGiaHan.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        ckbGiaHan.setText("Đã gia hạn");
        ckbGiaHan.setEnabled(false);
        ckbGiaHan.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        lblNgayTra.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayTra.setText("Ngày trả");

        cboNgayPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayPT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayPT.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
        );

        cboThangPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangPT.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangPT.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        cboNamPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtPhieuMuonPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtPhieuMuonPT.setEnabled(false);

        txtCuonSachPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtCuonSachPT.setEnabled(false);

        javax.swing.GroupLayout pnlThongTinPTLayout = new javax.swing.GroupLayout(pnlThongTinPT);
        pnlThongTinPT.setLayout(pnlThongTinPTLayout);
        pnlThongTinPTLayout.setHorizontalGroup(
            pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPTLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblPhieuMuonPT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblCuonSachPT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblThuThuPT, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblGiaHan, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtThuThuPT)
                    .addComponent(ckbGiaHan, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(txtCuonSachPT)
                    .addComponent(txtPhieuMuonPT))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(pnlThongTinPTLayout.createSequentialGroup()
                        .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblTrangThaiPT, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblNgayQuaHan, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ckbDaMat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtNgayQuaHan, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)))
                    .addGroup(pnlThongTinPTLayout.createSequentialGroup()
                        .addComponent(lblNgayTra, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNgayPT, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangPT, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamPT, 0, 0, Short.MAX_VALUE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinPTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblCuonSachPT, lblGiaHan, lblNgayQuaHan, lblNgayTra, lblPhieuMuonPT, lblThuThuPT, lblTrangThaiPT});

        pnlThongTinPTLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {ckbDaMat, ckbGiaHan, txtCuonSachPT, txtNgayQuaHan, txtPhieuMuonPT, txtThuThuPT});

        pnlThongTinPTLayout.setVerticalGroup(
            pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinPTLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblPhieuMuonPT)
                    .addComponent(txtPhieuMuonPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgayTra)
                    .addComponent(cboNgayPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblCuonSachPT)
                    .addComponent(txtCuonSachPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNgayQuaHan)
                    .addComponent(txtNgayQuaHan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblThuThuPT)
                    .addComponent(txtThuThuPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTrangThaiPT)
                    .addComponent(ckbDaMat))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPTLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblGiaHan)
                    .addComponent(ckbGiaHan))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pnlThongTinPTLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {ckbDaMat, ckbGiaHan, lblCuonSachPT, lblGiaHan, lblNgayQuaHan, lblNgayTra, lblPhieuMuonPT, lblThuThuPT, lblTrangThaiPT, txtCuonSachPT, txtNgayQuaHan, txtPhieuMuonPT, txtThuThuPT});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamPT.addItem(String.valueOf(i));
        }

        cboNamPT.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        btnSuaPT.setBackground(new java.awt.Color(255, 255, 153));
        btnSuaPT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnSuaPT.setText("Cập nhật");
        btnSuaPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaPTActionPerformed(evt);
            }
        });

        btnXoaPT.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaPT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaPT.setText("Xóa");
        btnXoaPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaPTActionPerformed(evt);
            }
        });

        btnLamMoiPT.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiPT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiPT.setText("Làm mới");
        btnLamMoiPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiPTActionPerformed(evt);
            }
        });

        lblTimKiemPT.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemPT.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemPT.setText("Từ khóa:");

        txtTimKiemPT.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemPT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemPTMouseClicked(evt);
            }
        });
        txtTimKiemPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemPTActionPerformed(evt);
            }
        });

        btnTimKiemPT.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemPT.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemPT.setText("Tìm kiếm");
        btnTimKiemPT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemPTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabPhieuTraLayout = new javax.swing.GroupLayout(tabPhieuTra);
        tabPhieuTra.setLayout(tabPhieuTraLayout);
        tabPhieuTraLayout.setHorizontalGroup(
            tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrPhieuTra)
            .addGroup(tabPhieuTraLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabPhieuTraLayout.createSequentialGroup()
                            .addComponent(btnSuaPT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaPT)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiPT))
                        .addComponent(pnlThongTinPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(tabPhieuTraLayout.createSequentialGroup()
                        .addComponent(lblTimKiemPT, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemPT, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemPT)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        tabPhieuTraLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiPT, btnSuaPT, btnXoaPT});

        tabPhieuTraLayout.setVerticalGroup(
            tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuTraLayout.createSequentialGroup()
                .addComponent(scrPhieuTra, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemPT)
                    .addComponent(txtTimKiemPT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemPT))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinPT, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(tabPhieuTraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnSuaPT)
                    .addComponent(btnXoaPT)
                    .addComponent(btnLamMoiPT))
                .addContainerGap())
        );

        tabPhieuTraLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiPT, btnSuaPT, btnXoaPT});

        tabPhieuTraLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemPT, lblTimKiemPT, txtTimKiemPT});

        tabbedQuanLyHoaDon.addTab("Phiếu trả", tabPhieuTra);

        tabPhieuPhat.setBackground(new java.awt.Color(204, 255, 204));
        tabPhieuPhat.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));

        tblPhieuPhat.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED));
        tblPhieuPhat.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        tblPhieuPhat.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Độc giả", "Thủ thư", "Ngày lập", "Lý do", "Xử phạt"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblPhieuPhat.setSelectionBackground(new java.awt.Color(204, 255, 255));
        tblPhieuPhat.setSelectionForeground(new java.awt.Color(51, 51, 51));
        tblPhieuPhat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuPhatMouseClicked(evt);
            }
        });
        scrPhieuPhat.setViewportView(tblPhieuPhat);

        pnlThongTinPP.setBackground(new java.awt.Color(204, 255, 204));
        pnlThongTinPP.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED), "Thông tin chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Cambria Math", 1, 14))); // NOI18N
        pnlThongTinPP.setPreferredSize(new java.awt.Dimension(700, 100));

        lblIDPP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblIDPP.setText("ID");

        txtThuThuPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtThuThuPP.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtThuThuPPKeyReleased(evt);
            }
        });

        txtIDPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtIDPP.setEnabled(false);

        lblXuPhat.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblXuPhat.setText("Xử phạt");

        lblLyDo.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblLyDo.setText("Lý do");

        lblDocGiaPP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblDocGiaPP.setText("Độc giả");

        cboNgayPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNgayPP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        cboNgayPP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
        );

        cboThangPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboThangPP.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));
        cboThangPP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.MONTH) + 1));

        cboNamPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboNamPP.setSelectedItem(String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));

        txtLyDo.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        txtXuPhat.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N

        lblNgayLap.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblNgayLap.setText("Ngày lập");

        lblThuThuPP.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        lblThuThuPP.setText("Thủ thư");

        cboDocGiaPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        cboDocGiaPP.setSelectedIndex(-1);

        javax.swing.GroupLayout pnlThongTinPPLayout = new javax.swing.GroupLayout(pnlThongTinPP);
        pnlThongTinPP.setLayout(pnlThongTinPPLayout);
        pnlThongTinPPLayout.setHorizontalGroup(
            pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPPLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(lblNgayLap, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                        .addComponent(lblIDPP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(lblDocGiaPP, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtIDPP)
                    .addGroup(pnlThongTinPPLayout.createSequentialGroup()
                        .addComponent(cboNgayPP, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboThangPP, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboNamPP, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cboDocGiaPP, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(60, 60, 60)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblLyDo, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblXuPhat, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThuThuPP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtLyDo, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                        .addComponent(txtXuPhat))
                    .addComponent(txtThuThuPP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        pnlThongTinPPLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {lblDocGiaPP, lblIDPP, lblLyDo, lblNgayLap, lblThuThuPP, lblXuPhat});

        pnlThongTinPPLayout.setVerticalGroup(
            pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlThongTinPPLayout.createSequentialGroup()
                .addContainerGap(37, Short.MAX_VALUE)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblIDPP)
                    .addComponent(txtIDPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThuThuPP)
                    .addComponent(txtThuThuPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblDocGiaPP)
                    .addComponent(cboDocGiaPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblLyDo)
                    .addComponent(txtLyDo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pnlThongTinPPLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblNgayLap)
                    .addComponent(cboNgayPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboThangPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboNamPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblXuPhat)
                    .addComponent(txtXuPhat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pnlThongTinPPLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cboNamPP, cboNgayPP, cboThangPP, lblDocGiaPP, lblIDPP, lblLyDo, lblNgayLap, lblThuThuPP, lblXuPhat, txtIDPP, txtLyDo, txtThuThuPP, txtXuPhat});

        for (int i = Calendar.getInstance().get(Calendar.YEAR); i >= 1970; i--) {
            cboNamPP.addItem(String.valueOf(i));
        }

        btnThemPP.setBackground(new java.awt.Color(153, 255, 204));
        btnThemPP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnThemPP.setText("Thêm");
        btnThemPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemPPActionPerformed(evt);
            }
        });

        btnXoaPP.setBackground(new java.awt.Color(255, 153, 153));
        btnXoaPP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnXoaPP.setText("Xóa");
        btnXoaPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaPPActionPerformed(evt);
            }
        });

        btnLamMoiPP.setBackground(new java.awt.Color(204, 255, 255));
        btnLamMoiPP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnLamMoiPP.setText("Làm mới");
        btnLamMoiPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiPPActionPerformed(evt);
            }
        });

        lblTimKiemPP.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        lblTimKiemPP.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTimKiemPP.setText("Từ khóa:");

        txtTimKiemPP.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        txtTimKiemPP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtTimKiemPPMouseClicked(evt);
            }
        });
        txtTimKiemPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemPPActionPerformed(evt);
            }
        });

        btnTimKiemPP.setBackground(new java.awt.Color(204, 255, 255));
        btnTimKiemPP.setFont(new java.awt.Font("Cambria Math", 1, 12)); // NOI18N
        btnTimKiemPP.setText("Tìm kiếm");
        btnTimKiemPP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemPPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout tabPhieuPhatLayout = new javax.swing.GroupLayout(tabPhieuPhat);
        tabPhieuPhat.setLayout(tabPhieuPhatLayout);
        tabPhieuPhatLayout.setHorizontalGroup(
            tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuPhatLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabPhieuPhatLayout.createSequentialGroup()
                        .addComponent(lblTimKiemPP, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTimKiemPP, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemPP))
                    .addGroup(tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(tabPhieuPhatLayout.createSequentialGroup()
                            .addComponent(btnThemPP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnXoaPP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnLamMoiPP))
                        .addComponent(pnlThongTinPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
            .addComponent(scrPhieuPhat)
        );

        tabPhieuPhatLayout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnLamMoiPP, btnThemPP, btnXoaPP});

        tabPhieuPhatLayout.setVerticalGroup(
            tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabPhieuPhatLayout.createSequentialGroup()
                .addComponent(scrPhieuPhat, javax.swing.GroupLayout.DEFAULT_SIZE, 247, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblTimKiemPP)
                    .addComponent(txtTimKiemPP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemPP))
                .addGap(18, 18, 18)
                .addComponent(pnlThongTinPP, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 55, Short.MAX_VALUE)
                .addGroup(tabPhieuPhatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(btnThemPP)
                    .addComponent(btnXoaPP)
                    .addComponent(btnLamMoiPP))
                .addContainerGap())
        );

        tabPhieuPhatLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnTimKiemPP, lblTimKiemPP, txtTimKiemPP});

        tabPhieuPhatLayout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {btnLamMoiPP, btnThemPP, btnXoaPP});

        tabbedQuanLyHoaDon.addTab("Phiếu phạt", tabPhieuPhat);

        javax.swing.GroupLayout tabHoaDonLayout = new javax.swing.GroupLayout(tabHoaDon);
        tabHoaDon.setLayout(tabHoaDonLayout);
        tabHoaDonLayout.setHorizontalGroup(
            tabHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLyHoaDon)
        );
        tabHoaDonLayout.setVerticalGroup(
            tabHoaDonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLyHoaDon)
        );

        tabbedQuanLy.addTab("Hóa đơn", tabHoaDon);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLy)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabbedQuanLy, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtTimKiemKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemKActionPerformed
        btnTimKiemK.doClick();
    }//GEN-LAST:event_txtTimKiemKActionPerformed

    private void btnTimKiemKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemKActionPerformed
        String hint = txtTimKiemK.getText().toLowerCase();
        List<Ke> filterList = listKe.stream().filter(e -> e.getiD().contains(hint)).
                collect(Collectors.toList());
        fillToTable(filterList, modelKe);
    }//GEN-LAST:event_btnTimKiemKActionPerformed

    private void btnThemKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemKActionPerformed
        Ke item = new Ke();
        if (sqlKe.insertList(item)) {
            listKe.add(item);
            cboKeTS.addItem(item.getiD());
            btnLamMoiTSActionPerformed(evt);
            JOptionPane.showMessageDialog(rootPane, "Thêm thành công", "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE, this.ico_success);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                    + "Hệ thống đang xảy ra sự cố.",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        }
    }//GEN-LAST:event_btnThemKActionPerformed

    private void btnXoaKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaKActionPerformed
        int index = tblKe.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Ke item = listKe.get(index);
            // Lấy thông tin liên kết.
            boolean linkedN = listNgan.stream().anyMatch(e -> e.getiDKe().equals(item.getiD()));
            // Kiểm tra thông tin liên kết.
            if (linkedN == true) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã được liên kết thông tin.".formatted(item.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlKe.deleteList(item.getiD())) {
                        listKe.remove(index);
                        cboKeTS.removeItemAt(index);
                        btnLamMoiTSActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    tblKe.removeRowSelectionInterval(index, index);
                }
            }
        }
    }//GEN-LAST:event_btnXoaKActionPerformed

    private void txtTimKiemNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemNActionPerformed
        btnTimKiemNActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemNActionPerformed

    private void btnTimKiemNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemNActionPerformed
        String hint = txtTimKiemN.getText().toLowerCase();
        List<Ngan> filterList = listNgan.stream().filter(e -> e.toString().contains(hint)).
                collect(Collectors.toList());
        fillToTable(filterList, modelNgan);
    }//GEN-LAST:event_btnTimKiemNActionPerformed

    private void btnThemNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemNActionPerformed
        Ngan item = new Ngan();
        if (sqlNgan.insertList(item)) {
            listNgan.add(item);
            btnLamMoiTSActionPerformed(evt);
            ///// Thay đổi COMBO BOX ./////
            cboNganTS.addItem(item.getiD());
            cboNganTS.setSelectedItem(null);
            cboNganCS.addItem(item.getiD());
            cboNganCS.setSelectedItem(null);
            ///////////////////////////////
            JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                    "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                    + "Hệ thông đang xảy ra sự cố.",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        }
    }//GEN-LAST:event_btnThemNActionPerformed

    private void btnXoaNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaNActionPerformed
        int index = tblNgan.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Ngan item = listNgan.get(index);
            // Lấy thông tin liên kết.
            boolean linkedCS = listCuonSach.stream().anyMatch(e -> e.getiDNgan().
                    equals(item.getiD()));
            if (linkedCS) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã được liên kết thông tin.".formatted(item.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận?", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlNgan.deleteList(item.getiD())) {
                        listNgan.remove(index);
                        btnLamMoiTSActionPerformed(evt);
                        ///// Thay đổi COMBO BOX ./////
                        cboNganTS.removeItemAt(index);
                        cboNganCS.removeItemAt(index);
                        ///////////////////////////////
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công!",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    tblNgan.removeRowSelectionInterval(index, index);
                }
            }
        }
    }//GEN-LAST:event_btnXoaNActionPerformed

    private void txtTimKiemKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemKMouseClicked
        txtTimKiemK.setText("");
    }//GEN-LAST:event_txtTimKiemKMouseClicked

    private void txtTimKiemNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemNMouseClicked
        txtTimKiemN.setText("");
    }//GEN-LAST:event_txtTimKiemNMouseClicked

    private void btnThemTSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemTSActionPerformed
        if (cboNganTS.getSelectedItem() == null || cboKeTS.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin liên kết!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Ngan itemNgan = listNgan.get(cboNganTS.getSelectedIndex());
            if (!itemNgan.getiDKe().isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "%s đã được liên kết thông tin.".formatted(itemNgan.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                String iDKe = cboKeTS.getSelectedItem().toString();
                if (sqlNgan.updateList(itemNgan.getiD(), iDKe)) {
                    itemNgan.setiDKe(iDKe);
                    btnLamMoiTSActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemTSActionPerformed

    private void btnXoaTSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaTSActionPerformed
        if (cboNganTS.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin ngăn sách!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Ngan itemNgan = listNgan.get(cboNganTS.getSelectedIndex());
            if (itemNgan.getiDKe().isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s chưa dược liên kết.".formatted(itemNgan.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlNgan.updateList(itemNgan.getiD(), "")) {
                        itemNgan.setiDKe("");
                        btnLamMoiTSActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnXoaTSActionPerformed

    private void cboNganTSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboNganTSActionPerformed
        if (cboNganTS.getSelectedItem() != null) {
            Ngan item = listNgan.get(cboNganTS.getSelectedIndex());
            String iDKe = item.getiDKe();
            cboKeTS.setSelectedItem(iDKe.isEmpty() ? null : iDKe);
        } else {
            cboKeTS.setSelectedItem(null);
        }
    }//GEN-LAST:event_cboNganTSActionPerformed

    private void btnLamMoiTSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiTSActionPerformed
        fillToTable(listNgan, modelNgan);
        fillToTable(listKe, modelKe);
        txtTimKiemK.setText("");
        txtTimKiemN.setText("");
        cboNganTS.setSelectedItem(null);
        if (!listKe.isEmpty()) {
            tblKe.removeRowSelectionInterval(0, listKe.size() - 1);
        }
        if (!listNgan.isEmpty()) {
            tblNgan.removeRowSelectionInterval(0, listNgan.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiTSActionPerformed

    private void txtTimKiemDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemDSActionPerformed
        btnTimKiemDSActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemDSActionPerformed

    private void btnTimKiemDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemDSActionPerformed
        String hint = txtTimKiemDS.getText().toLowerCase();
        List<DauSach> filterList = listDauSach.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelDauSach);
    }//GEN-LAST:event_btnTimKiemDSActionPerformed

    private void tblDauSachMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDauSachMouseClicked
        DauSach item = listDauSach.get(tblDauSach.getSelectedRow());
        txtIDDS.setText(item.getiD());
        txtTenSach.setText(item.getTenSach());
        txtTheLoai.setText(item.getTheLoai());
        txtDonGia.setText(String.valueOf(item.getDonGia()));
        cboNamXuatBan.setSelectedItem(String.valueOf(item.getNamXuatBan()));
        cboNhaXuatBanDS.setSelectedItem(item.getIDNhaXuatBan());
    }//GEN-LAST:event_tblDauSachMouseClicked

    private void btnThemDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDSActionPerformed
        if (txtIDDS.getText().length() < 13) {
            JOptionPane.showMessageDialog(rootPane, "ID đầu sách theo ISBN phải có "
                    + "13 ký tự chữ số!", "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtIDDS.requestFocus();
        } else if (txtTenSach.getText().isEmpty() || txtTenSach.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Tên sách không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtTenSach.requestFocus();
        } else if (txtTheLoai.getText().isEmpty() || txtTheLoai.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Thể loại không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtTheLoai.requestFocus();
        } else if (cboNamXuatBan.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Năm xuất bản không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (txtDonGia.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Đơn giá không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtDonGia.requestFocus();
        } else if (cboNhaXuatBanDS.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Nhà xuất bản không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboNhaXuatBanDS.requestFocus();
        } else {
            String iD = txtIDDS.getText();
            String tenSach = txtTenSach.getText().strip().replaceAll(" {2,}", " ");
            String theLoai = txtTheLoai.getText().strip().replaceAll(" {2,}", " ");
            int namXuatBan = Integer.parseInt(cboNamXuatBan.getSelectedItem().toString());
            float donGia = Float.parseFloat(txtDonGia.getText());
            String iDNhaXuatBan = cboNhaXuatBanDS.getSelectedItem().toString();
            // Lấy thông tin định danh.
            boolean checkID_TS = listDauSach.stream().anyMatch((e -> e.getiD().equals(iD)
                    || e.getTenSach().equals(tenSach)));
            // Kiểm tra thông tin định danh.
            if (checkID_TS) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Thông tin định danh đã tồn tại.", "Thông báo lỗi",
                        JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                DauSach item = new DauSach(iD, tenSach, theLoai, donGia, namXuatBan, iDNhaXuatBan);
                if (sqlDauSach.insertList(item)) {
                    listDauSach.add(item);
                    btnLamMoiDSActionPerformed(evt);
                    ///// Thay đổi COMBO BOX ./////
                    cboDauSachCS.addItem(item.getiD());
                    cboDauSachCS.setSelectedItem(null);
                    cboDauSachST.addItem(item.getiD());
                    cboDauSachST.setSelectedItem(null);
                    cboDauSachCT.addItem(item.getiD());
                    cboDauSachCT.setSelectedItem(null);
                    ///////////////////////////////
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemDSActionPerformed

    private void btnXoaDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaDSActionPerformed
        int index = tblDauSach.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            DauSach item = listDauSach.get(index);
            // Lấy thông tin liên kết.
            boolean linkedPN = listChiTietPhieuNhap.stream().map(e -> e.getDanhSach()).anyMatch(e -> {
                return e.stream().anyMatch(ds -> ds.getiDDauSach().equals(item.getiD()));
            });
            boolean linkedST = listSangTac.stream().map(e -> e.getDanhSach()).
                    anyMatch(e -> e.contains(item.getiD()));
            boolean linkedCS = listCuonSach.stream().anyMatch(e -> e.getiDDauSach().
                    equals(item.getiD()));
            // Kiểm tra thông tin liên kết.
            if (linkedPN || linkedST || linkedCS) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã được liên kết thông tin!".formatted(item.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlDauSach.deleteList(item.getiD())) {
                        listDauSach.remove(index);
                        btnLamMoiDSActionPerformed(evt);
                        ///// Thay đổi COMBO BOX ./////
                        cboDauSachCS.removeItem(item.getiD());
                        cboDauSachST.removeItem(item.getiD());
                        cboDauSachCT.removeItem(item.getiD());
                        ///////////////////////////////
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    tblDauSach.removeRowSelectionInterval(index, index);
                }
            }
        }
    }//GEN-LAST:event_btnXoaDSActionPerformed

    private void btnSuaDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDSActionPerformed
        int index = tblDauSach.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            if (txtIDDS.getText().length() < 13) {
                JOptionPane.showMessageDialog(rootPane, "ID đầu sách theo ISBN phải có "
                        + "13 ký tự chữ số!", "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtIDDS.requestFocus();
            } else if (txtTenSach.getText().isEmpty() || txtTenSach.getText().isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Tên sách không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtTenSach.requestFocus();
            } else if (txtTheLoai.getText().isEmpty() || txtTheLoai.getText().isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Thể loại không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtTheLoai.requestFocus();
            } else if (cboNamXuatBan.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Năm xuất bản không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (txtDonGia.getText().isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Đơn giá không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtDonGia.requestFocus();
            } else if (cboNhaXuatBanDS.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Nhà xuất bản không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                cboNhaXuatBanDS.requestFocus();
            } else {
                String iD = txtIDDS.getText();
                String tenSach = txtTenSach.getText().strip().replaceAll(" {2,}", " ");
                String theLoai = txtTheLoai.getText().strip().replaceAll(" {2,}", " ");
                float donGia = Float.parseFloat(txtDonGia.getText());
                int namXuatBan = Integer.parseInt(cboNamXuatBan.getSelectedItem().toString());
                String iDNhaXuatBan = cboNhaXuatBanDS.getSelectedItem().toString();
                // Lấy thông tin định danh.
                boolean checkID = !iD.equals(listDauSach.get(index).getiD())
                        && listDauSach.stream().anyMatch(e -> e.getiD().equals(iD));
                boolean checkTenSach = !tenSach.equals(listDauSach.get(index).getTenSach())
                        && listDauSach.stream().anyMatch(e -> e.getTenSach().equals(tenSach));
                // Kiểm tra thông tin định danh.
                if (checkID || checkTenSach) {
                    JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                            + "Thông tin định danh đã tồn tại.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                } else {
                    int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắn chắn sửa?",
                            "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                            JOptionPane.QUESTION_MESSAGE, this.ico_question);
                    if (choice == JOptionPane.OK_OPTION) {
                        DauSach item = listDauSach.get(index);
                        String oldID = item.getiD(), oldName = item.getTenSach();
                        if (sqlDauSach.updateList(oldID, iD, tenSach, theLoai,
                                donGia, namXuatBan, iDNhaXuatBan)) {
                            item.setiD(iD);
                            item.setTenSach(tenSach);
                            item.setTheLoai(theLoai);
                            item.setNamXuatBan(namXuatBan);
                            item.setDonGia(donGia);
                            item.setIDNhaXuatBan(iDNhaXuatBan);
                            ///// Thay đổi COMBO BOX ./////
                            if (!oldID.equals(item.getiD())) {
                                cboDauSachCS.removeItem(oldID);
                                cboDauSachCS.addItem(iD);
                                cboDauSachCS.setSelectedItem(null);
                                cboDauSachST.removeItem(oldID);
                                cboDauSachST.addItem(iD);
                                cboDauSachST.setSelectedItem(null);
                                cboDauSachCT.removeItem(oldID);
                                cboDauSachCT.addItem(iD);
                                cboDauSachCT.setSelectedItem(null);
                            } else if (!oldName.equals(item.getTenSach())) {
                                cboDauSachCS.setSelectedItem(null);
                                cboDauSachST.setSelectedItem(null);
                                cboDauSachCT.setSelectedItem(null);
                            }
                            ///////////////////////////////
                            btnLamMoiPN.doClick();
                            btnLamMoiDSActionPerformed(evt);
                            JOptionPane.showMessageDialog(rootPane, "Sửa thành công",
                                    "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                                    + "Hệ thống đang xảy ra sự cố.",
                                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                        }
                    } else {
                        tblDauSach.removeRowSelectionInterval(index, index);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaDSActionPerformed

    private void btnLamMoiDSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiDSActionPerformed
        fillToTable(listDauSach, modelDauSach);
        txtTimKiemDS.setText("");
        txtIDDS.setText("");
        txtTenSach.setText("");
        txtTheLoai.setText("");
        txtDonGia.setText("");
        cboNamXuatBan.setSelectedItem(null);
        cboNhaXuatBanDS.setSelectedItem(null);
        if (!listDauSach.isEmpty()) {
            tblDauSach.removeRowSelectionInterval(0, listDauSach.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiDSActionPerformed

    private void tblCuonSachMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCuonSachMouseClicked
        CuonSach item = listCuonSach.get(tblCuonSach.getSelectedRow());
        txtIDCS.setText(item.getiD());
        cboKho.setSelectedItem(item.getKho());
        cboDichVu.setSelectedItem(item.getDichVu());
        cboDauSachCS.setSelectedItem(item.getiDDauSach());
        cboNganCS.setSelectedItem(item.getiDNgan());
        cboPhieuThanhLyCS.setEnabled(true);
        txtTrangThaiCS.setText(item.getTrangThai());
        if (item.getiDPhieuThanhLy().isEmpty()) {
            cboPhieuThanhLyCS.setSelectedItem(null);
            txtGiaThanhLy.setText("");
        } else {
            cboPhieuThanhLyCS.setSelectedItem(item.getiDPhieuThanhLy());
            txtGiaThanhLy.setText(String.valueOf(item.getGiaThanhLy()));
        }
    }//GEN-LAST:event_tblCuonSachMouseClicked

    private void btnThemCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemCSActionPerformed
        // Kiểm tra thông tin cơ bản.
        if (cboKho.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Khổ sách không thể trống",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboKho.requestFocus();
        } else if (cboDichVu.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Dịch vụ sách không thể trống",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboDichVu.requestFocus();
        } else if (cboDauSachCS.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin đầu sách không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboDauSachCS.requestFocus();
        } else if (cboNganCS.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngăn sách không thể trống",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboNganCS.requestFocus();
        } else {
            CuonSach item = new CuonSach(cboKho.getSelectedItem().toString(),
                    cboDichVu.getSelectedItem().toString(),
                    cboDauSachCS.getSelectedItem().toString(),
                    cboNganCS.getSelectedItem().toString());
            // Lấy thông tin số lượng sách đã nhập.
            Optional<Integer> tongSoLuong = listChiTietPhieuNhap.stream().
                    map(e -> e.getDanhSach()).map(e -> {
                Optional<SanPham> tmp = e.stream().filter(s -> s.getiDDauSach().
                        equals(item.getiDDauSach())).findFirst();
                return tmp.isPresent() ? tmp.get().getSoLuong() : 0;
            }).reduce((a, b) -> a + b);
            // Kiểm tra thông tin số lượng sách hiện có.
            if (tongSoLuong.isPresent() && tongSoLuong.get() > 0) {
                int soLuongDaNhap = tongSoLuong.get();
                long soLuongHienCo = listCuonSach.stream().filter(e -> e.getiDDauSach().
                        equals(item.getiDDauSach())).count();
                if (soLuongHienCo < soLuongDaNhap) {
                    if (sqlCuonSach.insertList(item)) {
                        listCuonSach.add(item);
                        btnLamMoiCSActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Số lượng sách của đầu sách %s đã đạt số lượng tối đa là %d.".
                                    formatted(item.getiDDauSach(), soLuongDaNhap),
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Đầu sách %s chưa được nhập.".formatted(item.getiDDauSach()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnThemCSActionPerformed

    private void btnSuaCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaCSActionPerformed
        int index = tblCuonSach.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (!listCuonSach.get(index).getiDPhieuThanhLy().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! Sách đã được thanh lý.",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            CuonSach item = listCuonSach.get(index);
            // Kiểm tra thông tin cơ bản.
            if (cboKho.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Khổ sách không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                cboKho.requestFocus();
            } else if (cboDichVu.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Dịch vụ sách không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                cboDichVu.requestFocus();
            } else if (cboDauSachCS.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin đầu sách không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                cboDauSachCS.requestFocus();
            } else if (cboNganCS.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin sách không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                cboNganCS.requestFocus();
            } else {
                // Lấy thông tin thanh lý.
                String iDPhieuThanhLy = (cboPhieuThanhLyCS.getSelectedItem() == null)
                        ? "" : cboPhieuThanhLyCS.getSelectedItem().toString();
                float giaThanhLy = -1;
                // Kiểm tra thông tin thanh lý.
                if (!iDPhieuThanhLy.isEmpty()) {
                    if (item.getTrangThai().equals("Đã mượn")) {
                        JOptionPane.showMessageDialog(rootPane, "Thanh lý thất bại! "
                                + "%s đang được mượn.".formatted(item.getiD()),
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                        return;
                    }
                    if (txtGiaThanhLy.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(rootPane, "Thanh lý thất bại! "
                                + "Giá thanh lý không thể trống.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                        return;
                    }
                    giaThanhLy = Float.parseFloat(txtGiaThanhLy.getText());
                }
                String kho = cboKho.getSelectedItem().toString();
                String dichVu = cboDichVu.getSelectedItem().toString();
                String iDDauSach = cboDauSachCS.getSelectedItem().toString();
                String iDNgan = cboNganCS.getSelectedItem().toString();
                String trangThai = txtTrangThaiCS.getText();
                // Sửa thông tin
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn sửa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlCuonSach.updateList(item.getiD(), kho, dichVu, iDDauSach,
                            iDNgan, giaThanhLy, iDPhieuThanhLy, trangThai)) {
                        item.setKho(kho);
                        item.setDichVu(dichVu);
                        item.setiDDauSach(iDDauSach);
                        item.setiDNgan(iDNgan);
                        item.setiDPhieuThanhLy(iDPhieuThanhLy);
                        if (!iDPhieuThanhLy.isEmpty()) {
                            item.setGiaThanhLy(giaThanhLy);
                            item.setTrangThai("Đã thanh lý");
                            sqlCuonSach.updateList(item.getiD(), "Đã thanh lý");
                            btnLamMoiPTL.doClick();
                        }
                        btnLamMoiCSActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Sửa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    tblCuonSach.removeRowSelectionInterval(index, index);
                }
            }
        }
    }//GEN-LAST:event_btnSuaCSActionPerformed

    private void btnLamMoiCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiCSActionPerformed
        fillToTable(listCuonSach, modelCuonSach);
        txtIDCS.setText("");
        txtGiaThanhLy.setText("");
        txtTrangThaiCS.setText("");
        cboKho.setSelectedItem(null);
        cboDichVu.setSelectedItem(null);
        cboDauSachCS.setSelectedItem(null);
        cboNganCS.setSelectedItem(null);
        cboPhieuThanhLyCS.setSelectedItem(null);
        cboPhieuThanhLyCS.setEnabled(false);
        txtGiaThanhLy.setEnabled(false);
        if (!listCuonSach.isEmpty()) {
            tblCuonSach.removeRowSelectionInterval(0, listCuonSach.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiCSActionPerformed

    private void txtTimKiemDSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemDSMouseClicked
        txtTimKiemDS.setText("");
    }//GEN-LAST:event_txtTimKiemDSMouseClicked

    private void txtTimKiemCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemCSActionPerformed
        btnTimKiemCSActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemCSActionPerformed

    private void btnTimKiemCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemCSActionPerformed
        String hint = txtTimKiemCS.getText().toLowerCase();
        List<CuonSach> filterList = listCuonSach.stream().filter(e -> e.toString()
                .contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelCuonSach);
    }//GEN-LAST:event_btnTimKiemCSActionPerformed

    private void txtIDDSKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIDDSKeyPressed
        if (txtIDDS.getText().length() < 13 && evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtIDDS.setEditable(true);
        } else {
            txtIDDS.setEditable(false);
        }
    }//GEN-LAST:event_txtIDDSKeyPressed

    private void txtDonGiaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDonGiaKeyPressed
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || (evt.getKeyChar() == '.' && !txtDonGia.getText().isEmpty()
                && !txtDonGia.getText().contains("."))
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtDonGia.setEditable(true);
        } else {
            txtDonGia.setEditable(false);
        }
    }//GEN-LAST:event_txtDonGiaKeyPressed

    private void txtGiaThanhLyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtGiaThanhLyKeyPressed
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || (evt.getKeyChar() == '.' && !txtGiaThanhLy.getText().isEmpty()
                && !txtGiaThanhLy.getText().contains("."))
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtGiaThanhLy.setEditable(true);
        } else {
            txtGiaThanhLy.setEditable(false);
        }
    }//GEN-LAST:event_txtGiaThanhLyKeyPressed

    private void cboNganTSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboNganTSMouseClicked
        cboNganTS.setSelectedItem(null);
    }//GEN-LAST:event_cboNganTSMouseClicked

    private void cboKeTSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboKeTSMouseClicked
        cboKeTS.setSelectedItem(null);
    }//GEN-LAST:event_cboKeTSMouseClicked

    private void cboNhaXuatBanDSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboNhaXuatBanDSMouseClicked
        cboNhaXuatBanDS.setSelectedItem(null);
    }//GEN-LAST:event_cboNhaXuatBanDSMouseClicked

    private void cboKhoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboKhoMouseClicked
        cboKho.setSelectedItem(null);
    }//GEN-LAST:event_cboKhoMouseClicked

    private void cboDichVuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboDichVuMouseClicked
        cboDichVu.setSelectedItem(null);
    }//GEN-LAST:event_cboDichVuMouseClicked

    private void cboDauSachCSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboDauSachCSMouseClicked
        cboDauSachCS.setSelectedItem(null);
    }//GEN-LAST:event_cboDauSachCSMouseClicked

    private void cboNganCSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboNganCSMouseClicked
        cboNganCS.setSelectedItem(null);
    }//GEN-LAST:event_cboNganCSMouseClicked

    private void cboPhieuThanhLyCSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboPhieuThanhLyCSMouseClicked
        cboPhieuThanhLyCS.setSelectedItem(null);
    }//GEN-LAST:event_cboPhieuThanhLyCSMouseClicked

    private void tblPhieuMuonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuMuonMouseClicked
        PhieuMuon item = listPhieuMuon.get(tblPhieuMuon.getSelectedRow());
        txtIDPM.setText(item.getiD());
        cboNgayPM.setSelectedItem(String.valueOf(item.getNgayThucHien().get(Calendar.DAY_OF_MONTH)));
        cboThangPM.setSelectedItem(String.valueOf(item.getNgayThucHien().get(Calendar.MONTH) + 1));
        cboNamPM.setSelectedItem(String.valueOf(item.getNgayThucHien().get(Calendar.YEAR)));
        cboDocGiaPM.setSelectedItem(item.getiDDocGia());
        txtThuThuPM.setText(item.getiDThuThu());
        List<String> dsSachMuon = listPhieuTra.stream().filter(e -> e.getiDPhieuMuon().
                equals(item.getiD())).map(e -> e.getiDCuonSach()).collect(Collectors.toList());
        this.setSachMuon(dsSachMuon);
    }//GEN-LAST:event_tblPhieuMuonMouseClicked

    private void txtTimKiemPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemPMActionPerformed
        btnTimKiemPMActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemPMActionPerformed

    private void btnTimKiemPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemPMActionPerformed
        String hint = txtTimKiemPM.getText().toLowerCase();
        List<PhieuMuon> filterList = listPhieuMuon.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelPhieuMuon);
    }//GEN-LAST:event_btnTimKiemPMActionPerformed

    private void btnThemPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemPMActionPerformed
        if (cboNgayPM.getSelectedItem() == null || cboThangPM.getSelectedItem() == null
                || cboNamPM.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày mượn không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (cboDocGiaPM.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin độc giả không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboDocGiaPM.requestFocus();
        } else if (txtThuThuPM.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPM.requestFocus();
        } else if (!system.isQuanLy(txtThuThuPM.getText(), listThuThu)) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPM.requestFocus();
        } else if (txaSachMuon.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin sách mượn không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txaSachMuon.requestFocus();
        } else {
            Calendar ngayMuon = system.getDate(cboNgayPM.getSelectedItem().toString(),
                    cboThangPM.getSelectedItem().toString(), cboNamPM.getSelectedItem().toString());
            String iDDocGia = cboDocGiaPM.getSelectedItem().toString();
            String iDThuThu = txtThuThuPM.getText();
            String[] dsSachMuon = txaSachMuon.getText().split("\n");
            // Kiểm tra ngày mượn hợp lệ.
            if (ngayMuon.after(Calendar.getInstance())) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Thông tin ngày mượn không hợp lệ.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                return;
            }
            // Kiểm tra thông tin quá hạn.
            if (system.isCoSachQuaHan(iDDocGia, listPhieuMuon, listPhieuTra)) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Độc giả đang có sách quá hạn.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                return;
            }
            // Lấy danh sách phiếu mượn của độc giả.
            List<String> dsPhieuMuon = listPhieuMuon.stream().filter(e -> e.getiDDocGia().
                    equals(iDDocGia)).map(e -> e.getiD()).collect(Collectors.toList());
            // Kiểm tra tổng số sách đã mượn.
            long soLuongSachMuon = listPhieuTra.stream().filter(e -> dsPhieuMuon.
                    contains(e.getiDPhieuMuon()) && e.getiDThuThu().isEmpty()).count();
            if (soLuongSachMuon + dsSachMuon.length > 3) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Độc giả đã đạt số lần mượn tối đa.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                return;
            }
            //Thêm phiếu mượn.
            int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn đã chắc chắn với thông tin?",
                    "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE, this.ico_question);
            if (choice == JOptionPane.OK_OPTION) {
                PhieuMuon itemPM = new PhieuMuon(iDDocGia, iDThuThu, ngayMuon);
                if (sqlPhieuMuon.insertList(itemPM)) {
                    listPhieuMuon.add(itemPM);
                    for (String iDSachMuon : dsSachMuon) {
                        PhieuTra itemPT = new PhieuTra(itemPM.getiD(), iDSachMuon);
                        if (sqlPhieuTra.insertList(itemPT)) {
                            listPhieuTra.add(itemPT);
                            CuonSach itemCS = listCuonSach.stream().filter(e -> e.
                                    getiD().equals(iDSachMuon)).findFirst().get();
                            itemCS.setTrangThai("Đã mượn");
                            sqlCuonSach.updateList(itemCS.getiD(), "Đã mượn");
                        }
                    }
                    btnLamMoiCS.doClick();
                    btnLamMoiPT.doClick();
                    btnLamMoiPMActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemPMActionPerformed

    private void btnLamMoiPMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiPMActionPerformed
        fillToTable(listPhieuMuon, modelPhieuMuon);
        txtTimKiemPM.setText("");
        txtIDPM.setText("");
        txaSachMuon.setText("");
        txtThuThuPM.setText(quanLy.getiD());
        Calendar ngayHienTai = Calendar.getInstance();
        cboNgayPM.setSelectedItem(String.valueOf(ngayHienTai.get(Calendar.DAY_OF_MONTH)));
        cboThangPM.setSelectedItem(String.valueOf(ngayHienTai.get(Calendar.MONTH) + 1));
        cboNamPM.setSelectedItem(String.valueOf(ngayHienTai.get(Calendar.YEAR)));
        cboDocGiaPM.setSelectedItem(null);
        if (!listPhieuMuon.isEmpty()) {
            tblPhieuMuon.removeRowSelectionInterval(0, listPhieuMuon.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiPMActionPerformed

    private void cboPhieuThanhLyCSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPhieuThanhLyCSActionPerformed
        txtGiaThanhLy.setEnabled(cboPhieuThanhLyCS.getSelectedItem() != null);
    }//GEN-LAST:event_cboPhieuThanhLyCSActionPerformed

    private void txtTimKiemNXBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemNXBActionPerformed
        btnTimKiemXNBActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemNXBActionPerformed

    private void btnTimKiemXNBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemXNBActionPerformed
        String hint = txtTimKiemNXB.getText().toLowerCase();
        List<NhaXuatBan> filterList = listNXB.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelNXB);
    }//GEN-LAST:event_btnTimKiemXNBActionPerformed

    private void btnThemNXBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemNXBActionPerformed
        String tenNXB = txtTenNXB.getText().strip().replaceAll(" {2,}", " ");
        String diachiNXB = txtDiaChiNXB.getText().strip().replaceAll(" {2,}", " ");
        String emailNXB = txtEmailNXB.getText().strip().replaceAll(" {2,}", " ");
        String SDTNXB = txtSDTNXB.getText().strip().replaceAll(" {2,}", " ");
        if (tenNXB.isEmpty() || tenNXB.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Tên NXB không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtTenNXB.requestFocus();
        } else if (listNXB.stream().anyMatch(e -> e.getTen().equals(tenNXB))) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin định danh đã tồn tại!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (diachiNXB.isEmpty() || diachiNXB.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtDiaChiNXB.requestFocus();
        } else if (emailNXB.isEmpty() || emailNXB.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailNXB.requestFocus();
        } else if (!emailNXB.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailNXB.requestFocus();
        } else if (SDTNXB.isEmpty() || SDTNXB.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Số điện thoại không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSDTNXB.requestFocus();
        } else if (!SDTNXB.matches("^0.*") || SDTNXB.length() < 10) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin số điện thoại không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSDTNXB.requestFocus();
        } else {
            NhaXuatBan t = new NhaXuatBan(tenNXB, diachiNXB, emailNXB, SDTNXB);
            if (sqlNhaXuatBan.insertList(t)) {
                listNXB.add(t);
                //// Thay đổi COMBO BOX. ////
                cboNhaXuatBanDS.addItem(t.getiD());
                cboNhaXuatBanDS.setSelectedItem(null);
                /////////////////////////////
                btnLamMoiNXBActionPerformed(evt);
                JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                        "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Hệ thống đang xảy ra sự cố.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnThemNXBActionPerformed

    private void btnSuaNXBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaNXBActionPerformed
        int index = tblNhaXuatBan.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            NhaXuatBan t = listNXB.get(index);
            String tenNXB = txtTenNXB.getText().strip().replaceAll(" {2,}", " ");
            String diachiNXB = txtDiaChiNXB.getText().strip().replaceAll(" {2,}", " ");
            String emailNXB = txtEmailNXB.getText().strip().replaceAll(" {2,}", " ");
            String SDTNXB = txtSDTNXB.getText();
            boolean checkChange = !tenNXB.equals(t.getTen());
            if (tenNXB.isEmpty() || tenNXB.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Tên NXB không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtTenNXB.requestFocus();
            } else if (checkChange && listNXB.stream().anyMatch(e -> e.getTen().equals(tenNXB))) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin định danh đã tồn tại!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (diachiNXB.isEmpty() || diachiNXB.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtDiaChiNXB.requestFocus();
            } else if (emailNXB.isEmpty() || emailNXB.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailNXB.requestFocus();
            } else if (!emailNXB.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailNXB.requestFocus();
            } else if (SDTNXB.isEmpty() || SDTNXB.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Số điện thoại không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtSDTNXB.requestFocus();
            } else if (!SDTNXB.matches("^0.*") || SDTNXB.length() < 10) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin số điện thoại không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtSDTNXB.requestFocus();
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn sửa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlNhaXuatBan.updateList(t.getiD(), tenNXB, diachiNXB,
                            emailNXB, SDTNXB)) {
                        t.setTen(tenNXB);
                        t.setDiaChi(diachiNXB);
                        t.setEmail(emailNXB);
                        t.setSdt(SDTNXB);
                        btnLamMoiNXBActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Sửa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaNXBActionPerformed

    private void btnXoaNXBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaNXBActionPerformed
        int index = tblNhaXuatBan.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            NhaXuatBan t = listNXB.get(index);
            if (listDauSach.stream().anyMatch(e -> e.getIDNhaXuatBan().equals(t.getiD()))) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã liên kết thông tin.".formatted(t.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlNhaXuatBan.deleteList(t.getiD())) {
                        listNXB.remove(t);
                        //// Thay đổi COMBO BOX. ////
                        cboNhaXuatBanDS.removeItem(t.getiD());
                        /////////////////////////////
                        btnLamMoiNXBActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnXoaNXBActionPerformed

    private void btnLamMoiNXBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiNXBActionPerformed
        fillToTable(listNXB, modelNXB);
        txtIDNXB.setText("");
        txtTenNXB.setText("");
        txtDiaChiNXB.setText("");
        txtEmailNXB.setText("");
        txtSDTNXB.setText("");
        txtTimKiemNXB.setText("");
    }//GEN-LAST:event_btnLamMoiNXBActionPerformed

    private void tblNhaXuatBanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblNhaXuatBanMouseClicked
        int index = tblNhaXuatBan.getSelectedRow();
        NhaXuatBan t = listNXB.get(index);
        txtIDNXB.setText(t.getiD());
        txtTenNXB.setText(t.getTen());
        txtDiaChiNXB.setText(t.getDiaChi());
        txtEmailNXB.setText(t.getEmail());
        txtSDTNXB.setText(t.getSdt());
    }//GEN-LAST:event_tblNhaXuatBanMouseClicked

    private void txtTenNXBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTenNXBKeyPressed
        txtTenNXB.setEditable(!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'));
    }//GEN-LAST:event_txtTenNXBKeyPressed

    private void txtSDTNXBKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSDTNXBKeyPressed
        if (txtSDTNXB.getText().length() < 10 && evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtSDTNXB.setEditable(true);
        } else {
            txtSDTNXB.setEditable(false);
        }
    }//GEN-LAST:event_txtSDTNXBKeyPressed

    private void txtTimKiemTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemTGActionPerformed
        btnTimKiemTGActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemTGActionPerformed

    private void btnTimKiemTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemTGActionPerformed
        String hint = txtTimKiemTG.getText().toLowerCase();
        List<TacGia> filterList = listTacGia.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelTacGia);
    }//GEN-LAST:event_btnTimKiemTGActionPerformed

    private void btnThemTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemTGActionPerformed
        String hoTenTG = txtHoTenTG.getText().strip().replaceAll(" {2,}", " ");
        String diaChiTG = txtDiaChiTG.getText().strip().replaceAll(" {2,}", " ");
        String emailTG = txtEmailTG.getText().strip().replaceAll(" {2,}", " ");
        String phai = rdbNamTG.isSelected() ? "Nam" : "Nữ";
        if (hoTenTG.isEmpty() || hoTenTG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Họ tên không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtHoTenTG.requestFocus();
        } else if (rdbNamTG.isSelected() == false && rdbNuTG.isSelected() == false) {
            JOptionPane.showMessageDialog(rootPane, "Phái không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (cboNgayTG.getSelectedItem() == null || cboThangTG.getSelectedItem() == null
                || cboNamTG.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày sinh không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (diaChiTG.isEmpty() || diaChiTG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtDiaChiTG.requestFocus();
        } else if (emailTG.isEmpty() || emailTG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailTG.requestFocus();
        } else if (!emailTG.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                    "Thông báo lối", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailNXB.requestFocus();
        } else {
            Calendar ngaySinhTG = system.getDate(cboNgayTG.getSelectedItem().toString(),
                    cboThangTG.getSelectedItem().toString(), cboNamTG.getSelectedItem().toString());
            TacGia t = new TacGia(hoTenTG, phai, ngaySinhTG, diaChiTG, emailTG);
            if (sqlTacGia.insertList(t)) {
                listTacGia.add(t);
                listSangTac.add(new SangTac(t.getiD()));
                //// Thay đổi COMBO BOX. ////
                cboTacGiaST.addItem(t.getiD());
                cboTacGiaST.setSelectedItem(null);
                /////////////////////////////
                btnLamMoiTGActionPerformed(evt);
                JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                        "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Hệ thống đang xảy ra sự cố.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnThemTGActionPerformed

    private void btnSuaTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaTGActionPerformed
        int index = tblTacGia.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            TacGia t = listTacGia.get(index);
            String hoTenTG = txtHoTenTG.getText().strip().replaceAll(" {2,}", " ");
            String diaChiTG = txtDiaChiTG.getText().strip().replaceAll(" {2,}", " ");
            String emailTG = txtEmailTG.getText().strip().replaceAll(" {2,}", " ");
            String phaiTG = rdbNamTG.isSelected() ? "Nam" : "Nữ";
            if (hoTenTG.isEmpty() || hoTenTG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Họ tên không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtHoTenTG.requestFocus();
            } else if (rdbNamTG.isSelected() == false && rdbNuTG.isSelected() == false) {
                JOptionPane.showMessageDialog(rootPane, "Phái không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (cboNgayTG.getSelectedItem() == null || cboThangTG.getSelectedItem() == null
                    || cboNamTG.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin ngày sinh không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (diaChiTG.isEmpty() || diaChiTG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtDiaChiTG.requestFocus();
            } else if (emailTG.isEmpty() || emailTG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailTG.requestFocus();
            } else if (!emailTG.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                        "Thông báo lối", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailNXB.requestFocus();
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn sửa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    Calendar ngaySinhTG = system.getDate(cboNgayTG.getSelectedItem().toString(),
                            cboThangTG.getSelectedItem().toString(), cboNamTG.getSelectedItem().toString());
                    if (sqlTacGia.updateList(t.getiD(), hoTenTG, phaiTG, ngaySinhTG, diaChiTG, emailTG)) {
                        t.setHoTen(hoTenTG);
                        t.setPhai(phaiTG);
                        t.setNgaySinh(ngaySinhTG);
                        t.setEmail(emailTG);
                        t.setDiaChi(diaChiTG);
                        ///// Thay đổi COMBO BOX. ////
                        cboTacGiaST.setSelectedItem(null);
                        /////////////////////////////
                        btnLamMoiTGActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Sửa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaTGActionPerformed

    private void btnXoaTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaTGActionPerformed
        int index = tblTacGia.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            TacGia t = listTacGia.get(index);
            if (listSangTac.stream().anyMatch(e -> e.getiD().equals(t.getiD())
                    && !e.getDanhSach().isEmpty())) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã được liên kết thông tin!".formatted(t.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa ?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlTacGia.deleteList(t.getiD())) {
                        listSangTac.removeIf(e -> e.getiD().equals(t.getiD()));
                        listTacGia.remove(t);
                        //// Thay đổi COMBO BOX. ////
                        cboTacGiaST.removeItem(t.getiD());
                        /////////////////////////////
                        btnLamMoiTGActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnXoaTGActionPerformed

    private void btnLamMoiTGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiTGActionPerformed
        fillToTable(listTacGia, modelTacGia);
        txtIDTG.setText("");
        txtHoTenTG.setText("");
        txtDiaChiTG.setText("");
        txtEmailTG.setText("");
        txtTimKiemTG.setText("");
        btgPhaiTG.clearSelection();
        cboNgayTG.setSelectedItem(null);
        cboThangTG.setSelectedItem(null);
        cboNamTG.setSelectedItem(null);
    }//GEN-LAST:event_btnLamMoiTGActionPerformed

    private void tblTacGiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTacGiaMouseClicked
        int index = tblTacGia.getSelectedRow();
        TacGia t = listTacGia.get(index);
        txtIDTG.setText(t.getiD());
        txtHoTenTG.setText(t.getHoTen());
        txtEmailTG.setText(t.getEmail());
        txtDiaChiTG.setText(t.getDiaChi());
        if (t.getPhai().equals("Nam")) {
            rdbNamTG.setSelected(true);
        } else {
            rdbNuTG.setSelected(true);
        }
        Calendar ntn = t.getNgaySinh();
        String ngay = String.valueOf(ntn.get(Calendar.DAY_OF_MONTH));
        String thang = String.valueOf(ntn.get(Calendar.MONTH) + 1);
        String nam = String.valueOf(ntn.get(Calendar.YEAR));
        cboNgayTG.setSelectedItem(ngay);
        cboThangTG.setSelectedItem(thang);
        cboNamTG.setSelectedItem(nam);
    }//GEN-LAST:event_tblTacGiaMouseClicked

    private void txtHoTenTGKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtHoTenTGKeyPressed
        txtHoTenTG.setEditable(!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'));
    }//GEN-LAST:event_txtHoTenTGKeyPressed

    private void txtTimKiemSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemSTActionPerformed
        btnTimKiemSTActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemSTActionPerformed

    private void btnTimKiemSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemSTActionPerformed
        String hint = txtTimKiemST.getText().toLowerCase();
        List<SangTac> filterList = listSangTac.stream().filter(e
                -> !e.getDanhSach().isEmpty() && e.toString().contains(hint)).
                collect(Collectors.toList());
        fillToTable(filterList, modelSangTac);

    }//GEN-LAST:event_btnTimKiemSTActionPerformed

    private void cboTacGiaSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacGiaSTActionPerformed
        if (cboTacGiaST.getSelectedItem() != null) {
            String idTG = cboTacGiaST.getSelectedItem().toString();
            TacGia t = listTacGia.stream().filter(e -> e.getiD().equals(idTG)).
                    findFirst().get();
            txtHoTenST.setText(t.getHoTen());
        } else {
            txtHoTenST.setText("");
        }
    }//GEN-LAST:event_cboTacGiaSTActionPerformed

    private void cboDauSachSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboDauSachSTActionPerformed
        if (cboDauSachST.getSelectedItem() != null) {
            String idDS = cboDauSachST.getSelectedItem().toString();
            DauSach t = listDauSach.stream().filter(e -> e.getiD().equals(idDS)).
                    findFirst().get();
            txtTenSachST.setText(t.getTenSach());
        } else {
            txtTenSachST.setText("");
        }
    }//GEN-LAST:event_cboDauSachSTActionPerformed

    private void btnThemSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemSTActionPerformed
        if (cboTacGiaST.getSelectedItem() == null || cboDauSachST.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin liên kết!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            String idTG = cboTacGiaST.getSelectedItem().toString();
            String idTP = cboDauSachST.getSelectedItem().toString();
            // Lấy thông tin liên kết.
            List<String> dsTacPham = listSangTac.stream().filter(e -> e.getiD().
                    equals(idTG)).findFirst().get().getDanhSach();
            // Kiểm tra thông tin liên kết.
            if (dsTacPham.stream().anyMatch(e -> e.equals(idTP))) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "%s đã được liên kết với %s.".formatted(idTP, idTG),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                if (sqlSangTac.insertList(idTG, idTP)) {
                    dsTacPham.add(idTP);
                    btnLamMoiSTActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }

            }
        }
    }//GEN-LAST:event_btnThemSTActionPerformed

    private void btnXoaSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaSTActionPerformed
        if (cboTacGiaST.getSelectedItem() == null || cboDauSachST.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin liên kết!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            String idTG = cboTacGiaST.getSelectedItem().toString();
            String idTP = cboDauSachST.getSelectedItem().toString();
            List<String> dsTacPham = listSangTac.stream().filter(e -> e.getiD().equals(idTG)).
                    findFirst().get().getDanhSach();
            if (dsTacPham.stream().anyMatch(e -> e.equals(idTP))) {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlSangTac.deleteList(idTG, idTP)) {
                        dsTacPham.remove(idTP);
                        btnLamMoiSTActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "Tác phẩm chưa được liên kết với tác giả.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnXoaSTActionPerformed

    private void btnLamMoiSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiSTActionPerformed
        fillToTable(listSangTac, modelSangTac);
        txtTimKiemST.setText("");
        cboTacGiaST.setSelectedItem(null);
        cboDauSachST.setSelectedItem(null);
        txtTenSachST.setText("");
        txtHoTenST.setText("");
    }//GEN-LAST:event_btnLamMoiSTActionPerformed

    private void cboTacGiaSTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboTacGiaSTMouseClicked
        cboTacGiaST.setSelectedItem(null);
    }//GEN-LAST:event_cboTacGiaSTMouseClicked

    private void cboDauSachSTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboDauSachSTMouseClicked
        cboDauSachST.setSelectedItem(null);
    }//GEN-LAST:event_cboDauSachSTMouseClicked

    private void txtTimKiemDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemDGActionPerformed
        btnTimKiemDGActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemDGActionPerformed

    private void btnTimKiemDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemDGActionPerformed
        String hint = txtTimKiemDG.getText().toLowerCase();
        List<DocGia> filterList = listDocGia.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelDocGia);
    }//GEN-LAST:event_btnTimKiemDGActionPerformed

    private void btnThemDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemDGActionPerformed
        String hoTenDG = txtHoTenDG.getText().strip().replaceAll(" {2,}", " ");
        String diaChiDG = txtDiaChiDG.getText().strip().replaceAll(" {2,}", " ");
        String emailDG = txtEmailDG.getText().strip().replaceAll(" {2,}", " ");
        String SDTDG = txtSDTDG.getText();
        String phai = rdbNamDG.isSelected() ? "Nam" : "Nữ";
        if (hoTenDG.isEmpty() || hoTenDG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Họ tên không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtHoTenDG.requestFocus();
        } else if (rdbNamDG.isSelected() == false && rdbNuDG.isSelected() == false) {
            JOptionPane.showMessageDialog(rootPane, "Phái không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (cboNgayDG.getSelectedItem() == null || cboThangDG.getSelectedItem() == null
                || cboNamDG.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày sinh không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (diaChiDG.isEmpty() || diaChiDG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtDiaChiDG.requestFocus();
        } else if (emailDG.isEmpty() || emailDG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailDG.requestFocus();
        } else if (!emailDG.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailNXB.requestFocus();
        } else if (SDTDG.isEmpty() || SDTDG.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Số điện thoại không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSDTDG.requestFocus();
        } else if (!SDTDG.matches("0{1}.*") || SDTDG.length() < 10) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin số điện thoại không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSDTDG.requestFocus();
        } else {
            Calendar ngaySinhDG = system.getDate(cboNgayDG.getSelectedItem().toString(),
                    cboThangDG.getSelectedItem().toString(), cboNamDG.getSelectedItem().toString());
            DocGia dG = new DocGia(hoTenDG, phai, ngaySinhDG, diaChiDG, emailDG, SDTDG);
            if (sqlDocGia.insertList(dG)) {
                listDocGia.add(dG);
                //// Thay đổi COMBO BOX. ////
                cboDocGiaLP.addItem(dG.getiD());
                cboDocGiaLP.setSelectedItem(null);
                cboDocGiaPP.addItem(dG.getiD());
                cboDocGiaPP.setSelectedItem(null);
                /////////////////////////////
                btnLamMoiDGActionPerformed(evt);
                JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                        "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Hệ thống đang xảy ra sự cố.",
                        "Thông báo lỗi", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
            }
        }
    }//GEN-LAST:event_btnThemDGActionPerformed

    private void btnSuaDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaDGActionPerformed
        int index = tblDocGia.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            DocGia t = listDocGia.get(index);
            String hoTenDG = txtHoTenDG.getText().strip().replaceAll(" {2,}", " ");
            String diaChiDG = txtDiaChiDG.getText().strip().replaceAll(" {2,}", " ");
            String emailDG = txtEmailDG.getText().strip().replaceAll(" {2,}", " ");
            String SDTDG = txtSDTDG.getText();
            String phai = rdbNamDG.isSelected() ? "Nam" : "Nữ";
            boolean dahuy = ckbDaHuy.isSelected();
            if (hoTenDG.isEmpty() || hoTenDG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Họ tên không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtHoTenDG.requestFocus();
            } else if (rdbNamDG.isSelected() == false && rdbNuDG.isSelected() == false) {
                JOptionPane.showMessageDialog(rootPane, "Phái không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (cboNgayDG.getSelectedItem() == null || cboThangDG.getSelectedItem() == null
                    || cboNamDG.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin ngày sinh không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else if (diaChiDG.isEmpty() || diaChiDG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtDiaChiDG.requestFocus();
            } else if (emailDG.isEmpty() || emailDG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailDG.requestFocus();
            } else if (!emailDG.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtEmailNXB.requestFocus();
            } else if (SDTDG.isEmpty() || SDTDG.isBlank()) {
                JOptionPane.showMessageDialog(rootPane, "Số điện thoại không thể trống!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtSDTDG.requestFocus();
            } else if (!SDTDG.matches("0{1}.*") || SDTDG.length() < 10) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin số điện thoại không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                txtSDTDG.requestFocus();
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn sửa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    Calendar ngaySinhDG = system.getDate(cboNgayDG.getSelectedItem().toString(),
                            cboThangDG.getSelectedItem().toString(), cboNamDG.getSelectedItem().toString());
                    if (sqlDocGia.updateList(t.getiD(), hoTenDG, phai, ngaySinhDG,
                            diaChiDG, emailDG, SDTDG, dahuy)) {
                        t.setHoTen(hoTenDG);
                        t.setPhai(phai);
                        t.setNgaySinh(ngaySinhDG);
                        t.setEmail(emailDG);
                        t.setDiaChi(diaChiDG);
                        t.setSdt(SDTDG);
                        //// Thay đổi COMBO BOX. ////
                        if (dahuy) {
                            cboDocGiaLP.removeItem(t.getiD());
                            cboDocGiaPM.removeItem(t.getiD());
                            cboDocGiaPP.removeItem(t.getiD());
                        } else if (t.isDaHuy()) {
                            cboDocGiaLP.addItem(t.getiD());
                            cboDocGiaLP.setSelectedItem(null);
                            cboDocGiaPM.addItem(t.getiD());
                            cboDocGiaPM.setSelectedItem(null);
                            cboDocGiaPP.addItem(t.getiD());
                            cboDocGiaPP.setSelectedItem(null);
                        }
                        //////////////////////////////
                        t.setDaHuy(dahuy);
                        btnLamMoiDGActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Sửa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Sửa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaDGActionPerformed

    private void btnLamMoiDGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiDGActionPerformed
        fillToTable(listDocGia, modelDocGia);
        txtTimKiemDG.setText("");
        txtHoTenDG.setText("");
        txtIDDG.setText("");
        txtEmailDG.setText("");
        txtDiaChiDG.setText("");
        txtSDTDG.setText("");
        btgPhaiDG.clearSelection();
        cboNgayDG.setSelectedItem(null);
        cboThangDG.setSelectedItem(null);
        cboNamDG.setSelectedItem(null);
        ckbDaHuy.setSelected(false);
        ckbDaHuy.setEnabled(false);
    }//GEN-LAST:event_btnLamMoiDGActionPerformed

    private void txtHoTenDGKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtHoTenDGKeyPressed
        txtHoTenDG.setEditable(!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'));
    }//GEN-LAST:event_txtHoTenDGKeyPressed

    private void txtSDTDGKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSDTDGKeyPressed
        if (txtSDTDG.getText().length() < 10 && evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtSDTDG.setEditable(true);
        } else {
            txtSDTDG.setEditable(false);
        }
    }//GEN-LAST:event_txtSDTDGKeyPressed

    private void tblDocGiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDocGiaMouseClicked
        int index = tblDocGia.getSelectedRow();
        DocGia t = listDocGia.get(index);
        txtIDDG.setText(t.getiD());
        txtHoTenDG.setText(t.getHoTen());
        if (t.getPhai().equals("Nam")) {
            rdbNamDG.setSelected(true);
        } else {
            rdbNuDG.setSelected(true);
        }
        Calendar ntn = t.getNgaySinh();
        String ngay = String.valueOf(ntn.get(Calendar.DAY_OF_MONTH));
        String thang = String.valueOf(ntn.get(Calendar.MONTH) + 1);
        String nam = String.valueOf(ntn.get(Calendar.YEAR));
        cboNgayDG.setSelectedItem(ngay);
        cboThangDG.setSelectedItem(thang);
        cboNamDG.setSelectedItem(nam);
        txtDiaChiDG.setText(t.getDiaChi());
        txtEmailDG.setText(t.getEmail());
        txtSDTDG.setText(t.getSdt());
        ckbDaHuy.setEnabled(true);
        if (t.isDaHuy()) {
            ckbDaHuy.setSelected(true);
        } else {
            ckbDaHuy.setSelected(false);
        }
    }//GEN-LAST:event_tblDocGiaMouseClicked

    private void btnLamMoiPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiPNActionPerformed
        fillToTable(listPhieuNhap, modelPhieuNhap);
        txtIDPN.setText("");
        txtThuThuPN.setText(quanLy.getiD());
        txtThanhTienPN.setText("");
        Calendar today = Calendar.getInstance();
        cboNgayPN.setSelectedItem(String.valueOf(today.get(Calendar.DAY_OF_MONTH)));
        cboThangPN.setSelectedItem(String.valueOf(today.get(Calendar.MONTH) + 1));
        cboNamPN.setSelectedItem(String.valueOf(today.get(Calendar.YEAR)));
        txtTimKiemTTPN.setText("");
        if (!listPhieuNhap.isEmpty()) {
            tblThongTinPhieuNhap.removeRowSelectionInterval(0, listPhieuNhap.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiPNActionPerformed

    private void btnLamMoiCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiCTActionPerformed
        fillToTable(listChiTietPhieuNhap, modelChiTietPhieuNhap);
        cboPhieuNhapCT.setSelectedItem(null);
        cboDauSachCT.setSelectedItem(null);
        txtTimKiemCT.setText("");
        txtThanhTienPN.setText("");
        txtSoLuong.setText("");
        txtTenSachCT.setText("");
    }//GEN-LAST:event_btnLamMoiCTActionPerformed

    private void btnLamMoiPTLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiPTLActionPerformed
        fillToTable(listPhieuThanhLy, modelPhieuThanhLy);
        txtIDPTL.setText("");
        txtThuThuPTL.setText(quanLy.getiD());
        txtThanhTienPTL.setText("");
        Calendar today = Calendar.getInstance();
        cboNgayPTL.setSelectedItem(String.valueOf(today.get(Calendar.DAY_OF_MONTH)));
        cboThangPTL.setSelectedItem(String.valueOf(today.get(Calendar.MONTH) + 1));
        cboNamPTL.setSelectedItem(String.valueOf(today.get(Calendar.YEAR)));
        txtTimKiemPTL.setText("");
        if (!listPhieuThanhLy.isEmpty()) {
            tblPhieuThanhLy.removeRowSelectionInterval(0, listPhieuThanhLy.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiPTLActionPerformed

    private void btnLamMoiLPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiLPActionPerformed
        fillToTable(listLePhi, modelLePhi);
        txtIDLP.setText("");
        txtChiPhi.setText("");
        txtThuThuLP.setText(quanLy.getiD());
        cboDocGiaLP.setSelectedItem(null);
        Calendar today = Calendar.getInstance();
        cboNgayLP.setSelectedItem(String.valueOf(today.get(Calendar.DAY_OF_MONTH)));
        cboThangLP.setSelectedItem(String.valueOf(today.get(Calendar.MONTH) + 1));
        cboNamLP.setSelectedItem(String.valueOf(today.get(Calendar.YEAR)));
        txtTimKiemLP.setText("");
        if (!listLePhi.isEmpty()) {
            tblLePhi.removeRowSelectionInterval(0, listLePhi.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiLPActionPerformed

    private void btnLamMoiPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiPTActionPerformed
        fillToTable(listPhieuTra, modelPhieuTra);
        txtPhieuMuonPT.setText("");
        txtCuonSachPT.setText("");
        txtThuThuPT.setText("");
        Calendar today = Calendar.getInstance();
        cboNgayPT.setSelectedItem(String.valueOf(today.get(Calendar.DAY_OF_MONTH)));
        cboThangPT.setSelectedItem(String.valueOf(today.get(Calendar.MONTH) + 1));
        cboNamPT.setSelectedItem(String.valueOf(today.get(Calendar.YEAR)));
        txtNgayQuaHan.setText("");
        txtTimKiemPT.setText("");
        ckbGiaHan.setSelected(false);
        ckbDaMat.setSelected(false);
        if (!listPhieuTra.isEmpty()) {
            tblPhieuTra.removeRowSelectionInterval(0, listPhieuTra.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiPTActionPerformed

    private void btnLamMoiPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiPPActionPerformed
        fillToTable(listPhieuPhat, modelPhieuPhat);
        txtIDPP.setText("");
        cboDocGiaPP.setSelectedItem(null);
        txtThuThuPP.setText(quanLy.getiD());
        txtLyDo.setText("");
        txtXuPhat.setText("");
        Calendar today = Calendar.getInstance();
        cboNgayPP.setSelectedItem(String.valueOf(today.get(Calendar.DAY_OF_MONTH)));
        cboThangPP.setSelectedItem(String.valueOf(today.get(Calendar.MONTH) + 1));
        cboNamPP.setSelectedItem(String.valueOf(today.get(Calendar.YEAR)));
        if (!listPhieuPhat.isEmpty()) {
            tblPhieuPhat.removeRowSelectionInterval(0, listPhieuPhat.size() - 1);
        }
    }//GEN-LAST:event_btnLamMoiPPActionPerformed

    private void tblPhieuTraMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuTraMouseClicked
        PhieuTra item = listPhieuTra.get(tblPhieuTra.getSelectedRow());
        txtPhieuMuonPT.setText(item.getiDPhieuMuon());
        txtCuonSachPT.setText(item.getiDCuonSach());
        txtThuThuPT.setText(item.getiDThuThu());
        ckbGiaHan.setSelected(item.isDaGiaHan());
        if (item.getNgayTra() != null) {
            cboNgayPT.setSelectedItem(String.valueOf(item.getNgayTra().get(Calendar.DAY_OF_MONTH)));
            cboThangPT.setSelectedItem(String.valueOf(item.getNgayTra().get(Calendar.MONTH) + 1));
            cboNamPT.setSelectedItem(String.valueOf(item.getNgayTra().get(Calendar.YEAR)));
        }
        Calendar ngayQuaHan = system.getNgayQuaHan(system.getNgayMuon(
                listPhieuMuon, item.getiDPhieuMuon()), item.isDaGiaHan());
        txtNgayQuaHan.setText(df.format(ngayQuaHan.getTime()));
        ckbGiaHan.setSelected(item.isDaGiaHan());
        ckbGiaHan.setEnabled(!item.isDaGiaHan());
        ckbDaMat.setSelected(item.isDaMat());
    }//GEN-LAST:event_tblPhieuTraMouseClicked

    private void txaSachMuonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txaSachMuonMouseClicked
        if (!listCuonSach.isEmpty()) {
            new BorrowFrm(this, rootPaneCheckingEnabled).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Kho sách đang trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        }
    }//GEN-LAST:event_txaSachMuonMouseClicked

    private void btnSuaPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaPTActionPerformed
        int index = tblPhieuTra.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            PhieuTra item = listPhieuTra.get(index);
            String iDThuThu = txtThuThuPT.getText();
            boolean isGiaHan = ckbGiaHan.isSelected();
            boolean isDaMat = ckbDaMat.isSelected();

            if (item.isDaGiaHan() != isGiaHan) {
                if (!iDThuThu.isEmpty() || isDaMat) {
                    JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                            + "Thông tin không hợp lệ. (Trường hợp gia hạn không ghi nhận "
                            + "thủ thư và trạng thái.)",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                } else {
                    item.setDaGiaHan(true);
                    btnLamMoiPTActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Gia hạn thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                }
            } else {
                if (iDThuThu.isEmpty()) {
                    JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                            + "Thông tin thủ thư không thể trống.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    txtThuThuPT.requestFocus();
                } else if (!system.isQuanLy(iDThuThu, listThuThu)) {
                    JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    txtThuThuPT.requestFocus();
                } else if (cboNgayPT.getSelectedItem() == null || cboThangPT.getSelectedItem() == null
                        || cboNamPT.getSelectedItem() == null) {
                    JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                            + "Thông tin ngày trả không thể trống.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                } else {
                    Calendar ngayTra = system.getDate(cboNgayPT.getSelectedItem().toString(),
                            cboThangPT.getSelectedItem().toString(), cboNamPT.getSelectedItem().toString());
                    if (ngayTra.after(Calendar.getInstance()) || ngayTra.before(
                            system.getNgayMuon(listPhieuMuon, item.getiDPhieuMuon()))) {
                        JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                                + "Thông tin ngày trả không hợp lệ.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    } else {
                        if (sqlPhieuTra.updateList(item.getiDPhieuMuon(), item.getiDCuonSach(),
                                iDThuThu, ngayTra, isGiaHan, isDaMat)) {
                            item.setiDThuThu(iDThuThu);
                            item.setNgayTra(ngayTra);
                            item.setDaMat(isDaMat);
                            //// Cập nhật lại thông tin Trạng thái. ////
                            CuonSach itemCS = listCuonSach.stream().filter(e -> e.getiD().
                                    equals(item.getiDCuonSach())).findFirst().get();
                            itemCS.setTrangThai(isDaMat ? "Đã mất" : "Chưa mượn");
                            sqlCuonSach.updateList(itemCS.getiD(), itemCS.getTrangThai());
                            btnLamMoiCS.doClick();
                            ////////////////////////////////////////////
                            btnLamMoiPTActionPerformed(evt);
                            JOptionPane.showMessageDialog(rootPane, "Cập nhật thành công",
                                    "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                                    + "Hệ thống đang xảy ra sự cố.",
                                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_btnSuaPTActionPerformed

    private void btnXoaPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaPTActionPerformed
        int index = tblPhieuTra.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            PhieuTra item = listPhieuTra.get(index);
            if (item.getiDThuThu().isEmpty()) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "Sách chưa được hoàn trả.", "Thông báo lỗi",
                        JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    String iDPhieuMuon = item.getiDPhieuMuon();
                    if (sqlPhieuTra.deleteList(iDPhieuMuon, item.getiDCuonSach())) {
                        listPhieuTra.remove(index);
                        if (listPhieuTra.stream().noneMatch(e -> e.getiDPhieuMuon().
                                equals(iDPhieuMuon))) {
                            listPhieuMuon.removeIf(e -> e.getiD().equals(iDPhieuMuon));
                            sqlPhieuMuon.deleteList(iDPhieuMuon);
                            btnLamMoiPM.doClick();
                        }
                        btnLamMoiPTActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    tblPhieuTra.removeRowSelectionInterval(index, index);
                }
            }
        }
    }//GEN-LAST:event_btnXoaPTActionPerformed

    private void txtThuThuPTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtThuThuPTMouseClicked
        txtThuThuPT.setText(quanLy.getiD());
    }//GEN-LAST:event_txtThuThuPTMouseClicked

    private void tblPhieuPhatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuPhatMouseClicked
        PhieuPhat item = listPhieuPhat.get(tblPhieuPhat.getSelectedRow());
        txtIDPP.setText(item.getiD());
        cboDocGiaPP.setSelectedItem(item.getiDDocGia());
        Calendar ngayLap = item.getNgayThucHien();
        cboNgayPP.setSelectedItem(String.valueOf(ngayLap.get(Calendar.DAY_OF_MONTH)));
        cboThangPP.setSelectedItem(String.valueOf(ngayLap.get(Calendar.MONTH) + 1));
        cboNamPP.setSelectedItem(String.valueOf(ngayLap.get(Calendar.YEAR)));
        txtThuThuPP.setText(item.getiDThuThu());
        txtLyDo.setText(item.getLyDo());
        txtXuPhat.setText(item.getXuPhat());
    }//GEN-LAST:event_tblPhieuPhatMouseClicked

    private void txtTimKiemPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemPPActionPerformed
        btnTimKiemPPActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemPPActionPerformed

    private void btnTimKiemPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemPPActionPerformed
        String hint = txtTimKiemPP.getText().toLowerCase();
        List<PhieuPhat> filterList = listPhieuPhat.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelPhieuPhat);
    }//GEN-LAST:event_btnTimKiemPPActionPerformed

    private void btnThemPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemPPActionPerformed
        if (cboDocGiaPP.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin độc giả không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (cboNgayPP.getSelectedItem() == null || cboThangPP.getSelectedItem() == null
                || cboNamPP.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày lập không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (txtThuThuPP.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPP.requestFocus();
        } else if (!system.isQuanLy(txtThuThuPP.getText(), listThuThu)) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPP.requestFocus();
        } else if (txtLyDo.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin lý do vi phạm không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtLyDo.requestFocus();
        } else if (txtXuPhat.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin hình thức xử phạt không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtXuPhat.requestFocus();
        } else {
            String iDDocGia = cboDocGiaPP.getSelectedItem().toString();
            String iDThuThu = txtThuThuPP.getText();
            Calendar ngayLap = system.getDate(cboNgayPP.getSelectedItem().toString(),
                    cboThangPP.getSelectedItem().toString(), cboNamPP.getSelectedItem().toString());
            String lyDo = txtLyDo.getText();
            String xuPhat = txtXuPhat.getText();
            if (ngayLap.after(Calendar.getInstance())) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Thông tin ngày lập không hợp lệ.", "Thông báo lỗi",
                        JOptionPane.ERROR_MESSAGE, this.ico_failure);
                return;
            }
            PhieuPhat item = new PhieuPhat(iDDocGia, iDThuThu, ngayLap, lyDo, xuPhat);
            if (sqlPhieuPhat.insertList(item)) {
                listPhieuPhat.add(item);
                btnLamMoiPPActionPerformed(evt);
                JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                        "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
            } else {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "Hệ thống đang xảy ra sự cố.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnThemPPActionPerformed

    private void btnXoaPPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaPPActionPerformed
        int index = tblPhieuPhat.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                    "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE, this.ico_question);
            if (choice == JOptionPane.OK_OPTION) {
                if (sqlPhieuPhat.deleteList(listPhieuPhat.get(index).getiD())) {
                    listPhieuPhat.remove(index);
                    btnLamMoiPPActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            } else {
                tblPhieuPhat.removeRowSelectionInterval(index, index);
            }
        }
    }//GEN-LAST:event_btnXoaPPActionPerformed

    private void txtTheLoaiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTheLoaiKeyPressed
        txtTheLoai.setEditable(!(evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'));
    }//GEN-LAST:event_txtTheLoaiKeyPressed

    private void tblThongTinPhieuNhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblThongTinPhieuNhapMouseClicked
        PhieuNhap pn = listPhieuNhap.get(tblThongTinPhieuNhap.getSelectedRow());
        txtIDPN.setText(pn.getiD());
        Calendar ntn = pn.getNgayThucHien();
        cboNgayPN.setSelectedItem(String.valueOf(ntn.get(Calendar.DAY_OF_MONTH)));
        cboThangPN.setSelectedItem(String.valueOf(ntn.get(Calendar.MONTH) + 1));
        cboNamPN.setSelectedItem(String.valueOf(ntn.get(Calendar.YEAR)));
        txtThuThuPN.setText(pn.getiDThuThu());
        txtThanhTienPN.setText(String.valueOf(system.getTongTienPN(pn.getiD(),
                listChiTietPhieuNhap, listDauSach)));

    }//GEN-LAST:event_tblThongTinPhieuNhapMouseClicked

    private void txtTimKiemTTPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemTTPNActionPerformed
        btnTimKiemTTPNActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemTTPNActionPerformed

    private void btnTimKiemTTPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemTTPNActionPerformed
        String hint = txtTimKiemTTPN.getText().toLowerCase();
        List<PhieuNhap> filterList = listPhieuNhap.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelPhieuNhap);
    }//GEN-LAST:event_btnTimKiemTTPNActionPerformed

    private void btnThemPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemPNActionPerformed
        if (txtThuThuPN.getText().isEmpty() || txtThuThuPN.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPN.requestFocus();
        } else if (!system.isQuanLy(txtThuThuPN.getText(), listThuThu)) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPN.requestFocus();
        } else if (cboNgayPN.getSelectedItem() == null || cboThangPN.getSelectedItem() == null
                || cboNamPN.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày nhập không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Calendar ngayNhap = system.getDate(cboNgayPN.getSelectedItem().toString(),
                    cboThangPN.getSelectedItem().toString(), cboNamPN.getSelectedItem().toString());
            if (ngayNhap.after(Calendar.getInstance())) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin ngày nhập không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                String iDThuThu = txtThuThuPN.getText();
                PhieuNhap pn = new PhieuNhap(iDThuThu, ngayNhap);
                if (sqlPhieuNhap.insertList(pn)) {
                    listPhieuNhap.add(pn);
                    listChiTietPhieuNhap.add(new ChiTietPhieuNhap(pn.getiD()));
                    //// Thay đổi COMBO BOX. ////
                    cboPhieuNhapCT.addItem(pn.getiD());
                    cboPhieuNhapCT.setSelectedItem(null);
                    ////////////////////////////
                    btnLamMoiPNActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemPNActionPerformed

    private void btnXoaPNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaPNActionPerformed
        int index = tblThongTinPhieuNhap.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            PhieuNhap t = listPhieuNhap.get(index);
            if (listChiTietPhieuNhap.stream().anyMatch(e -> e.getiD().
                    equals(t.getiD()) && !e.getDanhSach().isEmpty())) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã liên kết thông tin.".formatted(t.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlPhieuNhap.deleteList(t.getiD())) {
                        listPhieuNhap.remove(t);
                        listChiTietPhieuNhap.removeIf(e -> e.getiD().equals(t.getiD()));
                        btnLamMoiPNActionPerformed(evt);
                        //// Thay đổi COMBO BOX. ////
                        cboPhieuNhapCT.removeItem(t.getiD());
                        /////////////////////////////
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnXoaPNActionPerformed

    private void btnTimKiemCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemCTActionPerformed
        String hint = txtTimKiemCT.getText().toLowerCase();
        List<ChiTietPhieuNhap> filterList = listChiTietPhieuNhap.stream().filter(
                e -> !e.getDanhSach().isEmpty() && e.toString().contains(hint)).
                collect(Collectors.toList());
        fillToTable(filterList, modelChiTietPhieuNhap);
    }//GEN-LAST:event_btnTimKiemCTActionPerformed

    private void btnThemCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemCTActionPerformed
        if (cboPhieuNhapCT.getSelectedItem() == null || cboDauSachCT.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin liên kết!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (txtSoLuong.getText().isEmpty() || txtSoLuong.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Số lượng không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSoLuong.requestFocus();
        } else if (txtSoLuong.getText().equals("0")) {
            JOptionPane.showMessageDialog(rootPane, "Số lượng nhập phải lớn hơn 0!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtSoLuong.requestFocus();
        } else {
            String idPN = cboPhieuNhapCT.getSelectedItem().toString();
            String idDS = cboDauSachCT.getSelectedItem().toString();
            int soLuong = Integer.parseInt(txtSoLuong.getText());
            List<SanPham> dsSanPham = listChiTietPhieuNhap.stream().filter(e
                    -> e.getiD().equals(idPN)).findFirst().get().getDanhSach();
            boolean isTonTai = dsSanPham.stream().anyMatch(e -> e.getiDDauSach().equals(idDS));
            if (isTonTai) {
                JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                        + "%s đã được liên kết thông tin.".formatted(idPN),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                if (sqlChiTietPhieuNhap.insertList(idPN, idDS, soLuong)) {
                    dsSanPham.add(new SanPham(idDS, soLuong));
                    btnLamMoiPN.doClick();
                    btnLamMoiCTActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemCTActionPerformed

    private void btnXoaCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaCTActionPerformed
        if (cboPhieuNhapCT.getSelectedItem() == null || cboDauSachCT.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin liên kết!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            String idPN = cboPhieuNhapCT.getSelectedItem().toString();
            String idDS = cboDauSachCT.getSelectedItem().toString();
            // Lấy thông tin đầu sách cần loại bỏ.
            List<SanPham> dsSanPhams = listChiTietPhieuNhap.stream().filter(e
                    -> e.getiD().equals(idPN)).findFirst().get().getDanhSach();
            Optional<SanPham> sanPhamLoaiBo = dsSanPhams.stream().filter(e
                    -> e.getiDDauSach().equals(idDS)).findFirst();
            // Kiểm tra sách đã được nhập vào hệ thống.
            if (sanPhamLoaiBo.isPresent() && system.isDaVaoHeThong(idDS, sanPhamLoaiBo.get(),
                    listChiTietPhieuNhap, listCuonSach)) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "Sách đã nhập vào hệ thống.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn có chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlChiTietPhieuNhap.deleteList(idPN, idDS)) {
                        dsSanPhams.remove(sanPhamLoaiBo.get());
                        btnLamMoiCTActionPerformed(evt);
                        btnLamMoiPN.doClick();
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                            + "Phiếu nhập chưa được liên kết với đầu sách.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnXoaCTActionPerformed

    private void cboPhieuNhapCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboPhieuNhapCTActionPerformed
        if (cboPhieuNhapCT.getSelectedItem() != null && cboDauSachCT.getSelectedItem() != null) {
            String iDPN = cboPhieuNhapCT.getSelectedItem().toString();
            String iDDS = cboDauSachCT.getSelectedItem().toString();
            Optional<ChiTietPhieuNhap> item = listChiTietPhieuNhap.stream().
                    filter(e -> e.getiD().equals(iDPN)).findFirst();
            if (item.isPresent()) {
                List<SanPham> dsSanPham = item.get().getDanhSach();
                Optional<SanPham> sanPham = dsSanPham.stream().filter(e -> e.getiDDauSach().
                        equals(iDDS)).findFirst();
                if (sanPham.isPresent()) {
                    txtSoLuong.setText(String.valueOf(sanPham.get().getSoLuong()));
                    return;
                }
            }
        }
        txtSoLuong.setText("");
    }//GEN-LAST:event_cboPhieuNhapCTActionPerformed

    private void cboDauSachCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboDauSachCTActionPerformed
        if (cboDauSachCT.getSelectedItem() != null) {
            String iDDS = cboDauSachCT.getSelectedItem().toString();
            String tenSach = listDauSach.stream().filter(e -> e.getiD().
                    equals(iDDS)).findFirst().get().getTenSach();
            txtTenSachCT.setText(tenSach);
            if (cboPhieuNhapCT.getSelectedItem() != null) {
                String iDPN = cboPhieuNhapCT.getSelectedItem().toString();
                Optional<ChiTietPhieuNhap> item = listChiTietPhieuNhap.stream().
                        filter(e -> e.getiD().equals(iDPN)).findFirst();
                if (item.isPresent()) {
                    List<SanPham> dsSanPham = item.get().getDanhSach();
                    Optional<SanPham> sanPham = dsSanPham.stream().filter(e -> e.getiDDauSach().
                            equals(iDDS)).findFirst();
                    if (sanPham.isPresent()) {
                        txtSoLuong.setText(String.valueOf(sanPham.get().getSoLuong()));
                        return;
                    }
                }
            }
        } else {
            txtTenSachCT.setText("");
        }
        txtSoLuong.setText("");
    }//GEN-LAST:event_cboDauSachCTActionPerformed

    private void cboPhieuNhapCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboPhieuNhapCTMouseClicked
        cboPhieuNhapCT.setSelectedItem(null);
    }//GEN-LAST:event_cboPhieuNhapCTMouseClicked

    private void cboDauSachCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cboDauSachCTMouseClicked
        cboDauSachCT.setSelectedItem(null);
    }//GEN-LAST:event_cboDauSachCTMouseClicked

    private void txtSoLuongKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSoLuongKeyPressed
        if (txtSDTDG.getText().length() < 11 && evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtSDTDG.setEditable(true);
        } else {
            txtSDTDG.setEditable(false);
        }
    }//GEN-LAST:event_txtSoLuongKeyPressed

    private void tblPhieuThanhLyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuThanhLyMouseClicked
        PhieuThanhLy ptl = listPhieuThanhLy.get(tblPhieuThanhLy.getSelectedRow());
        txtIDPTL.setText(ptl.getiD());
        txtThuThuPTL.setText(ptl.getiDThuThu());
        txtThanhTienPTL.setText(String.valueOf(system.getTongTienPTL(ptl.getiD(), listCuonSach)));
        Calendar ntn = ptl.getNgayThucHien();
        String ngay = String.valueOf(ntn.get(Calendar.DAY_OF_MONTH));
        String thang = String.valueOf(ntn.get(Calendar.MONTH) + 1);
        String nam = String.valueOf(ntn.get(Calendar.YEAR));
        cboNgayPTL.setSelectedItem(ngay);
        cboThangPTL.setSelectedItem(thang);
        cboNamPTL.setSelectedItem(nam);

    }//GEN-LAST:event_tblPhieuThanhLyMouseClicked

    private void txtTimKiemPTLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemPTLActionPerformed
        btnTimKiemPTLActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemPTLActionPerformed

    private void btnTimKiemPTLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemPTLActionPerformed
        String hint = txtTimKiemPTL.getText().toLowerCase();
        List<PhieuThanhLy> filterList = listPhieuThanhLy.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelPhieuThanhLy);
    }//GEN-LAST:event_btnTimKiemPTLActionPerformed

    private void btnThemPTLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemPTLActionPerformed
        if (txtThuThuPTL.getText().isEmpty() || txtThuThuPTL.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPTL.requestFocus();
        } else if (!system.isQuanLy(txtThuThuPTL.getText(), listThuThu)) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuPTL.requestFocus();
        } else if (cboNgayPTL.getSelectedItem() == null || cboThangPTL.getSelectedItem() == null
                || cboNamPTL.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày thanh lý không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            Calendar ngayThanhLy = system.getDate(cboNgayPTL.getSelectedItem().toString(),
                    cboThangPTL.getSelectedItem().toString(), cboNamPTL.getSelectedItem().toString());
            if (ngayThanhLy.after(Calendar.getInstance())) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin ngày thanh lý không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                String iDThuThu = txtThuThuPTL.getText();
                PhieuThanhLy ptl = new PhieuThanhLy(iDThuThu, ngayThanhLy);
                if (sqlPhieuThanhLy.insertList(ptl)) {
                    listPhieuThanhLy.add(ptl);
                    //// Thay đổi COMBO BOX. ////
                    cboPhieuThanhLyCS.addItem(ptl.getiD());
                    cboPhieuThanhLyCS.setSelectedItem(null);
                    /////////////////////////////
                    btnLamMoiPTLActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnThemPTLActionPerformed

    private void btnXoaPTLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaPTLActionPerformed
        int index = tblPhieuThanhLy.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            PhieuThanhLy ptl = listPhieuThanhLy.get(index);
            if (listCuonSach.stream().anyMatch(e -> e.getiDPhieuThanhLy().equals(ptl.getiD()))) {
                JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                        + "%s đã liên kết thông tin.".formatted(ptl.getiD()),
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                int choice = JOptionPane.showConfirmDialog(rootPane, "Bạn chắc chắn xóa?",
                        "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.QUESTION_MESSAGE, this.ico_question);
                if (choice == JOptionPane.OK_OPTION) {
                    if (sqlPhieuThanhLy.deleteList(ptl.getiD())) {
                        listPhieuThanhLy.remove(ptl);
                        //// Thay đổi COMBO BOX. ////
                        cboPhieuThanhLyCS.removeItem(ptl.getiD());
                        /////////////////////////////
                        btnLamMoiPTLActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnXoaPTLActionPerformed

    private void tblLePhiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLePhiMouseClicked
        LePhi lp = listLePhi.get(tblLePhi.getSelectedRow());
        txtIDLP.setText(lp.getiD());
        txtChiPhi.setText(String.valueOf(lp.getChiPhi()));
        Calendar ntn = lp.getNgayThucHien();
        String ngay = String.valueOf(ntn.get(Calendar.DAY_OF_MONTH));
        String thang = String.valueOf(ntn.get(Calendar.MONTH) + 1);
        String nam = String.valueOf(ntn.get(Calendar.YEAR));
        cboNgayLP.setSelectedItem(ngay);
        cboThangLP.setSelectedItem(thang);
        cboNamLP.setSelectedItem(nam);
        cboDocGiaLP.setSelectedItem(lp.getiDDocGia());
        txtThuThuLP.setText(lp.getiDThuThu());
    }//GEN-LAST:event_tblLePhiMouseClicked

    private void txtTimKiemLPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemLPActionPerformed
        btnTimKiemLPActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemLPActionPerformed

    private void btnTimKiemLPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemLPActionPerformed
        String hint = txtTimKiemLP.getText().toLowerCase();
        List<LePhi> filterList = listLePhi.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelLePhi);
    }//GEN-LAST:event_btnTimKiemLPActionPerformed

    private void btnThemLPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemLPActionPerformed
        if (txtChiPhi.getText().isEmpty()) {
            JOptionPane.showMessageDialog(rootPane, "Chi phí không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtChiPhi.requestFocus();
        } else if (cboNgayLP.getSelectedItem() == null || cboThangLP.getSelectedItem() == null
                || cboNamLP.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin ngày lập không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else if (cboDocGiaLP.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin độc giả không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            cboDocGiaLP.requestFocus();
        } else if (txtThuThuLP.getText().isEmpty() || txtThuThuLP.getText().isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuLP.requestFocus();
        } else if (!system.isQuanLy(txtThuThuLP.getText(), listThuThu)) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin thủ thư không chính xác!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtThuThuLP.requestFocus();
        } else {
            String idDG = cboDocGiaLP.getSelectedItem().toString();
            String idTT = txtThuThuLP.getText();
            float chiPhi = Float.parseFloat(txtChiPhi.getText());
            Calendar ngayDong = system.getDate(cboNgayLP.getSelectedItem().toString(),
                    cboThangLP.getSelectedItem().toString(), cboNamLP.getSelectedItem().toString());
            if (ngayDong.after(Calendar.getInstance())) {
                JOptionPane.showMessageDialog(rootPane, "Thông tin ngày lập không hợp lệ!",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            } else {
                Calendar today = Calendar.getInstance();
                boolean daThanhToan = listLePhi.stream().anyMatch(e -> e.getiDDocGia().
                        equals(idDG) && system.getNgayQuaHan(ngayDong).after(today));
                if (daThanhToan) {
                    JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                            + "%s đã thanh toán lệ phí.".formatted(idDG),
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                } else {
                    LePhi item = new LePhi(idDG, idTT, chiPhi, ngayDong);
                    if (sqlLePhi.insertList(item)) {
                        listLePhi.add(item);
                        // Kiểm tra ngày đóng lệ phí.
                        if (system.getNgayQuaHan(ngayDong).after(Calendar.getInstance())) {
                            DocGia dG = listDocGia.stream().filter(e -> e.getiD().
                                    equals(idDG)).findFirst().get();
                            dG.setDaHuy(false);
                            sqlDocGia.updateList(idDG, false);
                            cboDocGiaPM.addItem(dG.getiD());
                            cboDocGiaPM.setSelectedItem(null);
                            btnLamMoiDG.doClick();
                        }
                        btnLamMoiLPActionPerformed(evt);
                        JOptionPane.showMessageDialog(rootPane, "Thêm thành công",
                                "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Thêm thất bại! "
                                + "Hệ thống đang xảy ra sự cố.",
                                "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            }
        }
    }//GEN-LAST:event_btnThemLPActionPerformed

    private void btnXoaLPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaLPActionPerformed
        int index = tblLePhi.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(rootPane, "Vui lòng chọn thông tin!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
        } else {
            LePhi lp = listLePhi.get(index);
            int choice = JOptionPane.showConfirmDialog(rootPane, "Ban chắc chắn xóa?",
                    "Thông báo xác nhận", JOptionPane.OK_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE, this.ico_question);
            if (choice == JOptionPane.OK_OPTION) {
                if (sqlLePhi.deleteList(lp.getiD())) {
                    listLePhi.remove(lp);
                    if (system.getNgayQuaHan(lp.getNgayThucHien()).after(Calendar.getInstance())) {
                        DocGia dG = listDocGia.stream().filter(e -> e.getiD().equals(lp.getiDDocGia())).
                                findFirst().get();
                        dG.setDaHuy(true);
                        sqlDocGia.updateList(dG.getiD(), true);
                        //// Thay đổi COMBO BOX. ////
                        cboDocGiaPM.removeItem(dG.getiD());
                        /////////////////////////////
                        btnLamMoiDG.doClick();
                    }
                    btnLamMoiLPActionPerformed(evt);
                    JOptionPane.showMessageDialog(rootPane, "Xóa thành công",
                            "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Xóa thất bại! "
                            + "Hệ thống đang xảy ra sự cố.",
                            "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                }
            }
        }
    }//GEN-LAST:event_btnXoaLPActionPerformed

    private void txtChiPhiKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtChiPhiKeyPressed
        if (evt.getKeyChar() >= '0' && evt.getKeyChar() <= '9'
                || (evt.getKeyChar() == '.' && !txtChiPhi.getText().isEmpty()
                && !txtChiPhi.getText().contains("."))
                || evt.getKeyCode() == KeyEvent.VK_BACK_SPACE
                || evt.getKeyCode() == KeyEvent.VK_LEFT
                || evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            txtChiPhi.setEditable(true);
        } else {
            txtChiPhi.setEditable(false);
        }
    }//GEN-LAST:event_txtChiPhiKeyPressed

    private void txtTimKiemCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemCTActionPerformed
        btnTimKiemCTActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemCTActionPerformed

    private void txtThuThuPNKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuPNKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuPN.setText(txtThuThuPN.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuPNKeyReleased

    private void txtThuThuPTLKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuPTLKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuPTL.setText(txtThuThuPTL.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuPTLKeyReleased

    private void txtThuThuLPKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuLPKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuLP.setText(txtThuThuLP.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuLPKeyReleased

    private void txtThuThuPMKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuPMKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuPM.setText(txtThuThuPM.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuPMKeyReleased

    private void txtThuThuPTKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuPTKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuPT.setText(txtThuThuPT.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuPTKeyReleased

    private void txtThuThuPPKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtThuThuPPKeyReleased
        if (evt.getKeyChar() >= 'a' && evt.getKeyChar() <= 'z') {
            txtThuThuPP.setText(txtThuThuPP.getText().toUpperCase());
        }
    }//GEN-LAST:event_txtThuThuPPKeyReleased

    private void txtTimKiemPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemPTActionPerformed
        btnTimKiemPTActionPerformed(evt);
    }//GEN-LAST:event_txtTimKiemPTActionPerformed

    private void btnTimKiemPTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemPTActionPerformed
        String hint = txtTimKiemPT.getText().toLowerCase();
        List<PhieuTra> filterList = listPhieuTra.stream().filter(e -> e.toString().
                contains(hint)).collect(Collectors.toList());
        fillToTable(filterList, modelPhieuTra);
    }//GEN-LAST:event_btnTimKiemPTActionPerformed

    private void btnDangXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDangXuatActionPerformed
        this.setVisible(false);
        this.quanLy = null;
        this.initLoginFrm();
    }//GEN-LAST:event_btnDangXuatActionPerformed

    private void btnCapNhatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapNhatActionPerformed
        Calendar ngaySinh = system.getDate(cboNgayQL.getSelectedItem().toString(),
                cboThangQL.getSelectedItem().toString(), cboNamQL.getSelectedItem().toString());
        String phai = (rbtnNamQL.isSelected()) ? "Nam" : "Nữ";
        String diaChi = txtDiaChiQL.getText().strip().replaceAll(" {2,}", " ");
        String email = txtEmailQL.getText().strip().replaceAll(" {2,}", " ");
        // Kiểm tra sự thay đổi thông tin.
        if (diaChi.isEmpty() || diaChi.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Địa chỉ không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtDiaChiQL.requestFocus();
        } else if (email.isEmpty() || email.isBlank()) {
            JOptionPane.showMessageDialog(rootPane, "Email không thể trống!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailQL.requestFocus();
        } else if (!email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
            JOptionPane.showMessageDialog(rootPane, "Thông tin email không hợp lệ!",
                    "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            txtEmailQL.requestFocus();
        } else {
            if (!ngaySinh.equals(quanLy.getNgaySinh()) || !phai.equals(quanLy.getPhai())
                    || !diaChi.equals(quanLy.getDiaChi()) || !email.equals(quanLy.getEmail())) {
                String choice = JOptionPane.showInputDialog(rootPane, "Nhập mật khẩu: ",
                        "Thông báo xác nhận", JOptionPane.QUESTION_MESSAGE);
                if (choice != null) {
                    if (choice.equals(listTaiKhoan.stream().filter(e -> e.getiDThuThu().
                            equals(quanLy.getiD())).findFirst().get().getMatKhau())) {
                        if (sqlThuThu.updateList(quanLy.getiD(), phai, ngaySinh, diaChi, email)) {
                            quanLy.setNgaySinh(ngaySinh);
                            quanLy.setPhai(phai);
                            quanLy.setDiaChi(diaChi);
                            quanLy.setEmail(email);
                            JOptionPane.showMessageDialog(rootPane, "Cập nhật thành công",
                                    "Thông báo", JOptionPane.INFORMATION_MESSAGE, this.ico_success);
                        } else {
                            JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                                    + "Hệ thống đang xảy ra xử cố.",
                                    "Thông báo", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                        }
                    } else {
                        JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                                + "Mật khẩu không chính xác.",
                                "Thông báo", JOptionPane.ERROR_MESSAGE, this.ico_failure);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(rootPane, "Cập nhật thất bại! "
                        + "Vui lòng thay đổi thông tin.",
                        "Thông báo lỗi", JOptionPane.ERROR_MESSAGE, this.ico_failure);
            }
        }
    }//GEN-LAST:event_btnCapNhatActionPerformed

    private void btnDanhSachQuaHanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDanhSachQuaHanActionPerformed
        new OutDateFrm(this, rootPaneCheckingEnabled).setVisible(true);
    }//GEN-LAST:event_btnDanhSachQuaHanActionPerformed

    private void txtTimKiemDGMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemDGMouseClicked
        txtTimKiemDG.setText("");
    }//GEN-LAST:event_txtTimKiemDGMouseClicked

    private void txtTimKiemTGMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemTGMouseClicked
        txtTimKiemTG.setText("");
    }//GEN-LAST:event_txtTimKiemTGMouseClicked

    private void txtTimKiemSTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemSTMouseClicked
        txtTimKiemST.setText("");
    }//GEN-LAST:event_txtTimKiemSTMouseClicked

    private void txtTimKiemNXBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemNXBMouseClicked
        txtTimKiemNXB.setText("");
    }//GEN-LAST:event_txtTimKiemNXBMouseClicked

    private void txtTimKiemCSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemCSMouseClicked
        txtTimKiemCS.setText("");
    }//GEN-LAST:event_txtTimKiemCSMouseClicked

    private void txtTimKiemTTPNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemTTPNMouseClicked
        txtTimKiemTTPN.setText("");
    }//GEN-LAST:event_txtTimKiemTTPNMouseClicked

    private void txtTimKiemCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemCTMouseClicked
        txtTimKiemCT.setText("");
    }//GEN-LAST:event_txtTimKiemCTMouseClicked

    private void txtTimKiemPTLMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemPTLMouseClicked
        txtTimKiemPTL.setText("");
    }//GEN-LAST:event_txtTimKiemPTLMouseClicked

    private void txtTimKiemLPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemLPMouseClicked
        txtTimKiemLP.setText("");
    }//GEN-LAST:event_txtTimKiemLPMouseClicked

    private void txtTimKiemPMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemPMMouseClicked
        txtTimKiemPM.setText("");
    }//GEN-LAST:event_txtTimKiemPMMouseClicked

    private void txtTimKiemPTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemPTMouseClicked
        txtTimKiemPT.setText("");
    }//GEN-LAST:event_txtTimKiemPTMouseClicked

    private void txtTimKiemPPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtTimKiemPPMouseClicked
        txtTimKiemPP.setText("");
    }//GEN-LAST:event_txtTimKiemPPMouseClicked

    private void initLoginFrm() {
        new LoginFrm(this, rootPaneCheckingEnabled).setVisible(true);
        if (this.quanLy == null) {
            System.exit(0);
        } else {
            this.tabbedQuanLy.setSelectedIndex(0);
            this.setVisible(true);
        }
    }

    private void checkDocGiaQuaHanLePhi() {
        Map<String, Calendar> filterMap = listLePhi.stream().collect(
                Collectors.toMap(LePhi::getiDDocGia, LePhi::getNgayThucHien,
                        (a, b) -> a.after(b) ? a : b));
        Calendar today = Calendar.getInstance();
        listDocGia.stream().forEach(e -> {
            Calendar ngayDong = filterMap.get(e.getiD());
            if (ngayDong == null) {
                e.setDaHuy(true);
                sqlDocGia.updateList(e.getiD(), true);
                btnLamMoiDG.doClick();
            } else {
                if (today.after(system.getNgayQuaHan(ngayDong))) {
                    e.setDaHuy(true);
                    sqlDocGia.updateList(e.getiD(), true);
                    btnLamMoiDG.doClick();
                }
            }
        });
    }

    public final List<String> getSachMuon() {
        return listCuonSach.stream().filter(e -> e.getDichVu().equals("Được mượn")
                && e.getTrangThai().equals("Chưa mượn")).map(e -> e.getiD()).
                collect(Collectors.toList());
    }

    public final void setSachMuon(List<String> dsSachMuon) {
        txaSachMuon.setText(dsSachMuon.stream().reduce((a, b) -> "%s\n%s".formatted(a, b)).get());
    }

    public final boolean isDangNhapThanhCong(String taiKhoan, String matKhau) {
        Optional<TaiKhoan> item = listTaiKhoan.stream().filter(e -> e.getTenDangNhap().
                equals(taiKhoan) && e.getMatKhau().equals(matKhau)).findFirst();
        if (item.isPresent()) {
            String iDThuThu = item.get().getiDThuThu();
            quanLy = listThuThu.stream().filter(e -> e.getiD().equals(iDThuThu)).
                    findFirst().get();
            txtIDQL.setText(quanLy.getiD());
            txtHoTenQL.setText(quanLy.getHoTen());
            Calendar ngaySinh = quanLy.getNgaySinh();
            cboNgayQL.setSelectedItem(String.valueOf(ngaySinh.get(Calendar.DAY_OF_MONTH)));
            cboThangQL.setSelectedItem(String.valueOf(ngaySinh.get(Calendar.MONTH) + 1));
            cboNamQL.setSelectedItem(String.valueOf(ngaySinh.get(Calendar.YEAR)));
            txtDiaChiQL.setText(quanLy.getDiaChi());
            txtEmailQL.setText(quanLy.getEmail());
            txtThuThuPN.setText(iDThuThu);
            txtThuThuPTL.setText(iDThuThu);
            txtThuThuLP.setText(iDThuThu);
            txtThuThuPM.setText(iDThuThu);
            txtThuThuPP.setText(iDThuThu);
            if (quanLy.getPhai().equals("Nam")) {
                rbtnNamQL.setSelected(true);
            } else {
                rbtnNuQL.setSelected(true);
            }
            return true;
        }
        return false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomeFrm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new HomeFrm().setVisible(true);

                } catch (Exception ex) {
                    Logger.getLogger(HomeFrm.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btgPhaiDG;
    private javax.swing.ButtonGroup btgPhaiQL;
    private javax.swing.ButtonGroup btgPhaiTG;
    private javax.swing.JButton btnCapNhat;
    private javax.swing.JButton btnDangXuat;
    private javax.swing.JButton btnDanhSachQuaHan;
    private javax.swing.JButton btnLamMoiCS;
    private javax.swing.JButton btnLamMoiCT;
    private javax.swing.JButton btnLamMoiDG;
    private javax.swing.JButton btnLamMoiDS;
    private javax.swing.JButton btnLamMoiLP;
    private javax.swing.JButton btnLamMoiNXB;
    private javax.swing.JButton btnLamMoiPM;
    private javax.swing.JButton btnLamMoiPN;
    private javax.swing.JButton btnLamMoiPP;
    private javax.swing.JButton btnLamMoiPT;
    private javax.swing.JButton btnLamMoiPTL;
    private javax.swing.JButton btnLamMoiST;
    private javax.swing.JButton btnLamMoiTG;
    private javax.swing.JButton btnLamMoiTS;
    private javax.swing.JButton btnSuaCS;
    private javax.swing.JButton btnSuaDG;
    private javax.swing.JButton btnSuaDS;
    private javax.swing.JButton btnSuaNXB;
    private javax.swing.JButton btnSuaPT;
    private javax.swing.JButton btnSuaTG;
    private javax.swing.JButton btnThemCS;
    private javax.swing.JButton btnThemCT;
    private javax.swing.JButton btnThemDG;
    private javax.swing.JButton btnThemDS;
    private javax.swing.JButton btnThemK;
    private javax.swing.JButton btnThemLP;
    private javax.swing.JButton btnThemN;
    private javax.swing.JButton btnThemNXB;
    private javax.swing.JButton btnThemPM;
    private javax.swing.JButton btnThemPN;
    private javax.swing.JButton btnThemPP;
    private javax.swing.JButton btnThemPTL;
    private javax.swing.JButton btnThemST;
    private javax.swing.JButton btnThemTG;
    private javax.swing.JButton btnThemTS;
    private javax.swing.JButton btnTimKiemCS;
    private javax.swing.JButton btnTimKiemCT;
    private javax.swing.JButton btnTimKiemDG;
    private javax.swing.JButton btnTimKiemDS;
    private javax.swing.JButton btnTimKiemK;
    private javax.swing.JButton btnTimKiemLP;
    private javax.swing.JButton btnTimKiemN;
    private javax.swing.JButton btnTimKiemPM;
    private javax.swing.JButton btnTimKiemPP;
    private javax.swing.JButton btnTimKiemPT;
    private javax.swing.JButton btnTimKiemPTL;
    private javax.swing.JButton btnTimKiemST;
    private javax.swing.JButton btnTimKiemTG;
    private javax.swing.JButton btnTimKiemTTPN;
    private javax.swing.JButton btnTimKiemXNB;
    private javax.swing.JButton btnXoaCT;
    private javax.swing.JButton btnXoaDS;
    private javax.swing.JButton btnXoaK;
    private javax.swing.JButton btnXoaLP;
    private javax.swing.JButton btnXoaN;
    private javax.swing.JButton btnXoaNXB;
    private javax.swing.JButton btnXoaPN;
    private javax.swing.JButton btnXoaPP;
    private javax.swing.JButton btnXoaPT;
    private javax.swing.JButton btnXoaPTL;
    private javax.swing.JButton btnXoaST;
    private javax.swing.JButton btnXoaTG;
    private javax.swing.JButton btnXoaTS;
    private javax.swing.JComboBox<String> cboDauSachCS;
    private javax.swing.JComboBox<String> cboDauSachCT;
    private javax.swing.JComboBox<String> cboDauSachST;
    private javax.swing.JComboBox<String> cboDichVu;
    private javax.swing.JComboBox<String> cboDocGiaLP;
    private javax.swing.JComboBox<String> cboDocGiaPM;
    private javax.swing.JComboBox<String> cboDocGiaPP;
    private javax.swing.JComboBox<String> cboKeTS;
    private javax.swing.JComboBox<String> cboKho;
    private javax.swing.JComboBox<String> cboNamDG;
    private javax.swing.JComboBox<String> cboNamLP;
    private javax.swing.JComboBox<String> cboNamPM;
    private javax.swing.JComboBox<String> cboNamPN;
    private javax.swing.JComboBox<String> cboNamPP;
    private javax.swing.JComboBox<String> cboNamPT;
    private javax.swing.JComboBox<String> cboNamPTL;
    private javax.swing.JComboBox<String> cboNamQL;
    private javax.swing.JComboBox<String> cboNamTG;
    private javax.swing.JComboBox<String> cboNamXuatBan;
    private javax.swing.JComboBox<String> cboNganCS;
    private javax.swing.JComboBox<String> cboNganTS;
    private javax.swing.JComboBox<String> cboNgayDG;
    private javax.swing.JComboBox<String> cboNgayLP;
    private javax.swing.JComboBox<String> cboNgayPM;
    private javax.swing.JComboBox<String> cboNgayPN;
    private javax.swing.JComboBox<String> cboNgayPP;
    private javax.swing.JComboBox<String> cboNgayPT;
    private javax.swing.JComboBox<String> cboNgayPTL;
    private javax.swing.JComboBox<String> cboNgayQL;
    private javax.swing.JComboBox<String> cboNgayTG;
    private javax.swing.JComboBox<String> cboNhaXuatBanDS;
    private javax.swing.JComboBox<String> cboPhieuNhapCT;
    private javax.swing.JComboBox<String> cboPhieuThanhLyCS;
    private javax.swing.JComboBox<String> cboTacGiaST;
    private javax.swing.JComboBox<String> cboThangDG;
    private javax.swing.JComboBox<String> cboThangLP;
    private javax.swing.JComboBox<String> cboThangPM;
    private javax.swing.JComboBox<String> cboThangPN;
    private javax.swing.JComboBox<String> cboThangPP;
    private javax.swing.JComboBox<String> cboThangPT;
    private javax.swing.JComboBox<String> cboThangPTL;
    private javax.swing.JComboBox<String> cboThangQL;
    private javax.swing.JComboBox<String> cboThangTG;
    private javax.swing.JCheckBox ckbDaHuy;
    private javax.swing.JCheckBox ckbDaMat;
    private javax.swing.JCheckBox ckbGiaHan;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblChiPhi;
    private javax.swing.JLabel lblCuonSachPT;
    private javax.swing.JLabel lblDauSachCS;
    private javax.swing.JLabel lblDauSachST;
    private javax.swing.JLabel lblDiaChiDG;
    private javax.swing.JLabel lblDiaChiNXB;
    private javax.swing.JLabel lblDiaChiQL;
    private javax.swing.JLabel lblDiaChiTG;
    private javax.swing.JLabel lblDichVu;
    private javax.swing.JLabel lblDocGiaLP;
    private javax.swing.JLabel lblDocGiaPM;
    private javax.swing.JLabel lblDocGiaPP;
    private javax.swing.JLabel lblDonGia;
    private javax.swing.JLabel lblEmailDG;
    private javax.swing.JLabel lblEmailNXB;
    private javax.swing.JLabel lblEmailQL;
    private javax.swing.JLabel lblEmailTG;
    private javax.swing.JLabel lblGiaHan;
    private javax.swing.JLabel lblGiaThanhLy;
    private javax.swing.JLabel lblHoTenDG;
    private javax.swing.JLabel lblHoTenQL;
    private javax.swing.JLabel lblHoTenST;
    private javax.swing.JLabel lblHoTenTG;
    private javax.swing.JLabel lblIDCS;
    private javax.swing.JLabel lblIDDG;
    private javax.swing.JLabel lblIDDS;
    private javax.swing.JLabel lblIDDauSachCT;
    private javax.swing.JLabel lblIDKeTS;
    private javax.swing.JLabel lblIDLP;
    private javax.swing.JLabel lblIDNXB;
    private javax.swing.JLabel lblIDNganTS;
    private javax.swing.JLabel lblIDPM;
    private javax.swing.JLabel lblIDPN;
    private javax.swing.JLabel lblIDPP;
    private javax.swing.JLabel lblIDPTL;
    private javax.swing.JLabel lblIDPhieuNhapCT;
    private javax.swing.JLabel lblIDQL;
    private javax.swing.JLabel lblIDTG;
    private javax.swing.JLabel lblKeSach;
    private javax.swing.JLabel lblKho;
    private javax.swing.JLabel lblLyDo;
    private javax.swing.JLabel lblNamXuatBan;
    private javax.swing.JLabel lblNganCS;
    private javax.swing.JLabel lblNganSach;
    private javax.swing.JLabel lblNgayDong;
    private javax.swing.JLabel lblNgayLap;
    private javax.swing.JLabel lblNgayMuon;
    private javax.swing.JLabel lblNgayNhap;
    private javax.swing.JLabel lblNgayQuaHan;
    private javax.swing.JLabel lblNgaySinhDG;
    private javax.swing.JLabel lblNgaySinhQL;
    private javax.swing.JLabel lblNgaySinhTG;
    private javax.swing.JLabel lblNgayThanhLy;
    private javax.swing.JLabel lblNgayTra;
    private javax.swing.JLabel lblNhaXuatBan;
    private javax.swing.JLabel lblPhaiDG;
    private javax.swing.JLabel lblPhaiQL;
    private javax.swing.JLabel lblPhaiTG;
    private javax.swing.JLabel lblPhieuMuonPT;
    private javax.swing.JLabel lblPhieuThanhLyCS;
    private javax.swing.JLabel lblSDTDG;
    private javax.swing.JLabel lblSDTNXB;
    private javax.swing.JLabel lblSachMuon;
    private javax.swing.JLabel lblSoLuong;
    private javax.swing.JLabel lblTTPN;
    private javax.swing.JLabel lblTacGiaST;
    private javax.swing.JLabel lblTenSach;
    private javax.swing.JLabel lblTenSachCT;
    private javax.swing.JLabel lblTenSachST;
    private javax.swing.JLabel lblTenXNB;
    private javax.swing.JLabel lblThanhTienPN;
    private javax.swing.JLabel lblThanhTienPTL;
    private javax.swing.JLabel lblTheLoai;
    private javax.swing.JLabel lblThongTinDauSach;
    private javax.swing.JLabel lblThongTinKeSach;
    private javax.swing.JLabel lblThongTinNganSach;
    private javax.swing.JLabel lblThongTinPhieuNhap;
    private javax.swing.JLabel lblThongTinQuanLy;
    private javax.swing.JLabel lblThongTinTacGia;
    private javax.swing.JLabel lblThongTinTacPham;
    private javax.swing.JLabel lblThuThuLP;
    private javax.swing.JLabel lblThuThuPM;
    private javax.swing.JLabel lblThuThuPP;
    private javax.swing.JLabel lblThuThuPT;
    private javax.swing.JLabel lblThuThuPTL;
    private javax.swing.JLabel lblTimKiemCS;
    private javax.swing.JLabel lblTimKiemCT;
    private javax.swing.JLabel lblTimKiemDG;
    private javax.swing.JLabel lblTimKiemDS;
    private javax.swing.JLabel lblTimKiemK;
    private javax.swing.JLabel lblTimKiemLP;
    private javax.swing.JLabel lblTimKiemN;
    private javax.swing.JLabel lblTimKiemNXB;
    private javax.swing.JLabel lblTimKiemPM;
    private javax.swing.JLabel lblTimKiemPN;
    private javax.swing.JLabel lblTimKiemPP;
    private javax.swing.JLabel lblTimKiemPT;
    private javax.swing.JLabel lblTimKiemPTL;
    private javax.swing.JLabel lblTimKiemST;
    private javax.swing.JLabel lblTimKiemTG;
    private javax.swing.JLabel lblTrangThaiCS;
    private javax.swing.JLabel lblTrangThaiDG;
    private javax.swing.JLabel lblTrangThaiPT;
    private javax.swing.JLabel lblXuPhat;
    private javax.swing.JPanel pnlQuanLy;
    private javax.swing.JPanel pnlThongTinCS;
    private javax.swing.JPanel pnlThongTinCT;
    private javax.swing.JPanel pnlThongTinDG;
    private javax.swing.JPanel pnlThongTinDS;
    private javax.swing.JPanel pnlThongTinLP;
    private javax.swing.JPanel pnlThongTinNXB;
    private javax.swing.JPanel pnlThongTinNXB1;
    private javax.swing.JPanel pnlThongTinPM;
    private javax.swing.JPanel pnlThongTinPN;
    private javax.swing.JPanel pnlThongTinPP;
    private javax.swing.JPanel pnlThongTinPT;
    private javax.swing.JPanel pnlThongTinQuanLy;
    private javax.swing.JPanel pnlThongTinST;
    private javax.swing.JPanel pnlThongTinTG;
    private javax.swing.JPanel pnlThongTinTS;
    private javax.swing.JRadioButton rbtnNamQL;
    private javax.swing.JRadioButton rbtnNuQL;
    private javax.swing.JRadioButton rdbNamDG;
    private javax.swing.JRadioButton rdbNamTG;
    private javax.swing.JRadioButton rdbNuDG;
    private javax.swing.JRadioButton rdbNuTG;
    private javax.swing.JScrollPane scrChiTietPhieuNhap;
    private javax.swing.JScrollPane scrCuonSach;
    private javax.swing.JScrollPane scrDauSach;
    private javax.swing.JScrollPane scrDocGia;
    private javax.swing.JScrollPane scrKe;
    private javax.swing.JScrollPane scrLePhi;
    private javax.swing.JScrollPane scrNgan;
    private javax.swing.JScrollPane scrNhaXuatBan;
    private javax.swing.JScrollPane scrPhieuMuon;
    private javax.swing.JScrollPane scrPhieuPhat;
    private javax.swing.JScrollPane scrPhieuThanhLy;
    private javax.swing.JScrollPane scrPhieuTra;
    private javax.swing.JScrollPane scrSangTac;
    private javax.swing.JScrollPane scrThongTinPhieuNhap;
    private javax.swing.JScrollPane scrThongTinTacGia;
    private javax.swing.JPanel tabChiTietPN;
    private javax.swing.JPanel tabCuonSach;
    private javax.swing.JPanel tabDauSach;
    private javax.swing.JPanel tabDocGia;
    private javax.swing.JPanel tabHoaDon;
    private javax.swing.JPanel tabLePhi;
    private javax.swing.JPanel tabNhaXuatBan;
    private javax.swing.JPanel tabPhieuMuon;
    private javax.swing.JPanel tabPhieuNhap;
    private javax.swing.JPanel tabPhieuPhat;
    private javax.swing.JPanel tabPhieuThanhLy;
    private javax.swing.JPanel tabPhieuTra;
    private javax.swing.JPanel tabSangTac;
    private javax.swing.JPanel tabTacGia;
    private javax.swing.JPanel tabThongTinPN;
    private javax.swing.JPanel tabThongTinTG;
    private javax.swing.JPanel tabTuSach;
    private javax.swing.JTabbedPane tabbedPhieuNhap;
    private javax.swing.JTabbedPane tabbedQuanLy;
    private javax.swing.JTabbedPane tabbedQuanLyHoaDon;
    private javax.swing.JTabbedPane tabbedQuanLyTacGia;
    private javax.swing.JTable tblChiTietPhieuNhap;
    private javax.swing.JTable tblCuonSach;
    private javax.swing.JTable tblDauSach;
    private javax.swing.JTable tblDocGia;
    private javax.swing.JTable tblKe;
    private javax.swing.JTable tblLePhi;
    private javax.swing.JTable tblNgan;
    private javax.swing.JTable tblNhaXuatBan;
    private javax.swing.JTable tblPhieuMuon;
    private javax.swing.JTable tblPhieuPhat;
    private javax.swing.JTable tblPhieuThanhLy;
    private javax.swing.JTable tblPhieuTra;
    private javax.swing.JTable tblSangTac;
    private javax.swing.JTable tblTacGia;
    private javax.swing.JTable tblThongTinPhieuNhap;
    private javax.swing.JTextArea txaSachMuon;
    private javax.swing.JTextField txtChiPhi;
    private javax.swing.JTextField txtCuonSachPT;
    private javax.swing.JTextField txtDiaChiDG;
    private javax.swing.JTextField txtDiaChiNXB;
    private javax.swing.JTextField txtDiaChiQL;
    private javax.swing.JTextField txtDiaChiTG;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtEmailDG;
    private javax.swing.JTextField txtEmailNXB;
    private javax.swing.JTextField txtEmailQL;
    private javax.swing.JTextField txtEmailTG;
    private javax.swing.JTextField txtGiaThanhLy;
    private javax.swing.JTextField txtHoTenDG;
    private javax.swing.JTextField txtHoTenQL;
    private javax.swing.JTextField txtHoTenST;
    private javax.swing.JTextField txtHoTenTG;
    private javax.swing.JTextField txtIDCS;
    private javax.swing.JTextField txtIDDG;
    private javax.swing.JTextField txtIDDS;
    private javax.swing.JTextField txtIDLP;
    private javax.swing.JTextField txtIDNXB;
    private javax.swing.JTextField txtIDPM;
    private javax.swing.JTextField txtIDPN;
    private javax.swing.JTextField txtIDPP;
    private javax.swing.JTextField txtIDPTL;
    private javax.swing.JTextField txtIDQL;
    private javax.swing.JTextField txtIDTG;
    private javax.swing.JTextField txtLyDo;
    private javax.swing.JTextField txtNgayQuaHan;
    private javax.swing.JTextField txtPhieuMuonPT;
    private javax.swing.JTextField txtSDTDG;
    private javax.swing.JTextField txtSDTNXB;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenNXB;
    private javax.swing.JTextField txtTenSach;
    private javax.swing.JTextField txtTenSachCT;
    private javax.swing.JTextField txtTenSachST;
    private javax.swing.JTextField txtThanhTienPN;
    private javax.swing.JTextField txtThanhTienPTL;
    private javax.swing.JTextField txtTheLoai;
    private javax.swing.JTextField txtThuThuLP;
    private javax.swing.JTextField txtThuThuPM;
    private javax.swing.JTextField txtThuThuPN;
    private javax.swing.JTextField txtThuThuPP;
    private javax.swing.JTextField txtThuThuPT;
    private javax.swing.JTextField txtThuThuPTL;
    private javax.swing.JTextField txtTimKiemCS;
    private javax.swing.JTextField txtTimKiemCT;
    private javax.swing.JTextField txtTimKiemDG;
    private javax.swing.JTextField txtTimKiemDS;
    private javax.swing.JTextField txtTimKiemK;
    private javax.swing.JTextField txtTimKiemLP;
    private javax.swing.JTextField txtTimKiemN;
    private javax.swing.JTextField txtTimKiemNXB;
    private javax.swing.JTextField txtTimKiemPM;
    private javax.swing.JTextField txtTimKiemPP;
    private javax.swing.JTextField txtTimKiemPT;
    private javax.swing.JTextField txtTimKiemPTL;
    private javax.swing.JTextField txtTimKiemST;
    private javax.swing.JTextField txtTimKiemTG;
    private javax.swing.JTextField txtTimKiemTTPN;
    private javax.swing.JTextField txtTrangThaiCS;
    private javax.swing.JTextField txtXuPhat;
    // End of variables declaration//GEN-END:variables
}
