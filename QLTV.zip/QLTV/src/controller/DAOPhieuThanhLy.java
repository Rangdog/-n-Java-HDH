package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.PhieuThanhLy;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAOPhieuThanhLy {

    private final Connection connection;

    public DAOPhieuThanhLy() throws Exception {
        connection = DAO_SQL.getConnection();
    }

    public List<PhieuThanhLy> getList() {
        List<PhieuThanhLy> listPhieuThanhLy = new ArrayList<>();
        String sql = "SELECT * FROM PHIEUTHANHLY";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                PhieuThanhLy e = new PhieuThanhLy();
                e.setiD(result.getString("ID"));
                e.setiDThuThu(result.getString("ID_THUTHU"));
                Calendar ngayThanhLy = (Calendar) Calendar.getInstance();
                ngayThanhLy.setTime(result.getDate("NGAYTHANHLY"));
                e.setNgayThucHien(ngayThanhLy);
                listPhieuThanhLy.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuThanhLy.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listPhieuThanhLy.isEmpty()) {
            PhieuThanhLy.setiDCounter(Integer.parseInt(listPhieuThanhLy.get(listPhieuThanhLy.
                    size() - 1).getiD().substring(2, 8)) + 1);
        }
        return listPhieuThanhLy;
    }

    public boolean insertList(PhieuThanhLy e) {
        String sql = "INSERT INTO PHIEUTHANHLY "
                + "VALUES(?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getiDThuThu());
            ps.setDate(3, new Date(e.getNgayThucHien().getTimeInMillis()));
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuThanhLy.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM PHIEUTHANHLY "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuThanhLy.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
