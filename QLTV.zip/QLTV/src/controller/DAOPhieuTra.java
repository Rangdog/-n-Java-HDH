package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.PhieuTra;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAOPhieuTra {

    private final Connection connection;

    public DAOPhieuTra() throws Exception {
        connection = DAO_SQL.getConnection();
    }

    public List<PhieuTra> getList() {
        List<PhieuTra> listPhieuTra = new ArrayList<>();
        String sql = "SELECT * FROM PHIEUTRA";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                PhieuTra e = new PhieuTra();
                e.setiDPhieuMuon(result.getString("ID_PHIEUMUON"));
                e.setiDCuonSach(result.getString("ID_CUONSACH"));
                if (result.getString("ID_THUTHU") == null) {
                    e.setiDThuThu("");
                    e.setNgayTra(null);
                } else {
                    e.setiDThuThu(result.getString("ID_THUTHU"));
                    Calendar ngayTra = Calendar.getInstance();
                    ngayTra.setTime(result.getDate("NGAYTRA"));
                    e.setNgayTra(ngayTra);
                }
                e.setDaGiaHan(result.getBoolean("DAGIAHAN"));
                e.setDaMat(result.getBoolean("DAMAT"));
                listPhieuTra.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuTra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listPhieuTra;
    }

    public boolean insertList(PhieuTra e) {
        String sql = "INSERT INTO PHIEUTRA "
                + "VALUES(?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiDPhieuMuon());
            ps.setString(2, e.getiDCuonSach());
            if (!e.getiDThuThu().isEmpty()) {
                ps.setString(3, e.getiDThuThu());
                ps.setDate(4, new Date(e.getNgayTra().getTimeInMillis()));
            } else {
                ps.setNull(3, Types.VARCHAR);
                ps.setNull(4, Types.DATE);
            }
            ps.setBoolean(5, e.isDaGiaHan());
            ps.setBoolean(6, e.isDaMat());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuTra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updateList(String idPhieuMuon, String iDCuonSach, String iDThuThu,
            Calendar ngayTra, boolean daGiaHan, boolean daMat) {
        String sql = "UPDATE PHIEUTRA "
                + "SET ID_THUTHU = ?,NGAYTRA = ? ,DAGIAHAN = ?, DAMAT = ? "
                + "WHERE ID_PHIEUMUON = ? AND ID_CUONSACH = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(5, idPhieuMuon);
            ps.setString(6, iDCuonSach);
            if (!iDThuThu.isEmpty()) {
                ps.setString(1, iDThuThu);
                ps.setDate(2, new Date(ngayTra.getTimeInMillis()));
            } else {
                ps.setNull(1, Types.VARCHAR);
                ps.setNull(2, Types.DATE);
            }
            ps.setBoolean(3, daGiaHan);
            ps.setBoolean(4, daMat);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuTra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iDPhieuMuon, String iDCuonSach) {
        String sql = "DELETE FROM PHIEUTRA "
                + "WHERE ID_PHIEUMUON = ? AND ID_CUONSACH = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iDPhieuMuon);
            ps.setString(2, iDCuonSach);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuTra.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
