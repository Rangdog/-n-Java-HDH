package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ChiTietPhieuNhap;
import model.PhieuNhap;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAOPhieuNhap {

    private final Connection connection;

    public DAOPhieuNhap() throws Exception {
        connection = DAO_SQL.getConnection();
    }

    public List<PhieuNhap> getList(List<ChiTietPhieuNhap> listChiTietPhieuNhap) {
        List<PhieuNhap> listPhieuNhap = new ArrayList<>();
        String sql = "SELECT * FROM PHIEUNHAP";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                PhieuNhap e = new PhieuNhap();
                e.setiD(result.getString("ID"));
                e.setiDThuThu(result.getString("ID_THUTHU"));
                Calendar ngayNhap = Calendar.getInstance();
                ngayNhap.setTime(result.getDate("NGAYNHAP"));
                e.setNgayThucHien(ngayNhap);
                listPhieuNhap.add(e);
                listChiTietPhieuNhap.add(new ChiTietPhieuNhap(e.getiD()));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listPhieuNhap.isEmpty()) {
            PhieuNhap.setiDCounter(Integer.parseInt(listPhieuNhap.get(listPhieuNhap.
                    size() - 1).getiD().substring(2, 8)) + 1);
        }
        return listPhieuNhap;
    }

    public boolean insertList(PhieuNhap e) {
        String sql = "INSERT INTO PHIEUNHAP "
                + "VALUES(?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getiDThuThu());
            ps.setDate(3, new Date(e.getNgayThucHien().getTimeInMillis()));
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM PHIEUNHAP "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuNhap.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
