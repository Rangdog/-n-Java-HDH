package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.DauSach;

/**
 *
 * @author BIN BIN
 */
public class DAODauSach {

    private final Connection connection;

    public DAODauSach() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<DauSach> getList() {
        List<DauSach> listDauSach = new ArrayList<>();
        String sql = "SELECT * FROM DAUSACH";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                DauSach e = new DauSach();
                e.setiD(result.getString("ID"));
                e.setTenSach(result.getString("TEN"));
                e.setTheLoai(result.getString("THELOAI"));
                e.setDonGia(result.getFloat("DONGIA"));
                e.setNamXuatBan(result.getInt("NAMXUATBAN"));
                e.setIDNhaXuatBan(result.getString("ID_NHAXUATBAN"));
                listDauSach.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAODauSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listDauSach;
    }

    public boolean updateList(String oldID, String iD, String tenSach, String theLoai,
            float donGia, int namXuatBan, String iDNhaXuatBan) {
        String sql = "UPDATE DAUSACH "
                + "SET ID = ?, TEN = ?, THELOAI = ?, DONGIA = ?, NAMXUATBAN = ?, ID_NHAXUATBAN = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            ps.setString(2, tenSach);
            ps.setString(3, theLoai);
            ps.setFloat(4, donGia);
            ps.setInt(5, namXuatBan);
            ps.setString(6, iDNhaXuatBan);
            ps.setString(7, oldID);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAODauSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean insertList(DauSach e) {
        String sql = "INSERT INTO DAUSACH "
                + "VALUES(?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getTenSach());
            ps.setString(3, e.getTheLoai());
            ps.setFloat(4, e.getDonGia());
            ps.setInt(5, e.getNamXuatBan());
            ps.setString(6, e.getIDNhaXuatBan());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAODauSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM DAUSACH "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAODauSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
