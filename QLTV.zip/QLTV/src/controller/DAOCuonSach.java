package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.CuonSach;

/**
 *
 * @author BIN BIN
 */
public class DAOCuonSach {

    private final Connection connection;

    public DAOCuonSach() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public List<CuonSach> getList() {
        List<CuonSach> listCuonSach = new ArrayList<>();
        String sql = "SELECT * FROM CUONSACH";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                CuonSach e = new CuonSach();
                e.setiD(result.getString("ID"));
                e.setKho(result.getString("KHO"));
                e.setDichVu(result.getString("DICHVU"));
                e.setiDDauSach(result.getString("ID_DAUSACH"));
                e.setiDNgan(result.getString("ID_NGAN"));
                String iDPhieuThanhLy = result.getString("ID_PHIEUTHANHLY");
                if (iDPhieuThanhLy == null) {
                    e.setiDPhieuThanhLy("");
                } else {
                    e.setiDPhieuThanhLy(iDPhieuThanhLy);
                    e.setGiaThanhLy(result.getFloat("GIATHANHLY"));
                }
                e.setTrangThai(result.getString("TRANGTHAI"));
                listCuonSach.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOCuonSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listCuonSach.isEmpty()) {
            CuonSach.setiDCounter(Integer.parseInt(listCuonSach.get(listCuonSach.
                    size() - 1).getiD().substring(2, 7)) + 1);
        }
        return listCuonSach;
    }

    public boolean insertList(CuonSach e) {
        String sql = "INSERT INTO CUONSACH "
                + "VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getKho());
            ps.setString(3, e.getDichVu());
            ps.setString(4, e.getiDDauSach());
            ps.setString(5, e.getiDNgan());
            ps.setNull(6, Types.FLOAT);
            ps.setNull(7, Types.VARCHAR);
            ps.setString(8, e.getTrangThai());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOCuonSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean updateList(String iD, String Kho, String dichVu, String iDDauSach,
            String iDNgan, Float giaThanhLy, String iDPhieuThanhLy, String trangThai) {
        String sql = "UPDATE CUONSACH "
                + "SET KHO = ?, DICHVU = ?, ID_DAUSACH = ?, ID_NGAN = ?, TRANGTHAI = ?, "
                + "GIATHANHLY = ?, ID_PHIEUTHANHLY = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, Kho);
            ps.setString(2, dichVu);
            ps.setString(3, iDDauSach);
            ps.setString(4, iDNgan);
            ps.setString(5, trangThai);
            if (iDPhieuThanhLy.isEmpty()) {
                ps.setNull(6, Types.FLOAT);
                ps.setNull(7, Types.VARCHAR);
            } else {
                ps.setFloat(6, giaThanhLy);
                ps.setString(7, iDPhieuThanhLy);
            }
            ps.setString(8, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOCuonSach.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public void updateList(String iD, String trangThai) {
        String sql = "UPDATE CUONSACH "
                + "SET TRANGTHAI = ? "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, trangThai);
            ps.setString(2, iD);
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DAOCuonSach.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
