package controller;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import model.*;

/**
 *
 * @author Phu Dự Thắng & Hà Xuân Thanh
 */
public class Controller {

    private final Connection connection;

    public Controller() throws Exception {
        this.connection = DAO_SQL.getConnection();
    }

    public boolean isQuanLy(String iD, List<ThuThu> listTT) {
        return listTT.stream().anyMatch(e -> e.getiD().equals(iD));
    }

    public boolean isCoSachQuaHan(String iDDocGia, List<PhieuMuon> listPM,
            List<PhieuTra> listPT) {
        // Lấy danh sách phiếu mượn & ngày mượn của độc giả.
        Map<String, Calendar> filterMap = listPM.stream().filter(e -> e.getiDDocGia().
                equals(iDDocGia)).collect(Collectors.toMap(PhieuMuon::getiD, PhieuMuon::getNgayThucHien));
        Calendar today = Calendar.getInstance();
        // Kiểm tra thông tin quá hạn của phiếu trả.
        return listPT.stream().filter(e -> filterMap.containsKey(e.getiDPhieuMuon())
                && e.getiDThuThu().isEmpty()).anyMatch(e -> today.after(
                getNgayQuaHan(filterMap.get(e.getiDPhieuMuon()), e.isDaGiaHan())));
    }

    public boolean isDaVaoHeThong(String iDDS, SanPham sanPham,
            List<ChiTietPhieuNhap> listCTPN, List<CuonSach> listCS) {
        // Lấy thông tin tổng số lượng sách của đầu sách trong hệ thống.
        int tongSoLuong = listCTPN.stream().map(e -> e.getDanhSach()).map(e -> {
            Optional<SanPham> tmp = e.stream().filter(s -> s.getiDDauSach().
                    equals(iDDS)).findFirst();
            return tmp.isPresent() ? tmp.get().getSoLuong() : 0;
        }).reduce((a, b) -> a + b).get();
        // Lấy thông tin số lượng hiện có của đầu sách trong hệ thống.
        long soLuongHienCo = listCS.stream().filter(e -> e.getiDDauSach().
                equals(iDDS)).count();
        int soLuongLoaiBo = sanPham.getSoLuong();
        // Kiểm tra sách đã được nhập vào hệ thống.
        return soLuongHienCo > tongSoLuong - soLuongLoaiBo;
    }

    public float getTongTienPN(String iD, List<ChiTietPhieuNhap> listCTPN,
            List<DauSach> listDS) {
        // Lấy thống tin về danh sách sản phẩm.
        List<SanPham> dsSanPham = listCTPN.stream().filter(e -> e.getiD().
                equals(iD)).findFirst().get().getDanhSach();
        // Lấy thông tin về đơn giá của danh sách sản phẩm.
        Map<String, Float> filterMap = new HashMap<>();
        dsSanPham.forEach(e -> {
            String iDDauSach = e.getiDDauSach();
            Float donGia = listDS.stream().filter(ds -> ds.getiD().equals(iDDauSach)).
                    findFirst().get().getDonGia();
            filterMap.put(iDDauSach, donGia);
        });
        // Tính toán thành tiền.
        Optional<Float> thanhTien = dsSanPham.stream().map(e -> e.getSoLuong()
                * filterMap.get(e.getiDDauSach())).reduce((a, b) -> a + b);
        if (thanhTien.isPresent()) {
            return thanhTien.get();
        }
        return 0;
    }

    public float getTongTienPTL(String iD, List<CuonSach> listCS) {
        Optional<Float> thanhTien = listCS.stream().filter(e -> e.getiDPhieuThanhLy().
                equals(iD)).map(e -> e.getGiaThanhLy()).reduce((a, b) -> a + b);
        if (thanhTien.isPresent()) {
            return thanhTien.get();
        }
        return 0;
    }

    public List<DocGiaQuaHan> getDanhSachMuonSachQuaHan() {
        List<DocGiaQuaHan> listQuaHan = new ArrayList<>();
        String sql = "{CALL FILTER_DOC_GIA_QUA_HAN()}";
        try {
            CallableStatement cs = connection.prepareCall(sql);
            ResultSet result = cs.executeQuery();
            while (result.next()) {
                DocGiaQuaHan e = new DocGiaQuaHan(result.getString(1), result.getString(2),
                        result.getString(3), result.getString(4), result.getInt(5));
                listQuaHan.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listQuaHan;
    }

    public Calendar getNgayQuaHan(Calendar ngayMuon, boolean daGiaHan) {
        Calendar ngayQuaHan = (Calendar) ngayMuon.clone();
        ngayQuaHan.add(Calendar.DAY_OF_MONTH, 15 + (daGiaHan ? 7 : 0));
        return ngayQuaHan;
    }

    public Calendar getNgayQuaHan(Calendar ngayDong) {
        Calendar ngayQuaHan = (Calendar) ngayDong.clone();
        ngayQuaHan.add(Calendar.YEAR, 1);
        return ngayQuaHan;
    }

    public Calendar getDate(String day, String month, String year) {
        return new GregorianCalendar(Integer.parseInt(year),
                Integer.parseInt(month) - 1, Integer.parseInt(day));
    }

    public Calendar getNgayMuon(List<PhieuMuon> listPM, String iD) {
        return listPM.stream().filter(e -> e.getiD().equals(iD)).findFirst().
                get().getNgayThucHien();
    }
}
