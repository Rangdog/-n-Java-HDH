package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.PhieuPhat;

/**
 *
 * @author Hà Xuân Thanh
 */
public class DAOPhieuPhat {

    private final Connection connection;

    public DAOPhieuPhat() throws Exception {
        connection = DAO_SQL.getConnection();
    }

    public List<PhieuPhat> getList() {
        List<PhieuPhat> listPhieuPhat = new ArrayList<>();
        String sql = "SELECT * FROM PHIEUPHAT";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet result = ps.executeQuery();
            while (result.next()) {
                PhieuPhat e = new PhieuPhat();
                e.setiD(result.getString("ID"));
                e.setiDDocGia(result.getString("ID_DOCGIA"));
                e.setiDThuThu(result.getString("ID_THUTHU"));
                Calendar ngayLap = (Calendar) Calendar.getInstance();
                ngayLap.setTime(result.getDate("NGAYLAP"));
                e.setNgayThucHien(ngayLap);
                e.setLyDo(result.getString("LYDO"));
                e.setXuPhat(result.getString("XUPHAT"));
                listPhieuPhat.add(e);
            }
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuPhat.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (!listPhieuPhat.isEmpty()) {
            PhieuPhat.setiDCounter(Integer.parseInt(listPhieuPhat.get(listPhieuPhat.
                    size() - 1).getiD().substring(2, 8)) + 1);
        }
        return listPhieuPhat;
    }

    public boolean insertList(PhieuPhat e) {
        String sql = "INSERT INTO PHIEUPHAT "
                + "VALUES(?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, e.getiD());
            ps.setString(2, e.getiDDocGia());
            ps.setString(3, e.getiDThuThu());
            ps.setDate(4, new Date(e.getNgayThucHien().getTimeInMillis()));
            ps.setString(5, e.getLyDo());
            ps.setString(6, e.getXuPhat());
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuPhat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean deleteList(String iD) {
        String sql = "DELETE FROM PHIEUPHAT "
                + "WHERE ID = ?";
        try {
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1, iD);
            return ps.executeUpdate() > 0;
        } catch (SQLException ex) {
            Logger.getLogger(DAOPhieuPhat.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
